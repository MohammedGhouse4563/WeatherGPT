import React, { useState, useEffect } from 'react';
import { 
  Scale, 
  Plus, 
  X, 
  MapPin, 
  Loader2, 
  Droplets, 
  Wind, 
  Sun, 
  Activity, 
  Search, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { useWeather } from '../context/WeatherContext';
import { api } from '../services/api';
import { LocationData, WeatherDataResponse } from '../types';
import { formatTemp, formatWindSpeed } from '../utils/weatherCodes';

const PRESET_CITIES: LocationData[] = [
  { name: 'Chennai', country: 'India', admin1: 'Tamil Nadu', latitude: 13.0827, longitude: 80.2707 },
  { name: 'Coimbatore', country: 'India', admin1: 'Tamil Nadu', latitude: 11.0168, longitude: 76.9558 },
  { name: 'Bengaluru', country: 'India', admin1: 'Karnataka', latitude: 12.9716, longitude: 77.5946 },
  { name: 'Mumbai', country: 'India', admin1: 'Maharashtra', latitude: 19.0760, longitude: 72.8777 },
];

export const ComparisonPage: React.FC = () => {
  const { location, tempUnit, windUnit } = useWeather();
  
  const [selectedCities, setSelectedCities] = useState<LocationData[]>([location, PRESET_CITIES[1]]);
  const [cityWeatherData, setCityWeatherData] = useState<Record<string, WeatherDataResponse>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch weather data for all selected cities
  useEffect(() => {
    async function loadAllCityWeather() {
      setLoading(true);
      const resultsMap: Record<string, WeatherDataResponse> = {};

      await Promise.all(
        selectedCities.map(async (city) => {
          try {
            const data = await api.getWeatherData(city);
            resultsMap[city.name] = data;
          } catch (e) {
            console.error(`Failed to load weather for ${city.name}`, e);
          }
        })
      );

      setCityWeatherData(resultsMap);
      setLoading(false);
    }
    loadAllCityWeather();
  }, [selectedCities]);

  const handleAddCity = (city: LocationData) => {
    if (selectedCities.some(c => c.name.toLowerCase() === city.name.toLowerCase())) return;
    if (selectedCities.length >= 4) {
      alert('You can compare up to 4 locations simultaneously.');
      return;
    }
    setSelectedCities(prev => [...prev, city]);
    setSearchQuery('');
    setSearchResults([]);
  };

  const handleRemoveCity = (cityName: string) => {
    if (selectedCities.length <= 1) return;
    setSelectedCities(prev => prev.filter(c => c.name !== cityName));
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const results = await api.searchLocations(searchQuery);
      setSearchResults(results);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const comparisonChartData = selectedCities.map((city) => {
    const data = cityWeatherData[city.name];
    const cur = data?.current;
    const today = data?.daily?.[0];

    return {
      name: city.name,
      temperature: cur ? (tempUnit === 'fahrenheit' ? Math.round((cur.temperature * 9) / 5 + 32) : Math.round(cur.temperature)) : 0,
      rainProb: today?.precipitationProbabilityMax || 0,
      humidity: cur?.relativeHumidity || 0,
      wind: cur ? (windUnit === 'mph' ? Math.round(cur.windSpeed * 0.621371) : Math.round(cur.windSpeed)) : 0,
      aqi: data?.airQuality?.usAqi || 45,
    };
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Scale className="w-6 h-6 text-cyan-400" />
            Meteorological Comparative Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Side-by-side atmospheric comparison of up to 4 global locations
          </p>
        </div>
      </div>

      {/* City Chips & Add Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          {selectedCities.map((city) => (
            <div
              key={city.name}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 border border-slate-700 flex items-center gap-2 text-xs font-semibold text-slate-200"
            >
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              <span>{city.name}</span>
              {selectedCities.length > 1 && (
                <button
                  onClick={() => handleRemoveCity(city.name)}
                  className="text-slate-400 hover:text-red-400 ml-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Search to add city */}
        {selectedCities.length < 4 && (
          <form onSubmit={handleSearch} className="relative max-w-md flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search location to add for comparison..."
                className="w-full bg-slate-800 border border-slate-700 focus:border-cyan-500 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-400 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              {isSearching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              <span>Add</span>
            </button>
          </form>
        )}

        {/* Search Results Dropdown */}
        {searchResults.length > 0 && (
          <div className="bg-slate-950 border border-slate-700 rounded-xl p-2 max-h-48 overflow-y-auto space-y-1">
            {searchResults.map((item) => (
              <button
                key={`${item.latitude}-${item.longitude}`}
                onClick={() => handleAddCity(item)}
                className="w-full text-left px-3 py-1.5 rounded-lg hover:bg-slate-800 text-xs text-slate-200 flex items-center justify-between"
              >
                <span>{item.name}, {item.admin1 ? `${item.admin1}, ` : ''}{item.country}</span>
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
              </button>
            ))}
          </div>
        )}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[30vh] space-y-3 bg-slate-900/60 border border-slate-800 rounded-3xl p-8">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          <p className="text-xs text-slate-300">Synchronizing Multi-City Meteorological Feeds...</p>
        </div>
      ) : (
        <>
          {/* Comparison Cards Grid */}
          <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-${selectedCities.length} gap-4`}>
            {selectedCities.map((city) => {
              const data = cityWeatherData[city.name];
              const cur = data?.current;
              const today = data?.daily?.[0];
              const aqi = data?.airQuality;

              return (
                <div
                  key={city.name}
                  className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="text-base font-bold text-white">{city.name}</h3>
                      <p className="text-xs text-slate-400">{city.admin1 ? `${city.admin1}, ` : ''}{city.country}</p>
                    </div>
                    <span className="text-2xl font-black text-cyan-300">
                      {cur ? formatTemp(cur.temperature, tempUnit) : '--'}
                    </span>
                  </div>

                  <div className="space-y-2.5 text-xs text-slate-300">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Condition</span>
                      <strong className="text-slate-100">{cur?.weatherDescription || 'Fair'}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Feels Like</span>
                      <strong className="text-slate-100">{cur ? formatTemp(cur.apparentTemperature, tempUnit) : '--'}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Rain Probability</span>
                      <strong className="text-sky-400">{today ? `${today.precipitationProbabilityMax}%` : '0%'}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Wind Velocity</span>
                      <strong className="text-slate-100">{cur ? formatWindSpeed(cur.windSpeed, windUnit) : '--'}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Air Quality</span>
                      <strong className="text-emerald-400">{aqi?.status || 'Good'} ({aqi?.usAqi || 45})</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Humidity</span>
                      <strong className="text-slate-100">{cur ? `${cur.relativeHumidity}%` : '--'}</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Comparative Bar Chart */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                Thermal & Precipitation Variance Comparison
              </span>
            </div>

            <div className="h-64 sm:h-72 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparisonChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                    labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                  />
                  <Bar dataKey="temperature" name={`Temperature (°${tempUnit === 'fahrenheit' ? 'F' : 'C'})`} fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="rainProb" name="Rain Probability (%)" fill="#38bdf8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="aqi" name="Air Quality (AQI)" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}

    </div>
  );
};
