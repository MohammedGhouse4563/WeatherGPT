import React, { useState } from 'react';
import { 
  Calendar, 
  Sun, 
  Moon, 
  CloudRain, 
  Wind, 
  Droplets, 
  Gauge, 
  TrendingUp, 
  ArrowUp, 
  ArrowDown, 
  Clock,
  Layers,
  Filter
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { useWeather } from '../context/WeatherContext';
import { formatTemp, formatWindSpeed, getWindDirectionName, getUVLevel } from '../utils/weatherCodes';
import { useTranslation } from '../utils/i18n';

export const ForecastPage: React.FC = () => {
  const { location, weatherData, tempUnit, windUnit, language } = useWeather();
  const { t } = useTranslation(language);

  const [forecastTab, setForecastTab] = useState<'hourly' | 'daily'>('hourly');
  const [selectedMetric, setSelectedMetric] = useState<'temperature' | 'precipitation' | 'wind'>('temperature');

  const hourlyData = weatherData?.hourly.slice(0, 36).map((h) => ({
    time: new Date(h.time).toLocaleTimeString([], { hour: 'numeric', hour12: true }),
    isoTime: h.time,
    temp: tempUnit === 'fahrenheit' ? Math.round((h.temperature * 9) / 5 + 32) : Math.round(h.temperature),
    apparentTemp: tempUnit === 'fahrenheit' ? Math.round((h.apparentTemperature * 9) / 5 + 32) : Math.round(h.apparentTemperature),
    rainProb: h.precipitationProbability,
    rainMm: h.precipitation,
    windSpeed: windUnit === 'mph' ? Math.round(h.windSpeed * 0.621371) : Math.round(h.windSpeed),
    humidity: h.relativeHumidity,
    uv: h.uvIndex,
    condition: h.weatherDescription,
  })) || [];

  const dailyData = weatherData?.daily.slice(0, 7).map((d) => {
    const dateObj = new Date(d.date);
    return {
      date: dateObj.toLocaleDateString([], { weekday: 'short', month: 'numeric', day: 'numeric' }),
      maxTemp: tempUnit === 'fahrenheit' ? Math.round((d.tempMax * 9) / 5 + 32) : Math.round(d.tempMax),
      minTemp: tempUnit === 'fahrenheit' ? Math.round((d.tempMin * 9) / 5 + 32) : Math.round(d.tempMin),
      rainProb: d.precipitationProbabilityMax,
      rainSum: d.precipitationSum,
      windMax: windUnit === 'mph' ? Math.round(d.windSpeedMax * 0.621371) : Math.round(d.windSpeedMax),
      uvMax: d.uvIndexMax,
      condition: d.weatherDescription,
    };
  }) || [];

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Calendar className="w-6 h-6 text-cyan-400" />
            Meteorological Forecast Outlook
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            ECMWF High-Resolution Ensemble for {location.name}, {location.country}
          </p>
        </div>

        {/* Hourly vs Daily Toggle */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs font-semibold">
          <button
            id="btn-forecast-hourly"
            onClick={() => setForecastTab('hourly')}
            className={`px-4 py-1.5 rounded-lg transition-colors ${
              forecastTab === 'hourly' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            36-Hour Hourly
          </button>
          <button
            id="btn-forecast-daily"
            onClick={() => setForecastTab('daily')}
            className={`px-4 py-1.5 rounded-lg transition-colors ${
              forecastTab === 'daily' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            7-Day Daily Outlook
          </button>
        </div>
      </div>

      {/* Interactive Charts Panel */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl">
        
        {/* Metric Selector Pills */}
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800/80 pb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            {selectedMetric === 'temperature' ? 'Thermal Trajectory' : selectedMetric === 'precipitation' ? 'Precipitation Probability & Accumulation' : 'Wind Velocity Curves'}
          </span>

          <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl text-xs">
            <button
              onClick={() => setSelectedMetric('temperature')}
              className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                selectedMetric === 'temperature' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Temperature
            </button>
            <button
              onClick={() => setSelectedMetric('precipitation')}
              className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                selectedMetric === 'precipitation' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Rain & Probability
            </button>
            <button
              onClick={() => setSelectedMetric('wind')}
              className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                selectedMetric === 'wind' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              Wind Velocity
            </button>
          </div>
        </div>

        {/* Chart Canvas */}
        <div className="h-64 sm:h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {forecastTab === 'hourly' ? (
              selectedMetric === 'temperature' ? (
                <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} unit={`°${tempUnit === 'fahrenheit' ? 'F' : 'C'}`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                    labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                  />
                  <Area type="monotone" dataKey="temp" name="Temperature" stroke="#06b6d4" strokeWidth={2.5} fillOpacity={1} fill="url(#tempGradient)" />
                  <Line type="monotone" dataKey="apparentTemp" name="Feels Like" stroke="#f43f5e" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
                </AreaChart>
              ) : selectedMetric === 'precipitation' ? (
                <BarChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} unit="%" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                    labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                  />
                  <Bar dataKey="rainProb" name="Rain Probability (%)" fill="#38bdf8" radius={[4, 4, 0, 0]} />
                </BarChart>
              ) : (
                <LineChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} unit={windUnit === 'mph' ? 'mph' : 'km/h'} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                    labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                  />
                  <Line type="monotone" dataKey="windSpeed" name="Wind Speed" stroke="#a855f7" strokeWidth={2.5} dot={{ r: 2 }} />
                </LineChart>
              )
            ) : (
              /* Daily Charts */
              <AreaChart data={dailyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="dailyMaxGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} unit={`°${tempUnit === 'fahrenheit' ? 'F' : 'C'}`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="maxTemp" name="Max Temp" stroke="#f43f5e" strokeWidth={2.5} fill="url(#dailyMaxGrad)" />
                <Area type="monotone" dataKey="minTemp" name="Min Temp" stroke="#06b6d4" strokeWidth={2.5} fill="#06b6d4" fillOpacity={0.1} />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

      </div>

      {/* Detailed Grid Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            {forecastTab === 'hourly' ? 'Detailed Hourly Breakdown' : '7-Day Agronomic & Meteorological Outlook'}
          </h2>
          <span className="text-[11px] text-slate-400">Values updated in real-time</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">Time / Date</th>
                <th className="py-2.5 px-3">Condition</th>
                <th className="py-2.5 px-3">Temp</th>
                <th className="py-2.5 px-3">Rain %</th>
                <th className="py-2.5 px-3">Wind Speed</th>
                <th className="py-2.5 px-3">UV Index</th>
                <th className="py-2.5 px-3">Humidity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {forecastTab === 'hourly' ? (
                hourlyData.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-100">{item.time}</td>
                    <td className="py-2.5 px-3 text-cyan-300 font-medium">{item.condition}</td>
                    <td className="py-2.5 px-3 font-bold text-white">{item.temp}°</td>
                    <td className="py-2.5 px-3 text-sky-400 font-medium">{item.rainProb}%</td>
                    <td className="py-2.5 px-3">{item.windSpeed} {windUnit === 'mph' ? 'mph' : 'km/h'}</td>
                    <td className="py-2.5 px-3 text-amber-400 font-medium">{item.uv.toFixed(1)}</td>
                    <td className="py-2.5 px-3">{item.humidity}%</td>
                  </tr>
                ))
              ) : (
                dailyData.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-100">{item.date}</td>
                    <td className="py-2.5 px-3 text-cyan-300 font-medium">{item.condition}</td>
                    <td className="py-2.5 px-3 font-bold text-white">
                      <span className="text-rose-400">{item.maxTemp}°</span> / <span className="text-cyan-400">{item.minTemp}°</span>
                    </td>
                    <td className="py-2.5 px-3 text-sky-400 font-medium">{item.rainProb}% ({item.rainSum} mm)</td>
                    <td className="py-2.5 px-3">{item.windMax} {windUnit === 'mph' ? 'mph' : 'km/h'}</td>
                    <td className="py-2.5 px-3 text-amber-400 font-medium">{item.uvMax.toFixed(1)}</td>
                    <td className="py-2.5 px-3">Balanced</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
