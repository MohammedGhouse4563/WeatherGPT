import React, { useState, useEffect } from 'react';
import { 
  Route, 
  MapPin, 
  Navigation, 
  ArrowRight, 
  CloudRain, 
  Wind, 
  Eye, 
  AlertTriangle, 
  ShieldCheck, 
  Sparkles, 
  Car, 
  Clock, 
  RefreshCw, 
  Loader2, 
  ChevronRight,
  Printer,
  Compass
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { LocationData, WeatherDataResponse } from '../types';
import { formatTemp, formatWindSpeed } from '../utils/weatherCodes';
import { api } from '../services/api';
import { searchOfflineLocations } from '../utils/offlineLocations';

interface RouteCheckpoint {
  location: LocationData;
  distancePercent: number;
  weather: WeatherDataResponse;
  hazards: string[];
}

const ROUTE_PRESETS = [
  { from: 'Chennai', to: 'Bengaluru', label: 'Chennai ➔ Bengaluru (NH48 - 350 km)' },
  { from: 'Mumbai', to: 'Pune', label: 'Mumbai ➔ Pune (Expressway - 150 km)' },
  { from: 'Delhi', to: 'Jaipur', label: 'Delhi ➔ Jaipur (NH48 - 280 km)' },
  { from: 'London', to: 'Paris', label: 'London ➔ Paris (Euro Corridor - 450 km)' },
  { from: 'New York', to: 'Boston', label: 'New York ➔ Boston (I-95 - 340 km)' },
  { from: 'Tokyo', to: 'Osaka', label: 'Tokyo ➔ Osaka (Tokaido - 500 km)' },
];

export const TripPlannerPage: React.FC = () => {
  const { location, tempUnit, windUnit, language } = useWeather();

  const [originQuery, setOriginQuery] = useState(location.name);
  const [destQuery, setDestQuery] = useState('Bengaluru');
  const [originLoc, setOriginLoc] = useState<LocationData>(location);
  const [destLoc, setDestLoc] = useState<LocationData>({
    name: 'Bengaluru',
    country: 'India',
    admin1: 'Karnataka',
    latitude: 12.9716,
    longitude: 77.5946,
  });

  const [originResults, setOriginResults] = useState<LocationData[]>([]);
  const [destResults, setDestResults] = useState<LocationData[]>([]);
  const [showOriginDropdown, setShowOriginDropdown] = useState(false);
  const [showDestDropdown, setShowDestDropdown] = useState(false);

  const [departureTime, setDepartureTime] = useState<'now' | 'plus2h' | 'tomorrow'>('now');
  const [isLoadingRoute, setIsLoadingRoute] = useState(false);
  const [routeCheckpoints, setRouteCheckpoints] = useState<RouteCheckpoint[]>([]);
  const [aiTravelBrief, setAiTravelBrief] = useState<string | null>(null);
  const [isGeneratingAiBrief, setIsGeneratingAiBrief] = useState(false);

  // Autocomplete debouncers
  useEffect(() => {
    if (!originQuery.trim()) return;
    const t = setTimeout(async () => {
      const res = await api.searchLocations(originQuery);
      setOriginResults(res);
    }, 250);
    return () => clearTimeout(t);
  }, [originQuery]);

  useEffect(() => {
    if (!destQuery.trim()) return;
    const t = setTimeout(async () => {
      const res = await api.searchLocations(destQuery);
      setDestResults(res);
    }, 250);
    return () => clearTimeout(t);
  }, [destQuery]);

  const calculateRouteWeather = async () => {
    if (!originLoc || !destLoc) return;
    setIsLoadingRoute(true);
    setAiTravelBrief(null);

    try {
      const rawCheckpoints = await api.getRouteWeatherData(originLoc, destLoc, 3);
      
      const enriched: RouteCheckpoint[] = rawCheckpoints.map(cp => {
        const cur = cp.weather.current;
        const hazards: string[] = [];

        if (cur.windSpeed > 35) {
          hazards.push(`High Crosswinds (${Math.round(cur.windSpeed)} km/h)`);
        }
        if (cur.precipitation > 2 || (cp.weather.hourly[0]?.precipitationProbability || 0) > 60) {
          hazards.push('Heavy Rain & Wet Pavement');
        }
        if (cur.visibility < 3000) {
          hazards.push(`Low Visibility Fog (${(cur.visibility / 1000).toFixed(1)} km)`);
        }
        if (cur.temperature > 39) {
          hazards.push('Extreme High Heat (Tire stress)');
        } else if (cur.temperature < 2) {
          hazards.push('Near Freezing (Risk of black ice)');
        }

        return {
          ...cp,
          hazards,
        };
      });

      setRouteCheckpoints(enriched);
    } catch (e) {
      console.error('Route calculation failed:', e);
    } finally {
      setIsLoadingRoute(false);
    }
  };

  useEffect(() => {
    calculateRouteWeather();
  }, [originLoc, destLoc]);

  const handleApplyPreset = (preset: typeof ROUTE_PRESETS[0]) => {
    const fromMatches = searchOfflineLocations(preset.from);
    const toMatches = searchOfflineLocations(preset.to);
    if (fromMatches.length > 0) {
      setOriginLoc(fromMatches[0]);
      setOriginQuery(fromMatches[0].name);
    }
    if (toMatches.length > 0) {
      setDestLoc(toMatches[0]);
      setDestQuery(toMatches[0].name);
    }
  };

  const handleGenerateAiBrief = async () => {
    if (routeCheckpoints.length === 0) return;
    setIsGeneratingAiBrief(true);
    try {
      const query = `Provide a comprehensive, concise Travel Route Weather Safety Brief for driving from ${originLoc.name} to ${destLoc.name}. Highlight expected temperatures, rain windows, crosswinds, and recommended stop intervals.`;
      const res = await api.sendChatMessage({
        query,
        defaultLocation: originLoc,
        language,
      });
      setAiTravelBrief(res.response);
    } catch (e) {
      setAiTravelBrief('Weather along route is within normal driving parameters. Stay vigilant for unexpected sudden localized showers and maintain regular highway stopping intervals.');
    } finally {
      setIsGeneratingAiBrief(false);
    }
  };

  const totalHazards = routeCheckpoints.reduce((acc, cp) => acc + cp.hazards.length, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800/90 to-cyan-950/50 border border-slate-700/80 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Route className="w-4 h-4" />
            <span>Smart Route Weather Planner</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Highway & Travel Meteorology
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            Forecast real-time weather checkpoints, severe driving hazards, and highway conditions along your journey.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition-colors self-start md:self-auto"
        >
          <Printer className="w-4 h-4 text-cyan-400" />
          <span>Print Route Dossier</span>
        </button>
      </div>

      {/* Preset Quick Routes */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex-shrink-0">
          Popular Corridors:
        </span>
        {ROUTE_PRESETS.map((p) => (
          <button
            key={p.label}
            onClick={() => handleApplyPreset(p)}
            className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 font-medium whitespace-nowrap transition-all text-xs"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Origin, Destination & Options Control Bar */}
      <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
          
          {/* Origin Input */}
          <div className="lg:col-span-2 relative">
            <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" /> Origin City / Departure
            </label>
            <input
              type="text"
              value={originQuery}
              onChange={(e) => {
                setOriginQuery(e.target.value);
                setShowOriginDropdown(true);
              }}
              onFocus={() => setShowOriginDropdown(true)}
              placeholder="Enter starting city..."
              className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />

            {showOriginDropdown && originResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 max-h-48 overflow-y-auto p-1">
                {originResults.map((item, idx) => (
                  <button
                    key={`${item.name}-${idx}`}
                    onClick={() => {
                      setOriginLoc(item);
                      setOriginQuery(item.name);
                      setShowOriginDropdown(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-slate-800 text-slate-200 flex justify-between"
                  >
                    <span className="font-semibold text-white">{item.name}</span>
                    <span className="text-slate-400">{item.country}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Destination Input */}
          <div className="lg:col-span-2 relative">
            <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-rose-400" /> Destination City / Arrival
            </label>
            <input
              type="text"
              value={destQuery}
              onChange={(e) => {
                setDestQuery(e.target.value);
                setShowDestDropdown(true);
              }}
              onFocus={() => setShowDestDropdown(true)}
              placeholder="Enter destination city..."
              className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />

            {showDestDropdown && destResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 max-h-48 overflow-y-auto p-1">
                {destResults.map((item, idx) => (
                  <button
                    key={`${item.name}-${idx}`}
                    onClick={() => {
                      setDestLoc(item);
                      setDestQuery(item.name);
                      setShowDestDropdown(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-slate-800 text-slate-200 flex justify-between"
                  >
                    <span className="font-semibold text-white">{item.name}</span>
                    <span className="text-slate-400">{item.country}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Recalculate Button */}
          <div>
            <button
              onClick={calculateRouteWeather}
              disabled={isLoadingRoute}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
            >
              {isLoadingRoute ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              <span>Sync Route</span>
            </button>
          </div>

        </div>
      </div>

      {/* Safety Summary Banner */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
        totalHazards === 0 
          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
          : 'bg-amber-950/40 border-amber-500/50 text-amber-300'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
            totalHazards === 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400 animate-pulse'
          }`}>
            {totalHazards === 0 ? <ShieldCheck className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider block">
              {totalHazards === 0 ? 'Optimal Route Conditions' : `${totalHazards} Potential Driving Hazards Detected`}
            </span>
            <p className="text-xs text-slate-300">
              {totalHazards === 0 
                ? 'No severe crosswinds, torrential downpours, or extreme visibility restrictions detected across route checkpoints.'
                : 'Review checkpoint hazard flags below before embarking on the highway.'}
            </p>
          </div>
        </div>

        <button
          onClick={handleGenerateAiBrief}
          disabled={isGeneratingAiBrief}
          className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-colors"
        >
          {isGeneratingAiBrief ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
          <span>WeatherGPT Advisory</span>
        </button>
      </div>

      {/* AI Travel Brief Output */}
      {aiTravelBrief && (
        <div className="p-5 rounded-3xl bg-slate-900 border border-cyan-500/40 shadow-xl space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase">
            <Sparkles className="w-4 h-4" />
            <span>AI Travel Safety Dossier</span>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-line">
            {aiTravelBrief}
          </p>
        </div>
      )}

      {/* Route Checkpoints Timeline */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
          <Compass className="w-4 h-4 text-cyan-400" />
          En-Route Checkpoints & Weather Profile
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {routeCheckpoints.map((cp, idx) => {
            const cur = cp.weather.current;
            const isOrigin = idx === 0;
            const isDest = idx === routeCheckpoints.length - 1;

            return (
              <div
                key={`${cp.location.latitude}-${idx}`}
                className={`p-4 rounded-2xl border transition-all space-y-3 ${
                  cp.hazards.length > 0 
                    ? 'bg-gradient-to-b from-slate-900 to-amber-950/30 border-amber-500/40 shadow-md shadow-amber-950/20' 
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Progress pill */}
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isOrigin 
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' 
                      : isDest 
                      ? 'bg-rose-950 text-rose-400 border border-rose-800' 
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isOrigin ? 'Origin (0%)' : isDest ? 'Destination (100%)' : `${cp.distancePercent}% of Route`}
                  </span>

                  <span className="text-[10px] text-slate-400 font-mono">
                    {cp.location.latitude.toFixed(1)}°, {cp.location.longitude.toFixed(1)}°
                  </span>
                </div>

                {/* Location Name */}
                <div>
                  <h3 className="text-sm font-bold text-white truncate">
                    {cp.location.name}
                  </h3>
                  <p className="text-[11px] text-cyan-300 font-medium truncate mt-0.5">
                    {cur.weatherDescription}
                  </p>
                </div>

                {/* Primary Temp */}
                <div className="text-3xl font-black text-white">
                  {formatTemp(cur.temperature, tempUnit)}
                </div>

                {/* Metric Badges */}
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-800/80">
                  <div className="space-y-0.5">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Wind className="w-3 h-3 text-cyan-400" /> Wind
                    </span>
                    <span className="font-semibold text-slate-200">
                      {formatWindSpeed(cur.windSpeed, windUnit)}
                    </span>
                  </div>

                  <div className="space-y-0.5">
                    <span className="text-slate-400 flex items-center gap-1">
                      <CloudRain className="w-3 h-3 text-sky-400" /> Rain
                    </span>
                    <span className="font-semibold text-slate-200">
                      {cur.precipitation} mm
                    </span>
                  </div>
                </div>

                {/* Hazards List */}
                {cp.hazards.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 space-y-1">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                      Hazard Warnings:
                    </span>
                    {cp.hazards.map((h, i) => (
                      <div key={i} className="text-[10px] text-amber-200 flex items-center gap-1 bg-amber-950/60 p-1 rounded-md">
                        <AlertTriangle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                        <span className="truncate">{h}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
