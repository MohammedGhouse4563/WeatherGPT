import React, { useState } from 'react';
import { 
  ShieldAlert, 
  PhoneCall, 
  AlertTriangle, 
  Wind, 
  Droplets, 
  CloudLightning, 
  Flame, 
  CheckSquare, 
  Square, 
  Radio, 
  ExternalLink,
  LifeBuoy
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';

const EMERGENCY_CONTACTS = [
  { name: 'National Emergency Response', number: '112', desc: 'All-in-one Police, Fire & Medical hotline across India' },
  { name: 'National Disaster Management (NDMA)', number: '1078', desc: 'Central Disaster Helpline & Cyclone alerts' },
  { name: 'State Disaster Control Room (SDMA)', number: '1070', desc: 'State-level flood & emergency coordination' },
  { name: 'Ambulance & Emergency Medical', number: '108', desc: 'Emergency trauma & medical transport services' },
  { name: 'Fire & Rescue Services', number: '101', desc: 'Water rescue, fallen tree clearing & fire emergency' },
  { name: 'IMD Cyclone Warning Center', number: '1800-180-1717', desc: 'Toll-free 24/7 meteorological advisory' },
];

export const DisasterCenterPage: React.FC = () => {
  const { location, alerts } = useWeather();
  const [activeHazard, setActiveHazard] = useState<'cyclone' | 'flood' | 'lightning' | 'heatwave'>('cyclone');
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleCheck = (id: string) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const HAZARD_PROTOCOLS = {
    cyclone: {
      title: 'Cyclone & Extreme Wind Protocols',
      icon: Wind,
      color: 'text-cyan-400',
      checklists: [
        { id: 'c1', label: 'Fasten or dismantle loose tin sheets, signboards, and outdoor furniture.' },
        { id: 'c2', label: 'Trim dead tree branches near power lines or roof edges.' },
        { id: 'c3', label: 'Charge all mobile phones, power banks, and keep battery emergency lights ready.' },
        { id: 'c4', label: 'Store at least 5-7 days of non-perishable dry food and drinking water in sanitized containers.' },
        { id: 'c5', label: 'Stay indoors away from glass windows and doors during peak wind passage.' },
        { id: 'c6', label: 'Do not venture out during the "eye of the cyclone" calm period as severe reverse winds follow.' },
      ],
    },
    flood: {
      title: 'Heavy Rainfall & Flash Flood Protocols',
      icon: Droplets,
      color: 'text-sky-400',
      checklists: [
        { id: 'f1', label: 'Identify higher ground evacuation centers and nearest municipal relief shelters.' },
        { id: 'f2', label: 'Keep emergency medical kits, prescribed medicines, and vital documents sealed in waterproof ziplock bags.' },
        { id: 'f3', label: 'Turn off main electrical breaker switch and gas cylinders if water enters premises.' },
        { id: 'f4', label: 'Never drive or walk through flooded underpasses or moving flood waters (Turn Around, Don’t Drown).' },
        { id: 'f5', label: 'Boil or chlorinate all drinking water to prevent water-borne disease outbreaks.' },
      ],
    },
    lightning: {
      title: 'Severe Thunderstorm & Lightning Safety',
      icon: CloudLightning,
      color: 'text-amber-400',
      checklists: [
        { id: 'l1', label: 'Follow the 30/30 Rule: If thunder occurs within 30 seconds of lightning, seek immediate indoor shelter.' },
        { id: 'l2', label: 'Unplug sensitive electronics and desktop computers from power wall outlets.' },
        { id: 'l3', label: 'Never take shelter under tall isolated trees, open sheds, or near metal towers.' },
        { id: 'l4', label: 'Avoid water bodies, swimming pools, open agricultural fields, and wet metal fences.' },
        { id: 'l5', label: 'Stay indoors for at least 30 minutes after the last thunderclap before resuming outdoors.' },
      ],
    },
    heatwave: {
      title: 'Extreme Heatwave & Heatstroke Protocols',
      icon: Flame,
      color: 'text-rose-400',
      checklists: [
        { id: 'h1', label: 'Drink water frequently with lemon, buttermilk, or ORS electrolytes even if not thirsty.' },
        { id: 'h2', label: 'Avoid direct peak sun exposure between 11:00 AM and 4:00 PM.' },
        { id: 'h3', label: 'Wear lightweight, loose-fitting, light-colored cotton clothing.' },
        { id: 'h4', label: 'Never leave children, elderly family members, or pets in parked closed vehicles.' },
        { id: 'h5', label: 'Recognize heat exhaustion signs: dizziness, nausea, rapid pulse, or heavy sweating.' },
      ],
    },
  };

  const currentProtocol = HAZARD_PROTOCOLS[activeHazard];
  const HazardIcon = currentProtocol.icon;

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-cyan-400" />
              Disaster Management & Preparedness Center
            </h1>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/80">
              National Disaster Support
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Emergency response protocols, checklists, and 24/7 hotline directory for {location.name}
          </p>
        </div>
      </div>

      {/* Emergency Helpline Directory Cards */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
          <PhoneCall className="w-4 h-4 text-emerald-400" />
          24/7 Government Emergency Hotlines
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {EMERGENCY_CONTACTS.map((c) => (
            <div
              key={c.number}
              className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between group hover:border-cyan-500/40 transition-all shadow-md"
            >
              <div className="space-y-0.5 pr-2">
                <div className="text-xs font-bold text-slate-100">{c.name}</div>
                <div className="text-[11px] text-slate-400 line-clamp-1">{c.desc}</div>
              </div>

              <a
                href={`tel:${c.number}`}
                className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/40 font-black text-sm font-mono flex items-center gap-1.5 transition-all shadow-sm flex-shrink-0"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>{c.number}</span>
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Safety & Hazard Protocols */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            Actionable Disaster Preparedness Checklist
          </h2>

          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl text-xs overflow-x-auto">
            <button
              onClick={() => setActiveHazard('cyclone')}
              className={`px-3 py-1 rounded-lg transition-colors font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                activeHazard === 'cyclone' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              <Wind className="w-3.5 h-3.5" />
              <span>Cyclone</span>
            </button>

            <button
              onClick={() => setActiveHazard('flood')}
              className={`px-3 py-1 rounded-lg transition-colors font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                activeHazard === 'flood' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              <Droplets className="w-3.5 h-3.5" />
              <span>Flood</span>
            </button>

            <button
              onClick={() => setActiveHazard('lightning')}
              className={`px-3 py-1 rounded-lg transition-colors font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                activeHazard === 'lightning' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              <CloudLightning className="w-3.5 h-3.5" />
              <span>Lightning</span>
            </button>

            <button
              onClick={() => setActiveHazard('heatwave')}
              className={`px-3 py-1 rounded-lg transition-colors font-semibold flex items-center gap-1.5 whitespace-nowrap ${
                activeHazard === 'heatwave' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Heatwave</span>
            </button>
          </div>
        </div>

        {/* Hazard Protocol Checklists */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <HazardIcon className={`w-5 h-5 ${currentProtocol.color}`} />
            <h3 className="text-sm font-bold text-slate-100">{currentProtocol.title}</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentProtocol.checklists.map((item) => {
              const isDone = !!checkedItems[item.id];

              return (
                <div
                  key={item.id}
                  onClick={() => toggleCheck(item.id)}
                  className={`p-3.5 rounded-2xl border cursor-pointer flex items-start gap-3 transition-all ${
                    isDone
                      ? 'bg-emerald-950/30 border-emerald-500/40 text-slate-200'
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600 text-slate-300'
                  }`}
                >
                  <div className="mt-0.5 text-cyan-400">
                    {isDone ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500" />
                    )}
                  </div>
                  <span className={`text-xs leading-relaxed ${isDone ? 'line-through text-slate-400' : ''}`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
