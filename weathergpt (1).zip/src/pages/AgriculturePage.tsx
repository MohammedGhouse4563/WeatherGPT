import React, { useState, useEffect } from 'react';
import { 
  Sprout, 
  Droplets, 
  Sun, 
  Wind, 
  Bug, 
  ShieldCheck, 
  Loader2, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  Clock
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { api } from '../services/api';
import { AgriAdvisoryResponse } from '../types';
import { useTranslation } from '../utils/i18n';

const CROPS = [
  'Paddy / Rice (நெல்)',
  'Cotton (பருத்தி)',
  'Sugarcane (கரும்பு)',
  'Wheat (गेहूं)',
  'Maize / Corn (மக்காச்சோளம்)',
  'Groundnut / Peanut (வேர்க்கடலை)',
  'Vegetables & Tomato (தக்காளி/காய்கறிகள்)',
  'Banana (வாழை)',
  'Tea & Coffee (தேயிலை/காபி)',
  'Chilli & Spices (மிளகாய்/மசாலா)',
];

const STAGES = ['Land Prep & Sowing', 'Vegetative Growth', 'Flowering & Tillering', 'Fruit/Grain Development', 'Harvesting & Maturation'];
const IRRIGATION_METHODS = ['Drip Irrigation', 'Sprinkler System', 'Flood / Canal Irrigation', 'Rainfed / Natural Moisture'];

export const AgriculturePage: React.FC = () => {
  const { location, language } = useWeather();
  const { t } = useTranslation(language);

  const [crop, setCrop] = useState<string>(CROPS[0]);
  const [stage, setStage] = useState<string>(STAGES[1]);
  const [irrigation, setIrrigation] = useState<string>(IRRIGATION_METHODS[0]);
  const [advisory, setAdvisory] = useState<AgriAdvisoryResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAdvisory = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAgriAdvisory({
        crop,
        location,
        growthStage: stage,
        irrigationMethod: irrigation,
        language,
      });
      setAdvisory(res);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate agronomic advisory');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdvisory();
  }, [location, language]);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <Sprout className="w-6 h-6 text-emerald-400" />
              {t('agriTitle')}
            </h1>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/80">
              Crop Intelligence
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Microclimate weather synchronization for {location.name}, {location.country}
          </p>
        </div>

        <button
          onClick={fetchAdvisory}
          disabled={loading}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 disabled:opacity-50 transition-all self-start sm:self-auto"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          <span>{t('getAdvisory')}</span>
        </button>
      </div>

      {/* Crop & Farming Parameter Selector Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sprout className="w-4 h-4 text-emerald-400" />
              {t('cropLabel')}
            </label>
            <select
              id="select-agri-crop"
              value={crop}
              onChange={(e) => setCrop(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none"
            >
              {CROPS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-amber-400" />
              {t('stageLabel')}
            </label>
            <select
              id="select-agri-stage"
              value={stage}
              onChange={(e) => setStage(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none"
            >
              {STAGES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-sky-400" />
              {t('irrigationLabel')}
            </label>
            <select
              id="select-agri-irrigation"
              value={irrigation}
              onChange={(e) => setIrrigation(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none"
            >
              {IRRIGATION_METHODS.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Advisory Output */}
      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[30vh] space-y-3 bg-slate-900/60 border border-slate-800 rounded-3xl p-8">
          <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          <p className="text-xs text-slate-300">Computing 7-Day Agronomic Forecast & Evapotranspiration Models...</p>
        </div>
      ) : error ? (
        <div className="p-6 bg-red-950/40 border border-red-800/80 rounded-2xl text-center space-y-2">
          <AlertTriangle className="w-8 h-8 text-red-400 mx-auto" />
          <p className="text-xs text-red-200">{error}</p>
        </div>
      ) : advisory ? (
        <div className="space-y-6">
          
          {/* Key Agronomic Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Irrigation Card */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Irrigation Window</span>
                <Droplets className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-sm font-black text-sky-300">
                {advisory.irrigationRecommendation.status}
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                {advisory.irrigationRecommendation.reason}
              </p>
            </div>

            {/* Spray Suitability */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pesticide Spray Window</span>
                <Wind className="w-4 h-4 text-cyan-400" />
              </div>
              <div className={`text-sm font-black ${advisory.spraySuitability.suitable ? 'text-emerald-400' : 'text-amber-400'}`}>
                {advisory.spraySuitability.suitable ? 'Favorable Window' : 'Postpone Spraying'}
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                {advisory.spraySuitability.condition} • {advisory.spraySuitability.windNote}
              </p>
            </div>

            {/* Heat Stress */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Thermal Canopy Stress</span>
                <Sun className="w-4 h-4 text-amber-400" />
              </div>
              <div className={`text-sm font-black ${
                advisory.heatStressRisk.level === 'Severe' || advisory.heatStressRisk.level === 'High' ? 'text-rose-400' : 'text-emerald-400'
              }`}>
                {advisory.heatStressRisk.level} Risk
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                {advisory.heatStressRisk.mitigation}
              </p>
            </div>

            {/* Pest Risk */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fungal & Pest Threat</span>
                <Bug className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-sm font-black text-purple-300">
                {advisory.diseasePestRisk.riskLevel} Level
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                {advisory.diseasePestRisk.prevention}
              </p>
            </div>

          </div>

          {/* Full AI Agronomic Guidance Output Box */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800/90 to-emerald-950/40 border border-emerald-500/30 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Comprehensive WeatherGPT Agronomy Directive ({crop})
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Updated: {new Date(advisory.updatedAt).toLocaleTimeString()}
              </span>
            </div>

            <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line prose prose-invert max-w-none">
              {advisory.aiAdvisoryText}
            </div>
          </div>

        </div>
      ) : null}

    </div>
  );
};
