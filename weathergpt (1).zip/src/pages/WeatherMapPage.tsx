import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Map as MapIcon, 
  Layers, 
  Search, 
  Navigation, 
  CloudRain, 
  Sun, 
  Wind, 
  AlertTriangle, 
  ShieldAlert,
  Loader2,
  Play,
  Pause,
  RotateCcw,
  Sliders,
  Maximize2,
  Crosshair,
  Gauge
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { formatTemp } from '../utils/weatherCodes';
import { api } from '../services/api';
import { LocationData } from '../types';

// Doppler radar timeline timestamps relative to now
const RADAR_TIMESTAMPS = [
  { id: 't-120', label: '-2h', timeOffset: -120 },
  { id: 't-90', label: '-90m', timeOffset: -90 },
  { id: 't-60', label: '-1h', timeOffset: -60 },
  { id: 't-30', label: '-30m', timeOffset: -30 },
  { id: 't-10', label: '-10m', timeOffset: -10 },
  { id: 't-now', label: 'LIVE NOW', timeOffset: 0, isLive: true },
  { id: 't+30', label: '+30m Nowcast', timeOffset: 30, isForecast: true },
];

export const WeatherMapPage: React.FC = () => {
  const { location, setLocation, weatherData, tempUnit } = useWeather();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const radarTileRef = useRef<L.TileLayer | null>(null);

  const [activeLayer, setActiveLayer] = useState<'precipitation' | 'temp' | 'wind' | 'satellite' | 'aqi'>('precipitation');
  const [mapSearchQuery, setMapSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Radar Timeline Animation State
  const [timelineIndex, setTimelineIndex] = useState<number>(5); // defaults to LIVE NOW
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1000); // 1 sec per frame
  const [radarOpacity, setRadarOpacity] = useState<number>(0.75);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [location.latitude, location.longitude],
        zoom: 7,
        zoomControl: false,
      });

      // CartoDB Dark Matter Base Tiles
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      // Custom Zoom Control
      L.control.zoom({ position: 'bottomright' }).addTo(map);

      layerGroupRef.current = L.layerGroup().addTo(map);

      // Click on map to fetch weather at coordinates
      map.on('click', async (e: L.LeafletMouseEvent) => {
        try {
          const { lat, lng } = e.latlng;
          const resolved = await api.reverseGeocode(lat, lng);
          setLocation(resolved);
        } catch (err) {
          console.error(err);
        }
      });

      mapInstanceRef.current = map;
    }
  }, []);

  // Update map view and marker when active location changes
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    map.flyTo([location.latitude, location.longitude], 8, { duration: 1.2 });

    const customIcon = L.divIcon({
      className: 'custom-weather-pin',
      html: `<div class="relative flex items-center justify-center">
        <div class="absolute w-8 h-8 rounded-full bg-cyan-500/30 animate-ping"></div>
        <div class="relative w-7 h-7 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center shadow-xl border-2 border-slate-900 text-xs">
          ${weatherData?.current ? Math.round(weatherData.current.temperature) + '°' : '📍'}
        </div>
      </div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
    });

    if (markerRef.current) {
      markerRef.current.setLatLng([location.latitude, location.longitude]);
      markerRef.current.setIcon(customIcon);
    } else {
      markerRef.current = L.marker([location.latitude, location.longitude], { icon: customIcon }).addTo(map);
    }

    const popupContent = `
      <div class="p-1 font-sans text-slate-900">
        <strong class="text-sm font-bold">${location.name}</strong><br/>
        <span class="text-xs text-slate-600">${location.country}</span>
        <div class="mt-1 pt-1 border-t border-slate-200 text-xs">
          <strong>${weatherData?.current ? formatTemp(weatherData.current.temperature, tempUnit) : '--'}</strong> • ${weatherData?.current?.weatherDescription || 'Observed'}<br/>
          Wind: ${weatherData?.current ? Math.round(weatherData.current.windSpeed) + ' km/h' : '--'}
        </div>
      </div>
    `;
    markerRef.current.bindPopup(popupContent);
  }, [location, weatherData, tempUnit]);

  // Radar Animation Loop
  useEffect(() => {
    let timer: any = null;
    if (isPlaying) {
      timer = setInterval(() => {
        setTimelineIndex((prev) => (prev + 1) % RADAR_TIMESTAMPS.length);
      }, playbackSpeed);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, playbackSpeed]);

  // Update Weather Layers based on activeLayer and timelineIndex
  useEffect(() => {
    if (!mapInstanceRef.current || !layerGroupRef.current) return;
    layerGroupRef.current.clearLayers();

    const map = mapInstanceRef.current;

    // Precipitation Doppler Radar Layer
    if (activeLayer === 'precipitation') {
      const isForecast = RADAR_TIMESTAMPS[timelineIndex]?.isForecast;
      const radarUrl = isForecast 
        ? 'https://tilecache.rainviewer.com/v2/radar/nowcast_5/256/{z}/{x}/{y}/2/1_1.png'
        : 'https://tilecache.rainviewer.com/v2/radar/nowcast_0/256/{z}/{x}/{y}/2/1_1.png';

      const rainViewerTile = L.tileLayer(radarUrl, {
        opacity: radarOpacity,
        attribution: '&copy; RainViewer Doppler Meteorological Radar',
      });
      layerGroupRef.current.addLayer(rainViewerTile);
    } 
    // Infrared Satellite Cloud Top Layer
    else if (activeLayer === 'satellite') {
      const satTile = L.tileLayer('https://tilecache.rainviewer.com/v2/satellite/infrared/256/{z}/{x}/{y}/0/1_0.png', {
        opacity: radarOpacity,
        attribution: '&copy; NOAA / EUMETSAT Infrared Satellite',
      });
      layerGroupRef.current.addLayer(satTile);
    }
    // Thermal & Wind Gradients
    else if (activeLayer === 'temp' || activeLayer === 'wind' || activeLayer === 'aqi') {
      const tempCircle = L.circle([location.latitude, location.longitude], {
        color: activeLayer === 'temp' ? '#f97316' : activeLayer === 'wind' ? '#06b6d4' : '#10b981',
        fillColor: activeLayer === 'temp' ? '#f97316' : activeLayer === 'wind' ? '#06b6d4' : '#10b981',
        fillOpacity: 0.15,
        radius: 75000,
        weight: 1.5,
      });
      layerGroupRef.current.addLayer(tempCircle);
    }

    // Severe Warning Zones
    if (weatherData?.alerts && weatherData.alerts.length > 0) {
      weatherData.alerts.forEach((alert) => {
        const circle = L.circle([location.latitude, location.longitude], {
          color: alert.severity === 'extreme' ? '#ef4444' : '#f59e0b',
          fillColor: alert.severity === 'extreme' ? '#ef4444' : '#f59e0b',
          fillOpacity: 0.22,
          radius: alert.severity === 'extreme' ? 65000 : 35000,
          weight: 2,
          dashArray: '5, 8',
        });
        circle.bindPopup(`<strong class="text-red-600">${alert.title}</strong><br/>${alert.description}`);
        layerGroupRef.current?.addLayer(circle);
      });
    }
  }, [activeLayer, timelineIndex, radarOpacity, weatherData, location]);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapSearchQuery.trim()) return;
    setIsSearching(true);
    try {
      const results = await api.searchLocations(mapSearchQuery);
      setSearchResults(results);
      if (results.length > 0) {
        setLocation(results[0]);
        setSearchResults([]);
        setMapSearchQuery('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-3 h-[calc(100vh-7.5rem)] flex flex-col pb-1">
      
      {/* Top Map Control & GIS Layer Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-slate-900/90 border border-slate-800 p-2.5 rounded-2xl shadow-xl">
        
        {/* Layer Switcher Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400 px-1.5 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-cyan-400" /> GIS:
          </span>

          <button
            onClick={() => setActiveLayer('precipitation')}
            className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeLayer === 'precipitation'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <CloudRain className="w-3.5 h-3.5" />
            <span>Doppler Radar</span>
          </button>

          <button
            onClick={() => setActiveLayer('satellite')}
            className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeLayer === 'satellite'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Infrared Satellite</span>
          </button>

          <button
            onClick={() => setActiveLayer('wind')}
            className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeLayer === 'wind'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            <span>Wind Vectors</span>
          </button>

          <button
            onClick={() => setActiveLayer('temp')}
            className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeLayer === 'temp'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>Thermal Contours</span>
          </button>
        </div>

        {/* Map City Search */}
        <form onSubmit={handleSearchSubmit} className="relative flex items-center min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
          <input
            type="text"
            value={mapSearchQuery}
            onChange={(e) => setMapSearchQuery(e.target.value)}
            placeholder="Search location on map..."
            className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 text-xs text-slate-100 placeholder-slate-500 rounded-xl pl-9 pr-8 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
          {isSearching && <Loader2 className="w-4 h-4 text-cyan-400 animate-spin absolute right-3" />}
        </form>

      </div>

      {/* Main Map Container */}
      <div className="flex-1 relative rounded-3xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950 flex flex-col justify-end">
        <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-10" />

        {/* Floating Location HUD Badge */}
        <div className="absolute top-4 left-4 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3 text-xs text-slate-100 shadow-xl max-w-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-bold text-sm text-cyan-300 truncate">{location.name}</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 font-mono font-bold">
              ECMWF GIS
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-300">
            <span>Temp: <strong className="text-white">{weatherData?.current ? formatTemp(weatherData.current.temperature, tempUnit) : '--'}</strong></span>
            <span>Wind: <strong className="text-white">{weatherData?.current ? Math.round(weatherData.current.windSpeed) + ' km/h' : '--'}</strong></span>
          </div>

          <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-1">
            Click anywhere on the map to inspect live atmospheric parameters.
          </div>
        </div>

        {/* Doppler Timeline Playback Controller (Floating Bottom Bar) */}
        <div className="relative z-20 m-3 p-3 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl space-y-2 max-w-2xl mx-auto w-[calc(100%-1.5rem)]">
          <div className="flex items-center justify-between gap-3">
            
            {/* Play/Pause & Step Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`p-2 rounded-xl text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
                  isPlaying 
                    ? 'bg-amber-400 hover:bg-amber-300 shadow-amber-400/20' 
                    : 'bg-cyan-400 hover:bg-cyan-300 shadow-cyan-400/20'
                }`}
                title={isPlaying ? 'Pause radar loop' : 'Play Doppler radar sequence'}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlaying ? 'Pause' : 'Play Loop'}</span>
              </button>

              <button
                onClick={() => setTimelineIndex(5)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                title="Reset to Live Now"
              >
                <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Live</span>
              </button>
            </div>

            {/* Current Active Timestamp Display */}
            <div className="text-center">
              <span className={`text-xs font-black uppercase px-2.5 py-1 rounded-full ${
                RADAR_TIMESTAMPS[timelineIndex]?.isLive 
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' 
                  : RADAR_TIMESTAMPS[timelineIndex]?.isForecast
                  ? 'bg-purple-950 text-purple-300 border border-purple-500/40'
                  : 'bg-slate-800 text-slate-300'
              }`}>
                {RADAR_TIMESTAMPS[timelineIndex]?.label}
              </span>
            </div>

            {/* Radar Opacity Slider */}
            <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-400">
              <Sliders className="w-3 h-3 text-cyan-400" />
              <span>Opacity</span>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.05"
                value={radarOpacity}
                onChange={(e) => setRadarOpacity(parseFloat(e.target.value))}
                className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

          </div>

          {/* Timeline Step Buttons Bar */}
          <div className="grid grid-cols-7 gap-1 pt-1">
            {RADAR_TIMESTAMPS.map((ts, idx) => (
              <button
                key={ts.id}
                onClick={() => {
                  setTimelineIndex(idx);
                  setIsPlaying(false);
                }}
                className={`py-1 rounded-lg text-[10px] font-bold transition-all ${
                  timelineIndex === idx
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
                }`}
              >
                {ts.label}
              </button>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
};
