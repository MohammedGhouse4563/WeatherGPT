import React, { useState } from 'react';
import { 
  Settings, 
  User, 
  Globe, 
  Bell, 
  Sliders, 
  MapPin, 
  ShieldCheck, 
  LogOut, 
  Check, 
  Trash2, 
  Sparkles,
  Smartphone,
  Info
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useAuth } from '../context/AuthContext';
import { SUPPORTED_LANGUAGES, useTranslation } from '../utils/i18n';
import { api } from '../services/api';

export const SettingsPage: React.FC = () => {
  const { 
    tempUnit, 
    setTempUnit, 
    windUnit, 
    setWindUnit, 
    language, 
    setLanguage, 
    favorites, 
    removeFavorite,
    location,
    setLocation 
  } = useWeather();
  const { user, logout } = useAuth();
  const { t } = useTranslation(language);

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [severeAlertsToggle, setSevereAlertsToggle] = useState(true);
  const [dailyBriefToggle, setDailyBriefToggle] = useState(true);
  const [agriAlertsToggle, setAgriAlertsToggle] = useState(true);

  const handleSavePreferences = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-cyan-400" />
          Settings & Personalization
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure meteorological units, language preferences, notification thresholds, and favorite locations
        </p>
      </div>

      {/* User Account Profile */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <User className="w-4 h-4 text-cyan-400" />
            User Profile
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/80">
            Authenticated
          </span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white font-black text-lg shadow-md shadow-cyan-500/20">
              {user?.name ? user.name[0].toUpperCase() : 'U'}
            </div>
            <div>
              <div className="text-sm font-bold text-slate-100">{user?.name || 'Meteorological User'}</div>
              <div className="text-xs text-slate-400">{user?.email || 'user@weathergpt.ai'}</div>
            </div>
          </div>

          <button
            onClick={logout}
            className="px-4 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-800/80 text-red-300 text-xs font-bold flex items-center gap-2 transition-colors self-start sm:self-auto"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Meteorological Units Configuration */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-5">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          Atmospheric Units of Measurement
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Temperature Scale */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">
              Temperature Unit
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setTempUnit('celsius')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  tempUnit === 'celsius'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                Celsius (°C)
              </button>
              <button
                onClick={() => setTempUnit('fahrenheit')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  tempUnit === 'fahrenheit'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                Fahrenheit (°F)
              </button>
            </div>
          </div>

          {/* Wind Speed Scale */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">
              Wind Velocity Unit
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setWindUnit('kmh')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  windUnit === 'kmh'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                Kilometers/hr (km/h)
              </button>
              <button
                onClick={() => setWindUnit('mph')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  windUnit === 'mph'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                Miles/hr (mph)
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Language Preference */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-400" />
          Conversational Language (Indian & Global)
        </span>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {SUPPORTED_LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLanguage(l.code as any)}
              className={`p-3 rounded-2xl border text-left transition-all ${
                language === l.code
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-950/40'
                  : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:border-slate-600'
              }`}
            >
              <div className="text-xs font-bold">{l.nativeName}</div>
              <div className="text-[10px] text-slate-400">{l.name}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Weather Alerts & Push Notifications */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <Bell className="w-4 h-4 text-cyan-400" />
          Alert Thresholds & Push Dispatch
        </span>

        <div className="divide-y divide-slate-800 text-xs">
          
          <div className="py-3 flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-100">Severe Weather & Gale Wind Warnings</div>
              <div className="text-[11px] text-slate-400">Push notifications on Red / Orange meteorological events</div>
            </div>
            <input
              type="checkbox"
              checked={severeAlertsToggle}
              onChange={(e) => setSevereAlertsToggle(e.target.checked)}
              className="w-4 h-4 accent-cyan-500 cursor-pointer"
            />
          </div>

          <div className="py-3 flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-100">Daily Morning Forecast Briefing</div>
              <div className="text-[11px] text-slate-400">Receive 7:00 AM summary of temperature and precipitation probability</div>
            </div>
            <input
              type="checkbox"
              checked={dailyBriefToggle}
              onChange={(e) => setDailyBriefToggle(e.target.checked)}
              className="w-4 h-4 accent-cyan-500 cursor-pointer"
            />
          </div>

          <div className="py-3 flex items-center justify-between">
            <div>
              <div className="font-semibold text-slate-100">Crop & Agronomic Spray Alerts</div>
              <div className="text-[11px] text-slate-400">Notify optimal pesticide spray and irrigation windows</div>
            </div>
            <input
              type="checkbox"
              checked={agriAlertsToggle}
              onChange={(e) => setAgriAlertsToggle(e.target.checked)}
              className="w-4 h-4 accent-cyan-500 cursor-pointer"
            />
          </div>

        </div>
      </div>

      {/* Saved Locations / Favorites */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-cyan-400" />
          Favorite Weather Locations
        </span>

        {favorites.length === 0 ? (
          <p className="text-xs text-slate-400">No favorite locations pinned yet. Click the star icon next to search to pin cities.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {favorites.map((fav) => (
              <div
                key={fav.name}
                className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between text-xs"
              >
                <div 
                  onClick={() => setLocation(fav)}
                  className="cursor-pointer hover:text-cyan-300 font-semibold text-slate-200 truncate pr-2"
                >
                  {fav.name}, {fav.country}
                </div>

                <button
                  onClick={() => removeFavorite(fav.name)}
                  className="text-slate-400 hover:text-red-400 p-1"
                  title="Remove"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Meteorological Data Infrastructure Notice */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 space-y-1">
        <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
          <ShieldCheck className="w-4 h-4" />
          <span>Real-time Grounding & Zero Hallucination Guarantee</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          WeatherGPT connects directly to global Numerical Weather Prediction (ECMWF, GFS, DWD ICON) and satellite radar streams. AI responses are strictly validated against verified atmospheric observations.
        </p>
      </div>

    </div>
  );
};
