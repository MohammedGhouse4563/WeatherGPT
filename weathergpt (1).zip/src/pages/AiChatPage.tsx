import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Mic, 
  MicOff, 
  Sparkles, 
  Bot, 
  User, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Loader2, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  Calendar, 
  Trash2, 
  Plus,
  MessageSquare,
  Copy,
  Check,
  ChevronRight
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { ChatMessage, ChatConversation } from '../types';
import { SUPPORTED_LANGUAGES, useTranslation } from '../utils/i18n';

interface AiChatPageProps {
  initialQuery?: string;
  onOpenVoiceModal: () => void;
}

export const AiChatPage: React.FC<AiChatPageProps> = ({ initialQuery, onOpenVoiceModal }) => {
  const { location, language, setLanguage } = useWeather();
  const { user } = useAuth();
  const { t } = useTranslation(language);

  const [inputQuery, setInputQuery] = useState(initialQuery || '');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string>('');
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isGenerating]);

  // Load conversations on mount
  useEffect(() => {
    async function loadConvs() {
      if (user) {
        try {
          const list = await api.getConversations();
          setConversations(list);
          if (list.length > 0 && !activeConvId) {
            setActiveConvId(list[0].id);
            setMessages(list[0].messages);
          } else if (list.length === 0) {
            startNewChat();
          }
        } catch (err) {
          console.warn('Failed to load chat history:', err);
          startNewChat();
        }
      } else {
        startNewChat();
      }
    }
    loadConvs();
  }, [user]);

  // Handle initialQuery passed from dashboard
  useEffect(() => {
    if (initialQuery && initialQuery.trim().length > 0) {
      handleSendMessage(initialQuery);
    }
  }, [initialQuery]);

  const startNewChat = () => {
    const newId = 'conv_' + Date.now();
    const initialAssistantMsg: ChatMessage = {
      id: 'msg_welcome_' + Date.now(),
      sender: 'assistant',
      content: `Hello ${user?.name || 'there'}! I am **WeatherGPT**, your meteorological conversational intelligence assistant. 

I can answer any weather forecast, severe alerts, travel safety, or agricultural inquiries for **${location.name}** and locations worldwide—grounded strictly in real-time verified ECMWF/GFS meteorological datasets.

How can I assist your meteorological planning today?`,
      timestamp: new Date().toISOString(),
      groundingData: {
        locationName: `${location.name}, ${location.country}`,
        dataSource: 'Open-Meteo Global NWP Integration',
        updatedAt: new Date().toISOString(),
      },
    };

    setActiveConvId(newId);
    setMessages([initialAssistantMsg]);

    const newConv: ChatConversation = {
      id: newId,
      title: 'New Meteorological Query',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [initialAssistantMsg],
      language,
    };

    setConversations(prev => [newConv, ...prev.filter(c => c.id !== newId)]);
  };

  const handleSendMessage = async (queryToSend?: string) => {
    const q = queryToSend || inputQuery;
    if (!q || !q.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      id: 'msg_user_' + Date.now(),
      sender: 'user',
      content: q.trim(),
      timestamp: new Date().toISOString(),
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInputQuery('');
    setIsGenerating(true);

    try {
      const historyContext = updatedMessages.slice(-5).map(m => ({
        sender: m.sender,
        content: m.content,
      }));

      const res = await api.sendChatMessage({
        query: q.trim(),
        defaultLocation: location,
        language,
        conversationHistory: historyContext,
      });

      const assistantMessage: ChatMessage = {
        id: 'msg_asst_' + Date.now(),
        sender: 'assistant',
        content: res.response,
        timestamp: new Date().toISOString(),
        groundingData: res.groundingData,
      };

      const finalMessages = [...updatedMessages, assistantMessage];
      setMessages(finalMessages);

      // Persist conversation
      if (activeConvId) {
        const convToSave: ChatConversation = {
          id: activeConvId,
          title: q.slice(0, 32) + (q.length > 32 ? '...' : ''),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: finalMessages,
          language,
        };

        setConversations(prev => [convToSave, ...prev.filter(c => c.id !== activeConvId)]);
        if (user) {
          api.saveConversation(convToSave).catch(e => console.warn(e));
        }
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: 'msg_err_' + Date.now(),
        sender: 'assistant',
        content: '⚠️ Unable to process query with real meteorological feed. ' + (err.message || 'Please check connectivity and retry.'),
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSpeechSpeak = (msgId: string, text: string) => {
    if (!synthRef.current) return;
    if (speakingMsgId === msgId) {
      synthRef.current.cancel();
      setSpeakingMsgId(null);
      return;
    }

    synthRef.current.cancel();
    const clean = text.replace(/[*#_`]/g, '').slice(0, 400);
    const utterance = new SpeechSynthesisUtterance(clean);
    
    // Set appropriate locale
    const localeMap: Record<string, string> = {
      ta: 'ta-IN', hi: 'hi-IN', te: 'te-IN', kn: 'kn-IN', ml: 'ml-IN', bn: 'bn-IN', mr: 'mr-IN', en: 'en-IN'
    };
    utterance.lang = localeMap[language] || 'en-IN';

    utterance.onstart = () => setSpeakingMsgId(msgId);
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    synthRef.current.speak(utterance);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDeleteConversation = async (convId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConversations(prev => prev.filter(c => c.id !== convId));
    if (activeConvId === convId) {
      startNewChat();
    }
    if (user) {
      api.deleteConversation(convId).catch(e => console.warn(e));
    }
  };

  const SUGGESTED_PROMPTS = [
    `Will it rain in ${location.name} in the next 12 hours?`,
    `What will the temperature and humidity be tomorrow?`,
    `Are there any severe cyclonic or gale wind warnings active?`,
    `Provide agriculture spray advisory for paddy crops today.`,
    `Compare current weather of Chennai and Bengaluru.`,
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-8rem)] pb-4">
      
      {/* Sidebar: Conversation History */}
      <div className="hidden lg:flex flex-col w-72 bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden p-3 space-y-3">
        <button
          onClick={startNewChat}
          className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Meteorological Query</span>
        </button>

        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2">
          Past Inquiries
        </div>

        <div className="flex-1 overflow-y-auto space-y-1 pr-1">
          {conversations.map((c) => (
            <div
              key={c.id}
              onClick={() => {
                setActiveConvId(c.id);
                setMessages(c.messages);
              }}
              className={`p-2.5 rounded-xl text-xs flex items-center justify-between cursor-pointer group transition-all ${
                activeConvId === c.id
                  ? 'bg-cyan-950/60 border border-cyan-500/40 text-cyan-300'
                  : 'hover:bg-slate-800 text-slate-300 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span className="truncate">{c.title || 'Meteorological Query'}</span>
              </div>

              <button
                onClick={(e) => handleDeleteConversation(c.id, e)}
                className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 p-1 rounded transition-opacity"
                title="Delete"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Main Chat Workspace */}
      <div className="flex-1 flex flex-col bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        
        {/* Chat Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 backdrop-blur-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-bold text-slate-100">WeatherGPT AI Assistant</h3>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  Grounded ECMWF
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Targeting: <strong className="text-slate-200">{location.name}</strong> • Language: <strong className="text-cyan-400 uppercase">{language}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-cyan-500"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName}
                </option>
              ))}
            </select>

            <button
              onClick={startNewChat}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
              title="New Chat"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-md shadow-cyan-500/20 mt-1">
                    <Sparkles className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-2xl rounded-2xl p-4 text-xs sm:text-sm leading-relaxed space-y-3 ${
                    isUser
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-900/30'
                      : 'bg-slate-800/80 border border-slate-700/80 text-slate-100 shadow-lg'
                  }`}
                >
                  <div className="whitespace-pre-line prose prose-invert max-w-none text-xs sm:text-sm">
                    {msg.content}
                  </div>

                  {/* Assistant Grounding Badge & Audio Controls */}
                  {!isUser && msg.groundingData && (
                    <div className="pt-2 border-t border-slate-700/60 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                      <div className="flex items-center gap-1.5 text-cyan-300">
                        <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Source: {msg.groundingData.dataSource || 'Global Met Integration'}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopyText(msg.id, msg.content)}
                          className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-slate-200"
                          title="Copy text"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          onClick={() => handleSpeechSpeak(msg.id, msg.content)}
                          className={`p-1 rounded hover:bg-slate-700 flex items-center gap-1 ${
                            speakingMsgId === msg.id ? 'text-red-400' : 'text-slate-400 hover:text-cyan-300'
                          }`}
                          title="Listen with voice TTS"
                        >
                          {speakingMsgId === msg.id ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-700 border border-slate-600 text-cyan-400 flex items-center justify-center flex-shrink-0 mt-1 font-bold text-xs">
                    {user?.name ? user.name[0].toUpperCase() : 'U'}
                  </div>
                )}
              </div>
            );
          })}

          {isGenerating && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center flex-shrink-0 animate-pulse">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="bg-slate-800/80 border border-cyan-500/30 rounded-2xl px-4 py-3 text-xs text-cyan-300 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                <span>Grounded Meteorological AI is synthesizing forecast data...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompt Chips (when few messages) */}
        {messages.length <= 2 && (
          <div className="px-4 py-2 border-t border-slate-800 bg-slate-900/40 flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap">
              Suggestions:
            </span>
            {SUGGESTED_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(prompt)}
                className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-cyan-300 text-xs whitespace-nowrap transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        {/* Input Bar */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-900/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={onOpenVoiceModal}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 hover:border-cyan-500/40 transition-colors"
              title="Voice Input"
            >
              <Mic className="w-5 h-5" />
            </button>

            <input
              id="input-ai-chat-message"
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={t('askPrompt')}
              disabled={isGenerating}
              className="flex-1 bg-slate-800/80 border border-slate-700 focus:border-cyan-500 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 disabled:opacity-50"
            />

            <button
              id="btn-ai-chat-send"
              type="submit"
              disabled={!inputQuery.trim() || isGenerating}
              className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold shadow-lg shadow-cyan-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
