import React from 'react';
import { 
  AlertOctagon, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Wind, 
  Droplets, 
  Flame, 
  CloudLightning, 
  Clock, 
  MapPin, 
  Radio, 
  PhoneCall, 
  ExternalLink,
  Info
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useTranslation } from '../utils/i18n';

interface AlertsPageProps {
  onNavigateToDisaster: () => void;
}

export const AlertsPage: React.FC<AlertsPageProps> = ({ onNavigateToDisaster }) => {
  const { location, alerts, weatherData, language } = useWeather();
  const { t } = useTranslation(language);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <AlertOctagon className="w-6 h-6 text-red-400" />
              Severe Weather Warnings & Alerts Center
            </h1>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-red-950 text-red-400 border border-red-800/80 animate-pulse">
              Active Monitoring
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time threshold triggers & CAP alert integration for {location.name}, {location.country}
          </p>
        </div>

        <button
          onClick={onNavigateToDisaster}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <PhoneCall className="w-4 h-4 text-cyan-400" />
          <span>Emergency Hotlines & Guidelines</span>
        </button>
      </div>

      {/* Active Warnings Section */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
          <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          Current Location Threat Assessment ({location.name})
        </h2>

        {alerts.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-100">No Active Severe Warnings</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
              Atmospheric parameters (wind speed {weatherData?.current ? Math.round(weatherData.current.windSpeed) : 0} km/h, precipitation, and thermal index) are within normal baseline thresholds for {location.name}.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {alerts.map((alert) => {
              const isExtreme = alert.severity === 'extreme';
              const isSevere = alert.severity === 'severe';

              return (
                <div
                  key={alert.id}
                  className={`p-6 rounded-3xl border transition-all ${
                    isExtreme
                      ? 'bg-gradient-to-br from-red-950/80 via-slate-900 to-rose-950/50 border-red-500/80 shadow-2xl shadow-red-950/40'
                      : isSevere
                      ? 'bg-gradient-to-br from-amber-950/70 via-slate-900 to-orange-950/40 border-amber-500/70 shadow-2xl shadow-amber-950/30'
                      : 'bg-slate-900/90 border-slate-800 text-slate-100'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white ${
                          isExtreme ? 'bg-red-600 animate-pulse' : 'bg-amber-600'
                        }`}
                      >
                        <ShieldAlert className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-white tracking-tight">
                          {alert.title}
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-slate-300 mt-0.5">
                          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{alert.area}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs uppercase font-extrabold px-3 py-1 rounded-full ${
                          isExtreme
                            ? 'bg-red-500 text-white'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        Level: {alert.severity}
                      </span>
                    </div>
                  </div>

                  <div className="py-4 space-y-3 text-xs leading-relaxed text-slate-200">
                    <p className="text-sm font-medium text-slate-100">{alert.description}</p>

                    {alert.recommendedAction && (
                      <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                        <div className="font-bold text-cyan-400 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          Recommended Meteorological Safety Action
                        </div>
                        <p className="text-xs text-slate-200">{alert.recommendedAction}</p>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>Valid until: {new Date(alert.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', weekday: 'short' })}</span>
                    </div>
                    <div>Source: <strong>{alert.source}</strong></div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Severity Scale Reference Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          Official Meteorological Warning Severity Tiers (IMD / WMO)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/60 space-y-1">
            <div className="flex items-center gap-2 text-red-400 font-bold">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span>Red Alert (Extreme)</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Take immediate protective action. High threat to life and infrastructure from severe cyclones, flash floods, or extreme heat.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-800/60 space-y-1">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <span>Orange Alert (Severe)</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Be prepared. Significant disruptions likely from gale winds, heavy rains, or severe thunderstorms.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-yellow-950/30 border border-yellow-800/60 space-y-1">
            <div className="flex items-center gap-2 text-yellow-400 font-bold">
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <span>Yellow Alert (Watch)</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Be aware. Potentially adverse weather in progression. Monitor updates regularly.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-800/60 space-y-1">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span>Green (No Warning)</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Atmosphere stable. Standard routine weather expected.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
