import React, { useState } from 'react';
import { 
  Sun, 
  Moon, 
  CloudRain, 
  Wind, 
  Droplets, 
  Eye, 
  Compass, 
  Gauge, 
  Sunrise, 
  Sunset, 
  Sparkles, 
  AlertTriangle, 
  ArrowUp, 
  ArrowDown, 
  CloudSun, 
  Mic, 
  RefreshCw, 
  Send,
  Loader2,
  Calendar,
  ShieldAlert,
  ChevronRight,
  Activity,
  Zap,
  Info,
  ThermometerSun,
  Flame,
  CloudFog,
  TrendingDown,
  TrendingUp,
  MoonStar,
  Printer,
  Route,
  Scale
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { formatTemp, formatWindSpeed, getWindDirectionName, getUVLevel } from '../utils/weatherCodes';
import { useTranslation } from '../utils/i18n';
import { 
  calculateDewPoint, 
  calculateWBGT, 
  calculateCloudCeiling, 
  calculateBarometricTendency, 
  calculateMoonPhase, 
  estimateSolarIrradiance 
} from '../utils/meteorology';

interface DashboardPageProps {
  onNavigate: (tab: string, query?: string) => void;
  onOpenVoice: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, onOpenVoice }) => {
  const { 
    location, 
    weatherData, 
    loading, 
    error, 
    tempUnit, 
    windUnit, 
    language,
    refreshWeather,
    alerts 
  } = useWeather();
  const { t } = useTranslation(language);

  const [quickQuery, setQuickQuery] = useState('');

  const handleQuickAsk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickQuery.trim()) return;
    onNavigate('chat', quickQuery);
  };

  if (loading && !weatherData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
          <CloudSun className="w-8 h-8 text-cyan-400 absolute inset-0 m-auto" />
        </div>
        <div className="text-center">
          <p className="text-sm font-bold text-slate-100">Fetching Live Meteorological Observations...</p>
          <p className="text-xs text-slate-400 mt-1">Connecting to ECMWF / GFS Global Weather Ensemble</p>
        </div>
      </div>
    );
  }

  if (error && !weatherData) {
    return (
      <div className="p-6 bg-red-950/40 border border-red-800/80 rounded-2xl text-center space-y-3 max-w-lg mx-auto mt-12">
        <AlertTriangle className="w-10 h-10 text-red-400 mx-auto" />
        <h3 className="text-base font-bold text-red-200">Meteorological Data Unavailable</h3>
        <p className="text-xs text-slate-300">{error}</p>
        <button
          onClick={refreshWeather}
          className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors"
        >
          Retry Meteorological Feed
        </button>
      </div>
    );
  }

  const cur = weatherData?.current;
  const todayDaily = weatherData?.daily?.[0];
  const aqi = weatherData?.airQuality;
  const uvInfo = cur ? getUVLevel(cur.uvIndex) : { label: 'Low', color: 'text-emerald-400' };

  // Calculate Advanced Meteorological Values
  const tempC = cur?.temperature || 25;
  const humidity = cur?.relativeHumidity || 50;
  const dewPointC = calculateDewPoint(tempC, humidity);
  const wbgtResult = calculateWBGT(tempC, humidity, cur?.windSpeed || 5);
  const cloudCeiling = calculateCloudCeiling(tempC, dewPointC);
  
  const hourlyPressures = weatherData?.hourly.slice(0, 5).map(h => h.pressureMsl || 1013);
  const pressureTendency = calculateBarometricTendency(hourlyPressures);
  
  const moonPhase = calculateMoonPhase();
  const solarFlux = estimateSolarIrradiance(cur?.cloudCover || 20, cur?.isDay || true, cur?.uvIndex || 3);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Active Severe Alert Banner (if any) */}
      {alerts && alerts.length > 0 && (
        <div 
          onClick={() => onNavigate('alerts')}
          className="p-4 rounded-2xl bg-gradient-to-r from-red-950/80 via-rose-950/60 to-slate-900 border border-red-500/50 shadow-lg shadow-red-950/30 flex items-center justify-between cursor-pointer group hover:border-red-400 transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center animate-pulse">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-red-200 uppercase tracking-wide">
                  {alerts[0].title}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-red-500 text-white font-bold uppercase">
                  {alerts[0].severity}
                </span>
              </div>
              <p className="text-xs text-slate-300 line-clamp-1 mt-0.5">
                {alerts[0].description}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs font-semibold text-red-400 group-hover:translate-x-1 transition-transform">
            <span>View Safety Protocols</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      )}

      {/* Quick AI WeatherGPT Search & Bar */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800/80 to-cyan-950/40 border border-slate-700/80 shadow-xl">
        <form onSubmit={handleQuickAsk} className="flex flex-col sm:flex-row items-center gap-3">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs whitespace-nowrap">
            <Sparkles className="w-4 h-4" />
            <span>Ask WeatherGPT:</span>
          </div>

          <div className="flex-1 w-full relative">
            <input
              id="input-dashboard-ai-query"
              type="text"
              value={quickQuery}
              onChange={(e) => setQuickQuery(e.target.value)}
              placeholder={`"Will it rain in ${location.name} this evening?", "What should I wear today?", "Is it safe to spray pesticides?"`}
              className="w-full bg-slate-950/70 border border-slate-700 focus:border-cyan-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onOpenVoice}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 flex items-center gap-1 text-xs font-semibold"
              title="Voice Assistant"
            >
              <Mic className="w-4 h-4" />
              <span className="hidden md:inline">Voice</span>
            </button>

            <button
              id="btn-dashboard-ask-submit"
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
            >
              <span>Ask AI</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>

      {/* Main Dynamic Hero Card */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-cyan-950/60 border border-slate-700/80 shadow-2xl p-5 sm:p-7">
        
        {/* Subtle Ambient Light Gradients */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* Location & Primary Temperature */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800/60">
                Live Met Grounding
              </span>
              <span className="text-xs text-slate-400">
                {weatherData?.updatedAt ? new Date(weatherData.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
              </span>
            </div>

            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                {location.name}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                {location.admin1 ? `${location.admin1}, ` : ''}{location.country}
              </p>
            </div>

            <div className="flex items-baseline gap-4 pt-1">
              <div className="text-5xl sm:text-7xl font-black text-white tracking-tighter">
                {cur ? formatTemp(cur.temperature, tempUnit) : '--°'}
              </div>
              <div className="space-y-0.5">
                <div className="text-sm sm:text-base font-semibold text-cyan-300">
                  {cur?.weatherDescription || 'Fair Sky'}
                </div>
                <div className="text-xs text-slate-400">
                  {t('feelsLike')} {cur ? formatTemp(cur.apparentTemperature, tempUnit) : '--°'}
                </div>
                {todayDaily && (
                  <div className="flex items-center gap-2 text-xs text-slate-300 pt-0.5 font-medium">
                    <span className="flex items-center text-rose-400">
                      <ArrowUp className="w-3 h-3 mr-0.5" /> {formatTemp(todayDaily.tempMax, tempUnit)}
                    </span>
                    <span>•</span>
                    <span className="flex items-center text-cyan-400">
                      <ArrowDown className="w-3 h-3 mr-0.5" /> {formatTemp(todayDaily.tempMin, tempUnit)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Metrics Badge Cluster */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            
            {/* Wind */}
            <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 backdrop-blur-sm space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                <Wind className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t('windSpeed')}</span>
              </div>
              <div className="text-sm sm:text-base font-bold text-slate-100">
                {cur ? formatWindSpeed(cur.windSpeed, windUnit) : '--'}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                {cur ? `${getWindDirectionName(cur.windDirection)} (${cur.windDirection}°)` : '--'}
              </div>
            </div>

            {/* Humidity */}
            <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 backdrop-blur-sm space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                <Droplets className="w-3.5 h-3.5 text-sky-400" />
                <span>{t('humidity')}</span>
              </div>
              <div className="text-sm sm:text-base font-bold text-slate-100">
                {cur ? `${cur.relativeHumidity}%` : '--'}
              </div>
              <div className="text-[11px] text-slate-400">
                Rain: {todayDaily ? `${todayDaily.precipitationProbabilityMax}%` : '0%'}
              </div>
            </div>

            {/* UV Index */}
            <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 backdrop-blur-sm space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>{t('uvIndex')}</span>
              </div>
              <div className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-1.5">
                <span>{cur ? cur.uvIndex.toFixed(1) : '--'}</span>
                <span className={`text-[10px] font-semibold ${uvInfo.color}`}>
                  ({uvInfo.label})
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                Max: {todayDaily ? todayDaily.uvIndexMax.toFixed(1) : '--'}
              </div>
            </div>

            {/* Air Quality */}
            <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 backdrop-blur-sm space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>AQI (US)</span>
              </div>
              <div className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-1.5">
                <span>{aqi ? aqi.usAqi : '--'}</span>
                <span className={`text-[10px] font-semibold ${
                  (aqi?.usAqi || 0) <= 50 ? 'text-emerald-400' : (aqi?.usAqi || 0) <= 100 ? 'text-yellow-400' : 'text-orange-400'
                }`}>
                  ({aqi?.status || 'Good'})
                </span>
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                PM2.5: {aqi ? `${aqi.pm2_5} µg/m³` : '--'}
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* ADVANCED METEOROLOGY & HEAT STRESS HUD (New Advanced Section) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-cyan-400" />
              Advanced Meteorological Diagnostics & Ephemeris
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono font-bold">
              Magnus & WBGT
            </span>
          </div>

          <button
            onClick={() => window.print()}
            className="text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export Dossier</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          
          {/* 1. Dew Point & Condensation Spread */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <ThermometerSun className="w-4 h-4 text-sky-400" /> Dew Point
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Magnus-Tetens</span>
            </div>
            <div className="text-2xl font-black text-white">
              {formatTemp(dewPointC, tempUnit)}
            </div>
            <div className="text-[11px] text-slate-300 leading-snug">
              Spread: <strong className="text-cyan-300">{Math.round(Math.abs(tempC - dewPointC) * 10) / 10}°C</strong>. 
              {Math.abs(tempC - dewPointC) < 3 ? ' Near saturation fog risk.' : ' Dry air boundary.'}
            </div>
          </div>

          {/* 2. WBGT Heat Stress Index */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-400" /> WBGT Heat Stress
              </span>
              <span className={`text-[10px] font-bold ${wbgtResult.category.color}`}>
                {wbgtResult.category.level}
              </span>
            </div>
            <div className="text-2xl font-black text-white">
              {wbgtResult.wbgt}°C
            </div>
            <div className="text-[11px] text-slate-300 leading-snug truncate">
              {wbgtResult.category.advice}
            </div>
          </div>

          {/* 3. Barometric Tendency (3h Delta P) */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-purple-400" /> 3h Pressure Tendency
              </span>
              <span className="text-[10px] font-mono text-purple-300">
                {pressureTendency.delta3h > 0 ? `+${pressureTendency.delta3h}` : pressureTendency.delta3h} hPa
              </span>
            </div>
            <div className="text-base font-bold text-white flex items-center gap-1.5">
              {pressureTendency.delta3h < 0 ? (
                <TrendingDown className="w-4 h-4 text-rose-400" />
              ) : (
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              )}
              <span>{pressureTendency.label}</span>
            </div>
            <div className="text-[11px] text-slate-300 leading-snug line-clamp-1">
              {pressureTendency.interpretation}
            </div>
          </div>

          {/* 4. Lunar Ephemeris & Moon Phase */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <MoonStar className="w-4 h-4 text-indigo-400" /> Lunar Phase
              </span>
              <span className="text-[10px] font-mono text-indigo-300">
                {moonPhase.illumination}% Illum
              </span>
            </div>
            <div className="text-base font-bold text-white truncate">
              {moonPhase.phaseName}
            </div>
            <div className="text-[11px] text-slate-300 leading-snug">
              Full moon in ~{moonPhase.nextFullMoonDays} days. Age: {moonPhase.ageDays}d.
            </div>
          </div>

        </div>
      </div>

      {/* 24-Hour Hourly Forecast Carousel */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200">
              {t('hourlyForecast')}
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">Next 24 Hours</span>
          </div>

          <button
            onClick={() => onNavigate('forecast')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
          >
            <span>Detailed Charts</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-700">
          {weatherData?.hourly.slice(0, 24).map((hour, idx) => {
            const timeDate = new Date(hour.time);
            const hourFormatted = timeDate.toLocaleTimeString([], { hour: 'numeric', hour12: true });

            return (
              <div
                key={hour.time}
                className={`flex-shrink-0 w-24 p-3 rounded-2xl text-center space-y-2 border transition-all ${
                  idx === 0
                    ? 'bg-gradient-to-b from-cyan-950/60 to-slate-900 border-cyan-500/50 shadow-md shadow-cyan-950/40'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="text-[11px] font-semibold text-slate-300">
                  {idx === 0 ? 'Now' : hourFormatted}
                </div>

                <div className="flex justify-center text-cyan-300 py-0.5">
                  {hour.isDay ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-300" />}
                </div>

                <div className="text-sm font-bold text-white">
                  {formatTemp(hour.temperature, tempUnit)}
                </div>

                <div className="flex items-center justify-center gap-1 text-[10px] font-medium text-sky-400">
                  <Droplets className="w-3 h-3" />
                  <span>{hour.precipitationProbability}%</span>
                </div>

                <div className="text-[9px] text-slate-400 truncate">
                  {formatWindSpeed(hour.windSpeed, windUnit)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2-Column Section: 7-Day Outlook & Meteorological Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: 7-Day Forecast */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" />
              {t('sevenDayForecast')}
            </h2>
            <span className="text-[11px] text-slate-400">High / Low Temperature Range</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 divide-y divide-slate-800/80">
            {weatherData?.daily.slice(0, 7).map((day, idx) => {
              const dayDate = new Date(day.date);
              const dayName = idx === 0 ? 'Today' : dayDate.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

              return (
                <div
                  key={day.date}
                  className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="w-28 font-medium text-slate-200">
                    {dayName}
                  </div>

                  <div className="flex items-center gap-2 flex-1 justify-start">
                    <Sun className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span className="text-slate-300 font-medium truncate max-w-[140px]">
                      {day.weatherDescription}
                    </span>
                  </div>

                  {/* Precipitation % */}
                  <div className="flex items-center gap-1 text-sky-400 font-medium w-16 justify-center">
                    {day.precipitationProbabilityMax > 15 ? (
                      <>
                        <CloudRain className="w-3.5 h-3.5" />
                        <span>{day.precipitationProbabilityMax}%</span>
                      </>
                    ) : (
                      <span className="text-slate-500 font-mono text-[11px]">0%</span>
                    )}
                  </div>

                  {/* Temperature Bar */}
                  <div className="flex items-center gap-2 w-32 justify-end font-semibold">
                    <span className="text-cyan-400">{formatTemp(day.tempMin, tempUnit)}</span>
                    <div className="w-14 h-1.5 rounded-full bg-slate-800 overflow-hidden flex">
                      <div className="h-full bg-gradient-to-r from-cyan-500 to-rose-500 w-full" />
                    </div>
                    <span className="text-rose-400">{formatTemp(day.tempMax, tempUnit)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Air Quality & Solar Cycle */}
        <div className="space-y-4">
          
          {/* Air Quality Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                Air Quality Index
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
                {aqi?.status || 'Good'}
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-black text-white">
                {aqi ? aqi.usAqi : 45}
              </span>
              <span className="text-xs text-slate-400">
                US AQI Scale (0-500)
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {aqi?.advice || 'Air quality is satisfactory and poses little risk.'}
            </p>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-[11px]">
              <div>
                <span className="text-slate-500 block">PM2.5</span>
                <span className="font-semibold text-slate-200">{aqi ? `${aqi.pm2_5}` : '--'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">PM10</span>
                <span className="font-semibold text-slate-200">{aqi ? `${aqi.pm10}` : '--'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Ozone</span>
                <span className="font-semibold text-slate-200">{aqi ? `${aqi.ozone}` : '--'}</span>
              </div>
            </div>
          </div>

          {/* Astronomical Solar Cycle & Cloud Base */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-amber-400" />
              Sun & Cloud Ceiling
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-2.5">
                <Sunrise className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <div>
                  <span className="text-[10px] text-slate-400 block">{t('sunrise')}</span>
                  <span className="text-xs font-bold text-slate-100">
                    {todayDaily?.sunrise ? new Date(todayDaily.sunrise).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '06:05 AM'}
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-2.5">
                <Sunset className="w-5 h-5 text-orange-400 flex-shrink-0" />
                <div>
                  <span className="text-[10px] text-slate-400 block">{t('sunset')}</span>
                  <span className="text-xs font-bold text-slate-100">
                    {todayDaily?.sunset ? new Date(todayDaily.sunset).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '06:30 PM'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800">
              <span>Cloud Base: <strong className="text-slate-200">{cloudCeiling.meters} m ({cloudCeiling.feet} ft)</strong></span>
              <span>Solar Flux: <strong className="text-slate-200">{solarFlux.irradiance} W/m²</strong></span>
            </div>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onNavigate('trip')}
              className="p-3 rounded-2xl bg-gradient-to-r from-slate-900 to-cyan-950/60 border border-slate-800 hover:border-cyan-500/40 text-left text-xs space-y-1 transition-all group"
            >
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
                <Route className="w-3.5 h-3.5" />
                <span>Trip Planner</span>
              </div>
              <p className="text-[10px] text-slate-400">Route highway hazards</p>
            </button>

            <button
              onClick={() => onNavigate('compare')}
              className="p-3 rounded-2xl bg-gradient-to-r from-slate-900 to-blue-950/60 border border-slate-800 hover:border-blue-500/40 text-left text-xs space-y-1 transition-all group"
            >
              <div className="flex items-center gap-1.5 text-blue-400 font-bold">
                <Scale className="w-3.5 h-3.5" />
                <span>Compare Cities</span>
              </div>
              <p className="text-[10px] text-slate-400">Multi-point weather stats</p>
            </button>
          </div>

        </div>

      </div>

      {/* Meteorological Data Source Grounding Footer Note */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>{weatherData?.source}</span>
        </div>
        <div className="font-mono text-[11px]">
          Latitude: {location.latitude.toFixed(3)}° • Longitude: {location.longitude.toFixed(3)}°
        </div>
      </div>

    </div>
  );
};
