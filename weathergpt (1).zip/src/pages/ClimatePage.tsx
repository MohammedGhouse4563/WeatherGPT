import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  History, 
  Calendar, 
  Thermometer, 
  CloudRain, 
  Droplet, 
  Sun, 
  Loader2, 
  AlertCircle,
  Award,
  BarChart3,
  Layers
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid 
} from 'recharts';
import { useWeather } from '../context/WeatherContext';
import { api } from '../services/api';
import { HistoricalClimateData } from '../types';
import { formatTemp } from '../utils/weatherCodes';

export const ClimatePage: React.FC = () => {
  const { location, tempUnit } = useWeather();
  
  const [years, setYears] = useState<number>(1);
  const [climateData, setClimateData] = useState<HistoricalClimateData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeChart, setActiveChart] = useState<'temp' | 'rain'>('temp');

  useEffect(() => {
    async function loadClimate() {
      setLoading(true);
      setError(null);
      try {
        const data = await api.getHistoricalClimate(location, years);
        setClimateData(data);
      } catch (err: any) {
        console.error('Failed to load historical climate data:', err);
        setError(err.message || 'Unable to retrieve historical climate records');
      } finally {
        setLoading(false);
      }
    }
    loadClimate();
  }, [location, years]);

  const summary = climateData?.summary;

  const chartData = climateData?.timeSeries.map((item) => ({
    date: item.date,
    tempMax: tempUnit === 'fahrenheit' ? Math.round((item.tempMax * 9) / 5 + 32) : Math.round(item.tempMax),
    tempMin: tempUnit === 'fahrenheit' ? Math.round((item.tempMin * 9) / 5 + 32) : Math.round(item.tempMin),
    tempMean: tempUnit === 'fahrenheit' ? Math.round((item.tempMean * 9) / 5 + 32) : Math.round(item.tempMean),
    rain: parseFloat(item.precipitationSum.toFixed(1)),
  })) || [];

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            Historical Climate Trends & Analysis
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            ERA5 Global Atmospheric Reanalysis (1940-Present) for {location.name}
          </p>
        </div>

        {/* Years Selector (1, 5, 10 years) */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs font-semibold">
          {[1, 5, 10].map((y) => (
            <button
              key={y}
              onClick={() => setYears(y)}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                years === y ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {y} {y === 1 ? 'Year' : 'Years'}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[40vh] space-y-3 bg-slate-900/60 border border-slate-800 rounded-3xl p-8">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          <p className="text-xs text-slate-300">Retrieving Historical Meteorological Reanalysis Archive...</p>
        </div>
      ) : error ? (
        <div className="p-6 bg-red-950/40 border border-red-800/80 rounded-2xl text-center space-y-2">
          <AlertCircle className="w-8 h-8 text-red-400 mx-auto" />
          <p className="text-xs text-red-200">{error}</p>
        </div>
      ) : (
        <>
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            
            {/* Avg Temperature */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Thermometer className="w-3.5 h-3.5 text-cyan-400" />
                <span>Mean Temp</span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-white">
                {summary ? formatTemp(summary.avgTemp, tempUnit) : '--'}
              </div>
              <div className="text-[10px] text-slate-400">
                Period Average over {years} yr{years > 1 ? 's' : ''}
              </div>
            </div>

            {/* Total Rainfall */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <CloudRain className="w-3.5 h-3.5 text-sky-400" />
                <span>Total Precipitation</span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-white">
                {summary?.totalRainfall.toLocaleString()} mm
              </div>
              <div className="text-[10px] text-slate-400">
                Wet Days: {summary?.wetDaysCount} • Dry: {summary?.dryDaysCount}
              </div>
            </div>

            {/* All-Time Peak High */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Sun className="w-3.5 h-3.5 text-rose-400" />
                <span>Record Max Temp</span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-rose-400">
                {summary?.maxTempRecord ? formatTemp(summary.maxTempRecord.temp, tempUnit) : '--'}
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                On {summary?.maxTempRecord.date}
              </div>
            </div>

            {/* All-Time Peak Low */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Award className="w-3.5 h-3.5 text-blue-400" />
                <span>Record Min Temp</span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-cyan-400">
                {summary?.minTempRecord ? formatTemp(summary.minTempRecord.temp, tempUnit) : '--'}
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                On {summary?.minTempRecord.date}
              </div>
            </div>

          </div>

          {/* Historical Chart Canvas */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                {activeChart === 'temp' ? 'Thermal Variation History' : 'Precipitation Distribution History'}
              </span>

              <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl text-xs">
                <button
                  onClick={() => setActiveChart('temp')}
                  className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                    activeChart === 'temp' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Temperature History
                </button>
                <button
                  onClick={() => setActiveChart('rain')}
                  className={`px-3 py-1 rounded-lg transition-colors font-medium ${
                    activeChart === 'rain' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Rainfall Distribution
                </button>
              </div>
            </div>

            <div className="h-72 sm:h-80 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                {activeChart === 'temp' ? (
                  <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="histTempGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} unit={`°${tempUnit === 'fahrenheit' ? 'F' : 'C'}`} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                      labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                    />
                    <Area type="monotone" dataKey="tempMax" name="Max Temp" stroke="#f43f5e" strokeWidth={2} fill="url(#histTempGrad)" />
                    <Line type="monotone" dataKey="tempMean" name="Mean Temp" stroke="#38bdf8" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="tempMin" name="Min Temp" stroke="#06b6d4" strokeWidth={1.5} dot={false} />
                  </AreaChart>
                ) : (
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} unit=" mm" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                      labelStyle={{ color: '#38bdf8', fontWeight: 'bold' }}
                    />
                    <Bar dataKey="rain" name="Daily Rainfall (mm)" fill="#0ea5e9" radius={[2, 2, 0, 0]} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}

    </div>
  );
};
