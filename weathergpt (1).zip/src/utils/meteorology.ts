// Advanced Meteorological & Ephemeris Calculations

export interface MoonPhaseInfo {
  phaseName: string;
  illumination: number; // 0 to 100%
  ageDays: number;
  icon: string;
  nextFullMoonDays: number;
  nextNewMoonDays: number;
}

export interface BarometricTendency {
  delta3h: number; // hPa change over 3 hours
  status: 'rapidly_falling' | 'falling' | 'steady' | 'rising' | 'rapidly_rising';
  label: string;
  interpretation: string;
  severity: 'normal' | 'warning' | 'critical';
}

export interface AdvancedDiagnostics {
  dewPoint: number; // °C
  wetBulbGlobeTemp: number; // °C (WBGT Heat Stress)
  heatStressCategory: { level: string; color: string; advice: string };
  cloudCeilingMeters: number; // m
  cloudCeilingFeet: number; // ft
  solarIrradiance: number; // W/m^2
  solarFluxCategory: string;
  barometricTendency: BarometricTendency;
  moonPhase: MoonPhaseInfo;
}

/**
 * Calculates Dew Point using the Magnus-Tetens approximation formula
 */
export function calculateDewPoint(tempC: number, relativeHumidity: number): number {
  const a = 17.27;
  const b = 237.7;
  const rh = Math.max(1, Math.min(100, relativeHumidity));
  const alpha = ((a * tempC) / (b + tempC)) + Math.log(rh / 100);
  const dewPoint = (b * alpha) / (a - alpha);
  return Math.round(dewPoint * 10) / 10;
}

/**
 * Calculates simplified Wet Bulb Globe Temperature (WBGT) index for heat stress
 */
export function calculateWBGT(tempC: number, relativeHumidity: number, windKmh: number = 5): {
  wbgt: number;
  category: { level: string; color: string; advice: string };
} {
  const rh = Math.max(1, Math.min(100, relativeHumidity));
  const e = (rh / 100) * 6.105 * Math.exp((17.27 * tempC) / (237.7 + tempC));
  // Australian Bureau of Meteorology simplified formula: WBGT = 0.567 * Ta + 0.393 * e + 3.94
  const wbgtVal = Math.round((0.567 * tempC + 0.393 * e + 3.94) * 10) / 10;

  if (wbgtVal < 20) {
    return {
      wbgt: wbgtVal,
      category: { level: 'Normal', color: 'text-emerald-400', advice: 'Optimal for heavy outdoor activities and work.' },
    };
  } else if (wbgtVal < 26) {
    return {
      wbgt: wbgtVal,
      category: { level: 'Low Risk', color: 'text-sky-400', advice: 'Cautious outdoor training. Stay hydrated.' },
    };
  } else if (wbgtVal < 29) {
    return {
      wbgt: wbgtVal,
      category: { level: 'Moderate Risk', color: 'text-yellow-400', advice: 'Schedule frequent rest breaks in shade.' },
    };
  } else if (wbgtVal < 32) {
    return {
      wbgt: wbgtVal,
      category: { level: 'High Risk', color: 'text-orange-400', advice: 'Limit intense physical exertion to under 30 mins.' },
    };
  } else {
    return {
      wbgt: wbgtVal,
      category: { level: 'Extreme Danger', color: 'text-red-500', advice: 'Cease heavy physical labor. High heat stroke hazard.' },
    };
  }
}

/**
 * Calculates Cloud Base (Ceiling) height in meters & feet
 */
export function calculateCloudCeiling(tempC: number, dewPointC: number): { meters: number; feet: number } {
  const spread = Math.max(0, tempC - dewPointC);
  const meters = Math.round(spread * 125);
  const feet = Math.round(spread * 400);
  return { meters, feet };
}

/**
 * Calculates 3-hour Barometric Pressure Tendency (Delta P)
 */
export function calculateBarometricTendency(hourlyPressures?: number[]): BarometricTendency {
  if (!hourlyPressures || hourlyPressures.length < 4) {
    return {
      delta3h: 0,
      status: 'steady',
      label: 'Steady',
      interpretation: 'Atmospheric pressure is steady. Stable meteorological equilibrium.',
      severity: 'normal',
    };
  }

  const current = hourlyPressures[0];
  const past3h = hourlyPressures[3] || hourlyPressures[0];
  const delta = Math.round((current - past3h) * 10) / 10;

  if (delta <= -2.5) {
    return {
      delta3h: delta,
      status: 'rapidly_falling',
      label: 'Rapidly Falling',
      interpretation: 'Severe cyclone or squall line approaching. High wind and precipitation imminent.',
      severity: 'critical',
    };
  } else if (delta <= -0.8) {
    return {
      delta3h: delta,
      status: 'falling',
      label: 'Falling',
      interpretation: 'Weather deteriorating. Cloudiness and showers developing.',
      severity: 'warning',
    };
  } else if (delta >= 2.0) {
    return {
      delta3h: delta,
      status: 'rapidly_rising',
      label: 'Rapidly Rising',
      interpretation: 'Strong high-pressure ridge establishing. Clearing skies and brisk breezes.',
      severity: 'normal',
    };
  } else if (delta >= 0.8) {
    return {
      delta3h: delta,
      status: 'rising',
      label: 'Rising',
      interpretation: 'Weather improving. Clouds breaking with steady conditions.',
      severity: 'normal',
    };
  } else {
    return {
      delta3h: delta,
      status: 'steady',
      label: 'Steady (±0.5 hPa)',
      interpretation: 'Stable meteorological conditions persist.',
      severity: 'normal',
    };
  }
}

/**
 * Computes exact Lunar Moon Phase, Age, and percentage illumination
 */
export function calculateMoonPhase(date: Date = new Date()): MoonPhaseInfo {
  // Known reference new moon: January 11, 2024 at 11:57 UTC
  const refNewMoon = new Date(Date.UTC(2024, 0, 11, 11, 57, 0)).getTime();
  const synodicMonth = 29.53058867 * 86400000; // in ms
  const diff = date.getTime() - refNewMoon;
  const cycleFraction = (diff % synodicMonth) / synodicMonth;
  const normalizedFraction = cycleFraction < 0 ? cycleFraction + 1 : cycleFraction;
  const ageDays = Math.round(normalizedFraction * 29.53 * 10) / 10;

  // Illumination percentage based on cosine angle
  const illumination = Math.round((1 - Math.cos(normalizedFraction * 2 * Math.PI)) / 2 * 100);

  let phaseName = 'New Moon';
  let icon = 'Moon';

  if (normalizedFraction < 0.03 || normalizedFraction >= 0.97) {
    phaseName = 'New Moon';
    icon = 'Circle';
  } else if (normalizedFraction < 0.22) {
    phaseName = 'Waxing Crescent';
    icon = 'Moon';
  } else if (normalizedFraction < 0.28) {
    phaseName = 'First Quarter';
    icon = 'CircleDot';
  } else if (normalizedFraction < 0.47) {
    phaseName = 'Waxing Gibbous';
    icon = 'MoonStar';
  } else if (normalizedFraction < 0.53) {
    phaseName = 'Full Moon';
    icon = 'Sun';
  } else if (normalizedFraction < 0.72) {
    phaseName = 'Waning Gibbous';
    icon = 'MoonStar';
  } else if (normalizedFraction < 0.78) {
    phaseName = 'Last Quarter';
    icon = 'CircleDot';
  } else {
    phaseName = 'Waning Crescent';
    icon = 'Moon';
  }

  // Days until next full and new moon
  const fullMoonFrac = 0.5;
  const daysToFull = normalizedFraction <= fullMoonFrac
    ? (fullMoonFrac - normalizedFraction) * 29.53
    : (1.5 - normalizedFraction) * 29.53;

  const daysToNew = (1 - normalizedFraction) * 29.53;

  return {
    phaseName,
    illumination,
    ageDays,
    icon,
    nextFullMoonDays: Math.round(daysToFull),
    nextNewMoonDays: Math.round(daysToNew),
  };
}

/**
 * Estimates Global Solar Irradiance in W/m^2 based on UV, Cloud Cover, and Daylight
 */
export function estimateSolarIrradiance(cloudCover: number, isDay: boolean, uvIndex: number): {
  irradiance: number;
  category: string;
} {
  if (!isDay) return { irradiance: 0, category: 'Night (0 W/m²)' };

  // Clear-sky max peak at solar noon is ~1000 W/m^2
  const cloudFactor = (100 - (cloudCover * 0.75)) / 100;
  const uvFactor = Math.min(uvIndex / 10, 1);
  const estimated = Math.round(1050 * cloudFactor * Math.max(0.15, uvFactor));

  let category = 'Low Radiation';
  if (estimated > 750) category = 'Peak Solar Generation (>750 W/m²)';
  else if (estimated > 450) category = 'Moderate Solar Flux (450–750 W/m²)';
  else if (estimated > 200) category = 'Diffuse Irradiance (200–450 W/m²)';

  return { irradiance: estimated, category };
}
