// WMO Weather Interpretation Codes (WW) mapping

export interface WeatherCodeInfo {
  description: string;
  icon: string; // Lucide icon name representation or visual indicator
  category: 'clear' | 'cloudy' | 'fog' | 'drizzle' | 'rain' | 'snow' | 'thunderstorm';
}

export function getWeatherCodeInfo(code: number, isDay: boolean = true): WeatherCodeInfo {
  switch (code) {
    case 0:
      return {
        description: isDay ? 'Clear Sky' : 'Clear Night',
        icon: isDay ? 'Sun' : 'Moon',
        category: 'clear',
      };
    case 1:
      return {
        description: isDay ? 'Mainly Clear' : 'Mainly Clear Night',
        icon: isDay ? 'SunDim' : 'MoonStar',
        category: 'clear',
      };
    case 2:
      return {
        description: 'Partly Cloudy',
        icon: isDay ? 'CloudSun' : 'CloudMoon',
        category: 'cloudy',
      };
    case 3:
      return {
        description: 'Overcast',
        icon: 'Cloud',
        category: 'cloudy',
      };
    case 45:
      return {
        description: 'Foggy',
        icon: 'CloudFog',
        category: 'fog',
      };
    case 48:
      return {
        description: 'Depositing Rime Fog',
        icon: 'CloudFog',
        category: 'fog',
      };
    case 51:
      return {
        description: 'Light Drizzle',
        icon: 'CloudDrizzle',
        category: 'drizzle',
      };
    case 53:
      return {
        description: 'Moderate Drizzle',
        icon: 'CloudDrizzle',
        category: 'drizzle',
      };
    case 55:
      return {
        description: 'Dense Drizzle',
        icon: 'CloudDrizzle',
        category: 'drizzle',
      };
    case 56:
    case 57:
      return {
        description: 'Freezing Drizzle',
        icon: 'CloudSnow',
        category: 'drizzle',
      };
    case 61:
      return {
        description: 'Slight Rain',
        icon: 'CloudRain',
        category: 'rain',
      };
    case 63:
      return {
        description: 'Moderate Rain',
        icon: 'CloudRain',
        category: 'rain',
      };
    case 65:
      return {
        description: 'Heavy Rain',
        icon: 'CloudRainWind',
        category: 'rain',
      };
    case 66:
    case 67:
      return {
        description: 'Freezing Rain',
        icon: 'CloudSnow',
        category: 'rain',
      };
    case 71:
      return {
        description: 'Slight Snowfall',
        icon: 'Snowflake',
        category: 'snow',
      };
    case 73:
      return {
        description: 'Moderate Snowfall',
        icon: 'Snowflake',
        category: 'snow',
      };
    case 75:
      return {
        description: 'Heavy Snowfall',
        icon: 'Snowflake',
        category: 'snow',
      };
    case 77:
      return {
        description: 'Snow Grains',
        icon: 'Snowflake',
        category: 'snow',
      };
    case 80:
      return {
        description: 'Slight Rain Showers',
        icon: 'CloudRain',
        category: 'rain',
      };
    case 81:
      return {
        description: 'Moderate Rain Showers',
        icon: 'CloudRainWind',
        category: 'rain',
      };
    case 82:
      return {
        description: 'Violent Rain Showers',
        icon: 'CloudRainWind',
        category: 'rain',
      };
    case 85:
    case 86:
      return {
        description: 'Snow Showers',
        icon: 'CloudSnow',
        category: 'snow',
      };
    case 95:
      return {
        description: 'Thunderstorm',
        icon: 'CloudLightning',
        category: 'thunderstorm',
      };
    case 96:
    case 99:
      return {
        description: 'Severe Thunderstorm with Hail',
        icon: 'CloudLightning',
        category: 'thunderstorm',
      };
    default:
      return {
        description: 'Fair Weather',
        icon: isDay ? 'Sun' : 'Moon',
        category: 'clear',
      };
  }
}

export function formatTemp(tempC: number, unit: 'celsius' | 'fahrenheit' = 'celsius'): string {
  if (tempC === undefined || tempC === null || isNaN(tempC)) return '--°';
  if (unit === 'fahrenheit') {
    const tempF = Math.round((tempC * 9) / 5 + 32);
    return `${tempF}°F`;
  }
  return `${Math.round(tempC)}°C`;
}

export function formatWindSpeed(kmh: number, unit: 'kmh' | 'mph' | 'ms' = 'kmh'): string {
  if (kmh === undefined || kmh === null || isNaN(kmh)) return '--';
  if (unit === 'mph') {
    return `${Math.round(kmh * 0.621371)} mph`;
  }
  if (unit === 'ms') {
    return `${(kmh / 3.6).toFixed(1)} m/s`;
  }
  return `${Math.round(kmh)} km/h`;
}

export function getWindDirectionName(degree: number): string {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const index = Math.round(((degree %= 360) < 0 ? degree + 360 : degree) / 22.5) % 16;
  return directions[index];
}

export function getUVLevel(uv: number): { label: string; color: string } {
  if (uv <= 2) return { label: 'Low', color: 'text-emerald-400' };
  if (uv <= 5) return { label: 'Moderate', color: 'text-yellow-400' };
  if (uv <= 7) return { label: 'High', color: 'text-orange-400' };
  if (uv <= 10) return { label: 'Very High', color: 'text-red-400' };
  return { label: 'Extreme', color: 'text-purple-400' };
}
