import { LocationData } from '../types';

export const MAJOR_GLOBAL_LOCATIONS: LocationData[] = [
  // India
  { name: 'Chennai', country: 'India', admin1: 'Tamil Nadu', latitude: 13.0827, longitude: 80.2707, timezone: 'Asia/Kolkata' },
  { name: 'Mumbai', country: 'India', admin1: 'Maharashtra', latitude: 19.0760, longitude: 72.8777, timezone: 'Asia/Kolkata' },
  { name: 'Delhi', country: 'India', admin1: 'Delhi', latitude: 28.6139, longitude: 77.2090, timezone: 'Asia/Kolkata' },
  { name: 'Bengaluru', country: 'India', admin1: 'Karnataka', latitude: 12.9716, longitude: 77.5946, timezone: 'Asia/Kolkata' },
  { name: 'Hyderabad', country: 'India', admin1: 'Telangana', latitude: 17.3850, longitude: 78.4867, timezone: 'Asia/Kolkata' },
  { name: 'Kolkata', country: 'India', admin1: 'West Bengal', latitude: 22.5726, longitude: 88.3639, timezone: 'Asia/Kolkata' },
  { name: 'Coimbatore', country: 'India', admin1: 'Tamil Nadu', latitude: 11.0168, longitude: 76.9558, timezone: 'Asia/Kolkata' },
  { name: 'Madurai', country: 'India', admin1: 'Tamil Nadu', latitude: 9.9252, longitude: 78.1198, timezone: 'Asia/Kolkata' },
  { name: 'Pune', country: 'India', admin1: 'Maharashtra', latitude: 18.5204, longitude: 73.8567, timezone: 'Asia/Kolkata' },
  { name: 'Ahmedabad', country: 'India', admin1: 'Gujarat', latitude: 23.0225, longitude: 72.5714, timezone: 'Asia/Kolkata' },
  { name: 'Jaipur', country: 'India', admin1: 'Rajasthan', latitude: 26.9124, longitude: 75.7873, timezone: 'Asia/Kolkata' },
  { name: 'Kochi', country: 'India', admin1: 'Kerala', latitude: 9.9312, longitude: 76.2673, timezone: 'Asia/Kolkata' },
  { name: 'Thiruvananthapuram', country: 'India', admin1: 'Kerala', latitude: 8.5241, longitude: 76.9366, timezone: 'Asia/Kolkata' },
  { name: 'Visakhapatnam', country: 'India', admin1: 'Andhra Pradesh', latitude: 17.6868, longitude: 83.2185, timezone: 'Asia/Kolkata' },
  { name: 'Chandigarh', country: 'India', admin1: 'Punjab', latitude: 30.7333, longitude: 76.7794, timezone: 'Asia/Kolkata' },
  
  // Asia Pacific
  { name: 'Tokyo', country: 'Japan', admin1: 'Tokyo', latitude: 35.6762, longitude: 139.6503, timezone: 'Asia/Tokyo' },
  { name: 'Singapore', country: 'Singapore', admin1: '', latitude: 1.3521, longitude: 103.8198, timezone: 'Asia/Singapore' },
  { name: 'Dubai', country: 'United Arab Emirates', admin1: 'Dubai', latitude: 25.2048, longitude: 55.2708, timezone: 'Asia/Dubai' },
  { name: 'Seoul', country: 'South Korea', admin1: 'Seoul', latitude: 37.5665, longitude: 126.9780, timezone: 'Asia/Seoul' },
  { name: 'Bangkok', country: 'Thailand', admin1: 'Bangkok', latitude: 13.7563, longitude: 100.5018, timezone: 'Asia/Bangkok' },
  { name: 'Kuala Lumpur', country: 'Malaysia', admin1: 'Kuala Lumpur', latitude: 3.1390, longitude: 101.6869, timezone: 'Asia/Kuala_Lumpur' },
  { name: 'Sydney', country: 'Australia', admin1: 'New South Wales', latitude: -33.8688, longitude: 151.2093, timezone: 'Australia/Sydney' },
  { name: 'Melbourne', country: 'Australia', admin1: 'Victoria', latitude: -37.8136, longitude: 144.9631, timezone: 'Australia/Melbourne' },
  { name: 'Auckland', country: 'New Zealand', admin1: 'Auckland', latitude: -36.8485, longitude: 174.7633, timezone: 'Pacific/Auckland' },
  
  // Europe
  { name: 'London', country: 'United Kingdom', admin1: 'England', latitude: 51.5074, longitude: -0.1278, timezone: 'Europe/London' },
  { name: 'Paris', country: 'France', admin1: 'Île-de-France', latitude: 48.8566, longitude: 2.3522, timezone: 'Europe/Paris' },
  { name: 'Berlin', country: 'Germany', admin1: 'Berlin', latitude: 52.5200, longitude: 13.4050, timezone: 'Europe/Berlin' },
  { name: 'Rome', country: 'Italy', admin1: 'Lazio', latitude: 41.9028, longitude: 12.4964, timezone: 'Europe/Rome' },
  { name: 'Madrid', country: 'Spain', admin1: 'Madrid', latitude: 40.4168, longitude: -3.7038, timezone: 'Europe/Madrid' },
  { name: 'Amsterdam', country: 'Netherlands', admin1: 'North Holland', latitude: 52.3676, longitude: 4.9041, timezone: 'Europe/Amsterdam' },
  { name: 'Zurich', country: 'Switzerland', admin1: 'Zurich', latitude: 47.3769, longitude: 8.5417, timezone: 'Europe/Zurich' },

  // Americas
  { name: 'New York', country: 'United States', admin1: 'New York', latitude: 40.7128, longitude: -74.0060, timezone: 'America/New_York' },
  { name: 'San Francisco', country: 'United States', admin1: 'California', latitude: 37.7749, longitude: -122.4194, timezone: 'America/Los_Angeles' },
  { name: 'Los Angeles', country: 'United States', admin1: 'California', latitude: 34.0522, longitude: -118.2437, timezone: 'America/Los_Angeles' },
  { name: 'Chicago', country: 'United States', admin1: 'Illinois', latitude: 41.8781, longitude: -87.6298, timezone: 'America/Chicago' },
  { name: 'Toronto', country: 'Canada', admin1: 'Ontario', latitude: 43.6532, longitude: -79.3832, timezone: 'America/Toronto' },
  { name: 'Vancouver', country: 'Canada', admin1: 'British Columbia', latitude: 49.2827, longitude: -123.1207, timezone: 'America/Vancouver' },
  { name: 'Sao Paulo', country: 'Brazil', admin1: 'Sao Paulo', latitude: -23.5505, longitude: -46.6333, timezone: 'America/Sao_Paulo' },
  { name: 'Mexico City', country: 'Mexico', admin1: 'Mexico City', latitude: 19.4326, longitude: -99.1332, timezone: 'America/Mexico_City' },
];

export function searchOfflineLocations(query: string): LocationData[] {
  if (!query || query.trim().length === 0) return [];
  const q = query.toLowerCase().trim();
  return MAJOR_GLOBAL_LOCATIONS.filter(loc => 
    loc.name.toLowerCase().includes(q) ||
    loc.country.toLowerCase().includes(q) ||
    (loc.admin1 && loc.admin1.toLowerCase().includes(q))
  ).slice(0, 8);
}
