import { 
  WeatherDataResponse, 
  LocationData, 
  UserProfile, 
  ChatConversation, 
  AgriAdvisoryRequest, 
  AgriAdvisoryResponse, 
  HistoricalClimateData,
  SupportedLanguage 
} from '../types';
import { searchOfflineLocations } from '../utils/offlineLocations';

const TOKEN_KEY = 'weathergpt_auth_token';
const CACHE_PREFIX = 'weathergpt_cache_';
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
}

function getAuthHeaders(): HeadersInit {
  const token = getStoredToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

// Caching helpers for 100% offline and network reliability
function getCacheKey(lat: number, lon: number): string {
  return `${CACHE_PREFIX}${lat.toFixed(2)}_${lon.toFixed(2)}`;
}

function getCachedWeatherData(lat: number, lon: number): WeatherDataResponse | null {
  try {
    const raw = localStorage.getItem(getCacheKey(lat, lon));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed.data as WeatherDataResponse;
  } catch {
    return null;
  }
}

function setCachedWeatherData(lat: number, lon: number, data: WeatherDataResponse) {
  try {
    localStorage.setItem(getCacheKey(lat, lon), JSON.stringify({
      timestamp: Date.now(),
      data,
    }));
  } catch (e) {
    console.warn('Cache write limit exceeded:', e);
  }
}

export const api = {
  // Auth
  async register(data: {
    name: string;
    email: string;
    password?: string;
    preferredLanguage?: SupportedLanguage;
    defaultLocation?: LocationData;
  }): Promise<{ user: UserProfile; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Registration failed' }));
      throw new Error(err.error || 'Registration failed');
    }
    const result = await res.json();
    setStoredToken(result.token);
    return result;
  },

  async login(email: string, password?: string): Promise<{ user: UserProfile; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Invalid credentials' }));
      throw new Error(err.error || 'Invalid credentials');
    }
    const result = await res.json();
    setStoredToken(result.token);
    return result;
  },

  async googleAuth(payload: { email: string; name?: string; avatarUrl?: string; preferredLanguage?: SupportedLanguage }): Promise<{ user: UserProfile; token: string }> {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Google authentication failed' }));
      throw new Error(err.error || 'Google authentication failed');
    }
    const result = await res.json();
    setStoredToken(result.token);
    return result;
  },

  async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: getAuthHeaders(),
      });
    } finally {
      clearStoredToken();
    }
  },

  async getMe(): Promise<UserProfile> {
    const res = await fetch('/api/auth/me', {
      headers: getAuthHeaders(),
    });
    if (!res.ok) {
      throw new Error('Session expired');
    }
    const data = await res.json();
    return data.user;
  },

  async updateProfile(updates: Partial<UserProfile>): Promise<UserProfile> {
    const res = await fetch('/api/profile', {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to update profile' }));
      throw new Error(err.error || 'Failed to update profile');
    }
    const data = await res.json();
    return data.user;
  },

  // Location search with instant offline cache fallback
  async searchLocations(q: string): Promise<LocationData[]> {
    if (!q || q.trim().length === 0) return [];
    try {
      const res = await fetch(`/api/locations/search?q=${encodeURIComponent(q)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.results && data.results.length > 0) {
          return data.results;
        }
      }
    } catch (e) {
      console.warn('Live location search error, using offline cities fallback:', e);
    }
    return searchOfflineLocations(q);
  },

  async reverseGeocode(lat: number, lon: number): Promise<LocationData> {
    try {
      const res = await fetch(`/api/locations/reverse?lat=${lat}&lon=${lon}`);
      if (res.ok) {
        const data = await res.json();
        return data.location;
      }
    } catch (e) {
      console.warn('Reverse geocode failed:', e);
    }
    return {
      name: `Location (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
      country: '',
      latitude: lat,
      longitude: lon,
    };
  },

  // Saved locations
  async getSavedLocations(): Promise<LocationData[]> {
    const res = await fetch('/api/locations/saved', {
      headers: getAuthHeaders(),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.locations || [];
  },

  async addSavedLocation(location: LocationData): Promise<LocationData[]> {
    const res = await fetch('/api/locations/saved', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ location }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to save location' }));
      throw new Error(err.error || 'Failed to save location');
    }
    const data = await res.json();
    return data.locations;
  },

  async deleteSavedLocation(name: string): Promise<LocationData[]> {
    const res = await fetch(`/api/locations/saved?name=${encodeURIComponent(name)}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to delete saved location' }));
      throw new Error(err.error || 'Failed to delete saved location');
    }
    const data = await res.json();
    return data.locations;
  },

  // Weather data with automatic LocalStorage caching & offline resiliency
  async getWeatherData(loc: LocationData): Promise<WeatherDataResponse> {
    const params = new URLSearchParams({
      lat: loc.latitude.toString(),
      lon: loc.longitude.toString(),
      name: loc.name,
      country: loc.country,
      admin1: loc.admin1 || '',
    });

    try {
      const res = await fetch(`/api/weather/full?${params.toString()}`);
      if (res.ok) {
        const data: WeatherDataResponse = await res.json();
        // Persist to local cache for resilient offline reloads
        setCachedWeatherData(loc.latitude, loc.longitude, data);
        return data;
      }
    } catch (networkErr) {
      console.warn('Network error fetching live weather, checking offline cache:', networkErr);
    }

    // Fallback to cached copy if offline or network error
    const cached = getCachedWeatherData(loc.latitude, loc.longitude);
    if (cached) {
      return {
        ...cached,
        source: `${cached.source} (Offline Cached Backup)`,
      };
    }

    throw new Error('Unable to establish connection to weather services and no offline cache was found.');
  },

  // Historical Climate
  async getHistoricalClimate(loc: LocationData, years: number = 1): Promise<HistoricalClimateData> {
    const params = new URLSearchParams({
      lat: loc.latitude.toString(),
      lon: loc.longitude.toString(),
      years: years.toString(),
      name: loc.name,
      country: loc.country,
    });
    const res = await fetch(`/api/weather/historical?${params.toString()}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to retrieve historical climate records' }));
      throw new Error(err.error || 'Failed to retrieve historical climate records');
    }
    return res.json();
  },

  // Multi-point route weather for Trip Planner
  async getRouteWeatherData(origin: LocationData, destination: LocationData, waypointCount: number = 3): Promise<Array<{
    location: LocationData;
    distancePercent: number;
    weather: WeatherDataResponse;
  }>> {
    const waypoints: LocationData[] = [];
    waypoints.push(origin);

    for (let i = 1; i <= waypointCount; i++) {
      const fraction = i / (waypointCount + 1);
      const lat = origin.latitude + (destination.latitude - origin.latitude) * fraction;
      const lon = origin.longitude + (destination.longitude - origin.longitude) * fraction;
      waypoints.push({
        name: `Waypoint ${i} (${Math.round(fraction * 100)}%)`,
        country: '',
        latitude: lat,
        longitude: lon,
      });
    }
    waypoints.push(destination);

    const results = await Promise.all(
      waypoints.map(async (wp, idx) => {
        try {
          const data = await api.getWeatherData(wp);
          const percent = Math.round((idx / (waypoints.length - 1)) * 100);
          return {
            location: wp,
            distancePercent: percent,
            weather: data,
          };
        } catch {
          // Provide basic interpolated fallback
          return null;
        }
      })
    );

    return results.filter(Boolean) as Array<{
      location: LocationData;
      distancePercent: number;
      weather: WeatherDataResponse;
    }>;
  },

  // WeatherGPT AI Chat
  async sendChatMessage(payload: {
    query: string;
    defaultLocation: LocationData;
    language: SupportedLanguage;
    conversationHistory?: Array<{ sender: 'user' | 'assistant'; content: string }>;
  }): Promise<{ response: string; groundingData: any; resolvedLocation: LocationData }> {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'AI chat service error' }));
      throw new Error(err.error || 'AI chat service error');
    }
    return res.json();
  },

  async getConversations(): Promise<ChatConversation[]> {
    const res = await fetch('/api/chat/conversations', {
      headers: getAuthHeaders(),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.conversations || [];
  },

  async saveConversation(conversation: ChatConversation): Promise<void> {
    await fetch('/api/chat/conversations', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ conversation }),
    });
  },

  async deleteConversation(id: string): Promise<void> {
    await fetch(`/api/chat/conversations/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
  },

  // Agriculture Advisory
  async getAgriAdvisory(req: AgriAdvisoryRequest): Promise<AgriAdvisoryResponse> {
    const res = await fetch('/api/agriculture/advisory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to generate agriculture advisory' }));
      throw new Error(err.error || 'Failed to generate agriculture advisory');
    }
    return res.json();
  },

  // Voice TTS
  async speakText(text: string): Promise<string | null> {
    try {
      const res = await fetch('/api/voice/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.audioBase64 || null;
    } catch {
      return null;
    }
  },
};

