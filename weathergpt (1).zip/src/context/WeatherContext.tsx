import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  WeatherDataResponse, 
  LocationData, 
  SupportedLanguage, 
  TemperatureUnit, 
  WindSpeedUnit,
  WeatherAlert 
} from '../types';
import { api } from '../services/api';
import { useAuth } from './AuthContext';

interface WeatherContextType {
  location: LocationData;
  weatherData: WeatherDataResponse | null;
  loading: boolean;
  error: string | null;
  language: SupportedLanguage;
  tempUnit: TemperatureUnit;
  windUnit: WindSpeedUnit;
  savedLocations: LocationData[];
  alerts: WeatherAlert[];
  unreadAlertCount: number;
  setLocation: (loc: LocationData) => void;
  setLanguage: (lang: SupportedLanguage) => void;
  setTempUnit: (unit: TemperatureUnit) => void;
  setWindUnit: (unit: WindSpeedUnit) => void;
  refreshWeather: () => Promise<void>;
  useCurrentGPSLocation: () => Promise<void>;
  saveCurrentLocation: (tag?: 'Home' | 'Office' | 'Farm' | 'Custom') => Promise<void>;
  removeSavedLocation: (name: string) => Promise<void>;
  isSaved: boolean;
}

const DEFAULT_LOCATION: LocationData = {
  name: 'Chennai',
  country: 'India',
  admin1: 'Tamil Nadu',
  latitude: 13.0827,
  longitude: 80.2707,
  timezone: 'Asia/Kolkata',
  tag: 'Home',
};

const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

export const WeatherProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, updateProfile } = useAuth();
  
  const [location, setLocationState] = useState<LocationData>(
    user?.defaultLocation || DEFAULT_LOCATION
  );
  const [weatherData, setWeatherData] = useState<WeatherDataResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [savedLocations, setSavedLocations] = useState<LocationData[]>([]);
  const [language, setLanguageState] = useState<SupportedLanguage>(
    user?.preferredLanguage || 'en'
  );
  const [tempUnit, setTempUnitState] = useState<TemperatureUnit>(
    user?.temperatureUnit || 'celsius'
  );
  const [windUnit, setWindUnitState] = useState<WindSpeedUnit>(
    user?.windSpeedUnit || 'kmh'
  );

  // Sync with user preferences when user loads
  useEffect(() => {
    if (user) {
      if (user.preferredLanguage) setLanguageState(user.preferredLanguage);
      if (user.temperatureUnit) setTempUnitState(user.temperatureUnit);
      if (user.windSpeedUnit) setWindUnitState(user.windSpeedUnit);
      if (user.defaultLocation && !weatherData) {
        setLocationState(user.defaultLocation);
      }
    }
  }, [user]);

  // Load saved locations for authenticated user
  const loadSavedLocations = useCallback(async () => {
    if (user) {
      try {
        const locs = await api.getSavedLocations();
        setSavedLocations(locs);
      } catch (e) {
        console.warn('Could not load saved locations:', e);
      }
    }
  }, [user]);

  useEffect(() => {
    loadSavedLocations();
  }, [loadSavedLocations]);

  // Fetch real weather data whenever location changes
  const fetchWeather = useCallback(async (loc: LocationData) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getWeatherData(loc);
      setWeatherData(data);
    } catch (err: any) {
      console.error('Weather load error:', err);
      setError(err.message || 'Failed to load weather data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeather(location);
  }, [location, fetchWeather]);

  const setLocation = (newLoc: LocationData) => {
    setLocationState(newLoc);
  };

  const refreshWeather = async () => {
    await fetchWeather(location);
  };

  const setLanguage = (newLang: SupportedLanguage) => {
    setLanguageState(newLang);
    if (user) {
      updateProfile({ preferredLanguage: newLang });
    }
  };

  const setTempUnit = (unit: TemperatureUnit) => {
    setTempUnitState(unit);
    if (user) {
      updateProfile({ temperatureUnit: unit });
    }
  };

  const setWindUnit = (unit: WindSpeedUnit) => {
    setWindUnitState(unit);
    if (user) {
      updateProfile({ windSpeedUnit: unit });
    }
  };

  const useCurrentGPSLocation = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const resolved = await api.reverseGeocode(latitude, longitude);
          setLocationState(resolved);
        } catch (e: any) {
          setError('Failed to resolve your GPS coordinates. Using direct coordinates.');
          setLocationState({
            name: 'My GPS Location',
            country: '',
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
        }
      },
      (err) => {
        setLoading(false);
        if (err.code === err.PERMISSION_DENIED) {
          setError('Location access denied. Enable GPS permission or search for a city manually.');
        } else {
          setError('Unable to retrieve your location: ' + err.message);
        }
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const saveCurrentLocation = async (tag: 'Home' | 'Office' | 'Farm' | 'Custom' = 'Custom') => {
    if (!user) return;
    try {
      const locToSave = { ...location, tag };
      const updated = await api.addSavedLocation(locToSave);
      setSavedLocations(updated);
    } catch (e: any) {
      console.error('Failed to save location:', e);
    }
  };

  const removeSavedLocation = async (name: string) => {
    if (!user) return;
    try {
      const updated = await api.deleteSavedLocation(name);
      setSavedLocations(updated);
    } catch (e: any) {
      console.error('Failed to remove location:', e);
    }
  };

  const isSaved = savedLocations.some(
    loc => Math.abs(loc.latitude - location.latitude) < 0.05 && Math.abs(loc.longitude - location.longitude) < 0.05
  );

  const alerts = weatherData?.alerts || [];
  const unreadAlertCount = alerts.filter(a => a.severity === 'extreme' || a.severity === 'severe').length;

  return (
    <WeatherContext.Provider
      value={{
        location,
        weatherData,
        loading,
        error,
        language,
        tempUnit,
        windUnit,
        savedLocations,
        alerts,
        unreadAlertCount,
        setLocation,
        setLanguage,
        setTempUnit,
        setWindUnit,
        refreshWeather,
        useCurrentGPSLocation,
        saveCurrentLocation,
        removeSavedLocation,
        isSaved,
      }}
    >
      {children}
    </WeatherContext.Provider>
  );
};

export const useWeather = () => {
  const context = useContext(WeatherContext);
  if (!context) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
};
