import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, SupportedLanguage, LocationData } from '../types';
import { api, getStoredToken } from '../services/api';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  login: (email: string, password?: string) => Promise<void>;
  register: (data: {
    name: string;
    email: string;
    password?: string;
    preferredLanguage?: SupportedLanguage;
    defaultLocation?: LocationData;
  }) => Promise<void>;
  googleLogin: (email?: string, name?: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function checkAuth() {
      const token = getStoredToken();
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const currentUser = await api.getMe();
        setUser(currentUser);
      } catch (err) {
        console.warn('Session expired or invalid, clearing token');
        setUser(null);
      } finally {
        setLoading(false);
      }
    }
    checkAuth();
  }, []);

  const login = async (email: string, password?: string) => {
    const res = await api.login(email, password);
    setUser(res.user);
  };

  const register = async (data: {
    name: string;
    email: string;
    password?: string;
    preferredLanguage?: SupportedLanguage;
    defaultLocation?: LocationData;
  }) => {
    const res = await api.register(data);
    setUser(res.user);
  };

  const googleLogin = async (email?: string, name?: string) => {
    const res = await api.googleAuth({
      email: email || 'anizaid35@gmail.com',
      name: name || 'Google Verified User',
      preferredLanguage: user?.preferredLanguage || 'en',
    });
    setUser(res.user);
  };

  const logout = async () => {
    await api.logout();
    setUser(null);
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    const updated = await api.updateProfile(updates);
    setUser(updated);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        googleLogin,
        logout,
        updateProfile,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
