import React from 'react';
import { LayoutDashboard, MessageSquareCode, Map, AlertOctagon, Mic, Sprout } from 'lucide-react';
import { useWeather } from '../context/WeatherContext';

interface MobileNavProps {
  activeTab: string;
  setActiveTab?: (tab: string, query?: string) => void;
  onSelectTab?: (tab: string) => void;
  onOpenVoice?: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  setActiveTab,
  onSelectTab,
  onOpenVoice = () => {},
}) => {
  const { unreadAlertCount } = useWeather();

  const handleSelect = (tab: string) => {
    if (setActiveTab) setActiveTab(tab);
    else if (onSelectTab) onSelectTab(tab);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 lg:hidden px-2 py-1.5 safe-area-pb">
      <div className="flex items-center justify-around relative">
        <button
          id="mob-nav-dashboard"
          onClick={() => handleSelect('dashboard')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'dashboard' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          <span>Home</span>
        </button>

        <button
          id="mob-nav-forecast"
          onClick={() => handleSelect('forecast')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'forecast' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sprout className="w-5 h-5 mb-0.5" />
          <span>Forecast</span>
        </button>

        {/* Central Floating Voice AI Button */}
        <div className="-mt-5">
          <button
            id="mob-nav-voice"
            onClick={onOpenVoice}
            className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 via-sky-500 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-500/40 border-2 border-slate-900 transform active:scale-95 transition-transform"
            aria-label="Voice Assistant"
          >
            <Mic className="w-6 h-6 animate-pulse" />
          </button>
        </div>

        <button
          id="mob-nav-map"
          onClick={() => handleSelect('map')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'map' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Map className="w-5 h-5 mb-0.5" />
          <span>Map</span>
        </button>

        <button
          id="mob-nav-chat"
          onClick={() => handleSelect('chat')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'chat' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <MessageSquareCode className="w-5 h-5 mb-0.5" />
            {unreadAlertCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500" />
            )}
          </div>
          <span>AI Chat</span>
        </button>
      </div>
    </nav>
  );
};
