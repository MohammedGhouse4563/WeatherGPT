import React, { useState } from 'react';
import { 
  X, 
  Bell, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Wind, 
  Droplets, 
  Flame, 
  Clock, 
  Check, 
  Settings2 
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../utils/i18n';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToAlerts?: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  onNavigateToAlerts,
}) => {
  const { alerts, language } = useWeather();
  const { user, updateProfile } = useAuth();
  const { t } = useTranslation(language);

  const [activeTab, setActiveTab] = useState<'alerts' | 'preferences'>('alerts');
  const [prefs, setPrefs] = useState(
    user?.notificationPreferences || {
      severeWeather: true,
      rainAlerts: true,
      heatAlerts: true,
      cycloneAlerts: true,
      dailyBriefing: true,
    }
  );
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleTogglePref = (key: keyof typeof prefs) => {
    const updated = { ...prefs, [key]: !prefs[key] };
    setPrefs(updated);
  };

  const handleSavePreferences = async () => {
    if (user) {
      await updateProfile({ notificationPreferences: prefs });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Meteorological Notifications & Alerts</h3>
              <p className="text-[11px] text-slate-400">Official warnings and custom briefing alerts</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex border-b border-slate-800 px-5 pt-2">
          <button
            onClick={() => setActiveTab('alerts')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'alerts'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Active Warnings ({alerts.length})
          </button>

          <button
            onClick={() => setActiveTab('preferences')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'preferences'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            Alert Subscriptions
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {activeTab === 'alerts' ? (
            <div>
              {alerts.length === 0 ? (
                <div className="py-8 text-center space-y-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">No Active Severe Warnings</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">
                    {t('noAlerts')}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-3.5 rounded-xl border ${
                        alert.severity === 'extreme'
                          ? 'bg-red-950/40 border-red-800/80 text-red-100'
                          : alert.severity === 'severe'
                          ? 'bg-amber-950/40 border-amber-800/80 text-amber-100'
                          : 'bg-yellow-950/30 border-yellow-800/60 text-yellow-100'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-bold flex items-center gap-1.5">
                          <ShieldAlert className="w-4 h-4" />
                          {alert.title}
                        </span>
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-black/40 border border-white/10 font-bold">
                          {alert.severity}
                        </span>
                      </div>
                      <p className="text-xs text-slate-200 mt-1">{alert.description}</p>
                      
                      <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-300">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" />
                          Valid until {new Date(alert.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <span className="font-semibold text-cyan-300">{alert.area}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Configure immediate push and broadcast notifications for localized meteorological threats:
              </p>

              <div className="space-y-2.5">
                {[
                  { key: 'severeWeather', label: 'Severe Storm & Cyclone Alerts', desc: 'Notify immediately when winds exceed 60 km/h or lightning occurs', icon: Wind },
                  { key: 'rainAlerts', label: 'Heavy Rainfall & Flash Flood Warnings', desc: 'Alert when precipitation exceeds 25mm in 3 hours', icon: Droplets },
                  { key: 'heatAlerts', label: 'Extreme Heatwave & Thermal Alerts', desc: 'Notify when temperatures exceed 40°C', icon: Flame },
                  { key: 'dailyBriefing', label: 'Daily Morning Meteorological Briefing', desc: 'Receive morning outlook at 7:00 AM local time', icon: Clock },
                ].map((item) => {
                  const Icon = item.icon;
                  const isChecked = !!prefs[item.key as keyof typeof prefs];

                  return (
                    <div
                      key={item.key}
                      onClick={() => handleTogglePref(item.key as any)}
                      className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/70 hover:border-slate-600 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-slate-700 text-cyan-400 mt-0.5">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-slate-100">{item.label}</div>
                          <div className="text-[11px] text-slate-400">{item.desc}</div>
                        </div>
                      </div>

                      <div
                        className={`w-5 h-5 rounded flex items-center justify-center border transition-colors ${
                          isChecked ? 'bg-cyan-500 border-cyan-400 text-white' : 'border-slate-600 bg-slate-800'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="pt-2 flex items-center justify-end">
                <button
                  onClick={handleSavePreferences}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-lg shadow-cyan-500/20"
                >
                  {savedSuccess ? <Check className="w-4 h-4" /> : null}
                  {savedSuccess ? 'Preferences Saved!' : 'Save Subscriptions'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">
            Source: IMD / ECMWF / WMO Cap Alerts
          </span>
          {onNavigateToAlerts && (
            <button
              onClick={() => {
                onNavigateToAlerts();
                onClose();
              }}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
            >
              Open Full Disaster Center →
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
