import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  X, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Loader2, 
  Languages, 
  RotateCcw,
  Check,
  Send
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { SUPPORTED_LANGUAGES, useTranslation } from '../utils/i18n';
import { api } from '../services/api';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToChatWithQuery?: (query: string) => void;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({ isOpen, onClose }) => {
  const { location, language, setLanguage } = useWeather();
  const { t } = useTranslation(language);

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Language mapping to BCP-47 locale tags for speech recognition
  const getLanguageLocale = (langCode: string): string => {
    switch (langCode) {
      case 'ta': return 'ta-IN';
      case 'hi': return 'hi-IN';
      case 'te': return 'te-IN';
      case 'kn': return 'kn-IN';
      case 'ml': return 'ml-IN';
      case 'bn': return 'bn-IN';
      case 'mr': return 'mr-IN';
      default: return 'en-IN';
    }
  };

  const startListening = () => {
    setErrorMsg('');
    setAiResponse('');
    setTranscript('');
    setInterimTranscript('');

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMsg('Speech recognition is not supported in this browser. Please type your query in AI Chat.');
      return;
    }

    try {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = getLanguageLocale(language);

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let finalTrans = '';
        let interimTrans = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTrans += event.results[i][0].transcript;
          } else {
            interimTrans += event.results[i][0].transcript;
          }
        }

        if (finalTrans) {
          setTranscript(finalTrans);
        }
        setInterimTranscript(interimTrans);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        if (event.error !== 'no-speech') {
          setErrorMsg(`Voice input error: ${event.error}. Click mic to retry.`);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Failed to start speech recognition:', err);
      setErrorMsg('Could not access microphone: ' + err.message);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    setIsListening(false);
  };

  // Process query with WeatherGPT API
  const handleProcessVoiceQuery = async (queryToProcess?: string) => {
    const q = queryToProcess || transcript || interimTranscript;
    if (!q || q.trim().length === 0) return;

    stopListening();
    setIsProcessing(true);
    setErrorMsg('');

    try {
      const result = await api.sendChatMessage({
        query: q,
        defaultLocation: location,
        language,
      });

      setAiResponse(result.response);
      speakText(result.response);
    } catch (err: any) {
      console.error('Error processing voice query:', err);
      setErrorMsg('Failed to process meteorological query: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const speakText = (text: string) => {
    if (!synthRef.current) return;
    synthRef.current.cancel();

    // Clean markdown for pleasant vocal reading
    const clean = text
      .replace(/[*#_`]/g, '')
      .replace(/\n+/g, '. ')
      .slice(0, 350);

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = getLanguageLocale(language);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  };

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      // Auto-start listening on open
      startListening();
    } else {
      stopListening();
      stopSpeaking();
    }
    return () => {
      stopListening();
      stopSpeaking();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                WeatherGPT Voice AI
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  Multilingual
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {location.name} • {SUPPORTED_LANGUAGES.find(l => l.code === language)?.nativeName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Switch */}
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-cyan-500"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.name})
                </option>
              ))}
            </select>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 flex-1 overflow-y-auto space-y-5">
          
          {/* Animated Central Mic / Waveform */}
          <div className="flex flex-col items-center justify-center py-4">
            <div className="relative">
              {isListening && (
                <>
                  <div className="absolute -inset-4 rounded-full bg-cyan-500/20 animate-ping" />
                  <div className="absolute -inset-8 rounded-full bg-cyan-500/10 animate-pulse" />
                </>
              )}
              
              <button
                id="btn-voice-toggle"
                onClick={isListening ? stopListening : startListening}
                className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-xl ${
                  isListening
                    ? 'bg-gradient-to-tr from-red-500 to-rose-600 text-white shadow-red-500/30 ring-4 ring-red-500/20'
                    : 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-white shadow-cyan-500/30 hover:scale-105'
                }`}
              >
                {isListening ? (
                  <Mic className="w-9 h-9 animate-pulse" />
                ) : (
                  <Mic className="w-9 h-9" />
                )}
              </button>
            </div>

            <p className="mt-4 text-xs font-semibold tracking-wide text-slate-300">
              {isListening ? t('listening') : isProcessing ? 'Analyzing Meteorological Forecast...' : 'Tap Mic to Speak'}
            </p>

            {/* Simulated Live Audio Spectrum Bars */}
            {isListening && (
              <div className="flex items-center gap-1 mt-3 h-6">
                {[40, 75, 100, 60, 90, 45, 80, 50, 95, 30].map((h, i) => (
                  <div
                    key={i}
                    className="w-1 bg-gradient-to-t from-cyan-500 to-sky-400 rounded-full animate-pulse"
                    style={{
                      height: `${h}%`,
                      animationDelay: `${i * 80}ms`,
                      animationDuration: '600ms',
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Transcript Display Box */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3.5 min-h-[70px]">
            <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1 flex items-center justify-between">
              <span>Your Query</span>
              {(transcript || interimTranscript) && !isProcessing && (
                <button
                  onClick={() => handleProcessVoiceQuery()}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold normal-case"
                >
                  <Send className="w-3 h-3" /> Send
                </button>
              )}
            </div>
            <p className="text-xs sm:text-sm text-slate-100 font-medium">
              {transcript || interimTranscript || (
                <span className="text-slate-500 italic">
                  Example: "Will it rain in Chennai this evening?", "What is tomorrow's temperature?"
                </span>
              )}
            </p>
          </div>

          {/* Error notice */}
          {errorMsg && (
            <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-xl text-xs text-red-300 flex items-center gap-2">
              <MicOff className="w-4 h-4 flex-shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Processing Indicator */}
          {isProcessing && (
            <div className="p-4 bg-slate-800/50 border border-cyan-500/30 rounded-xl flex items-center justify-center gap-3">
              <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
              <span className="text-xs text-cyan-200">Grounded Meteorological AI Computing...</span>
            </div>
          )}

          {/* AI Response Box */}
          {aiResponse && (
            <div className="bg-slate-950/80 border border-cyan-500/40 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> WeatherGPT Intelligence
                </span>
                <div className="flex items-center gap-2">
                  {isSpeaking ? (
                    <button
                      onClick={stopSpeaking}
                      className="px-2 py-1 rounded-md bg-red-500/20 text-red-400 hover:bg-red-500/30 text-[11px] font-medium flex items-center gap-1"
                    >
                      <VolumeX className="w-3.5 h-3.5" /> Stop Voice
                    </button>
                  ) : (
                    <button
                      onClick={() => speakText(aiResponse)}
                      className="px-2 py-1 rounded-md bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 text-[11px] font-medium flex items-center gap-1"
                    >
                      <Volume2 className="w-3.5 h-3.5" /> Replay Audio
                    </button>
                  )}
                </div>
              </div>

              <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line max-h-48 overflow-y-auto">
                {aiResponse}
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/70 flex items-center justify-between">
          <button
            onClick={() => {
              setTranscript('');
              setInterimTranscript('');
              setAiResponse('');
              startListening();
            }}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>

          {(transcript || interimTranscript) && !isProcessing && (
            <button
              onClick={() => handleProcessVoiceQuery()}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-all"
            >
              <Send className="w-3.5 h-3.5" /> Ask WeatherGPT
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
