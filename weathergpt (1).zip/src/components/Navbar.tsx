import React, { useState, useEffect, useRef } from 'react';
import { 
  CloudSun, 
  MapPin, 
  Search, 
  Mic, 
  Bell, 
  Globe, 
  User, 
  LogOut, 
  Navigation, 
  Loader2, 
  Check, 
  AlertTriangle,
  Menu,
  X,
  Bookmark,
  BookmarkCheck,
  RefreshCw
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useAuth } from '../context/AuthContext';
import { SUPPORTED_LANGUAGES, useTranslation } from '../utils/i18n';
import { api } from '../services/api';
import { LocationData } from '../types';

interface NavbarProps {
  onOpenVoice: () => void;
  onOpenNotifications: () => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  onNavigate: (tab: string) => void;
  activeTab: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenVoice,
  onOpenNotifications,
  onToggleSidebar,
  isSidebarOpen,
  onNavigate,
  activeTab,
}) => {
  const { 
    location, 
    setLocation, 
    language, 
    setLanguage, 
    tempUnit, 
    setTempUnit,
    useCurrentGPSLocation,
    loading,
    refreshWeather,
    saveCurrentLocation,
    removeSavedLocation,
    isSaved,
    unreadAlertCount
  } = useWeather();
  const { user, logout } = useAuth();
  const { t } = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [showLangDropdown, setShowLangDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);
  const langRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Debounced location search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await api.searchLocations(searchQuery);
        setSearchResults(results);
        setShowSearchDropdown(true);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside listener for dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchDropdown(false);
      }
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setShowLangDropdown(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setShowProfileDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectLocation = (loc: LocationData) => {
    setLocation(loc);
    setSearchQuery('');
    setShowSearchDropdown(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Left: Mobile Menu Toggle & Brand */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            id="btn-sidebar-toggle"
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
            aria-label="Toggle menu"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div 
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <CloudSun className="w-5 h-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 bg-clip-text text-transparent">
                  WeatherGPT
                </span>
                <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  AI Live
                </span>
              </div>
              <p className="text-[10px] text-slate-400 -mt-0.5 tracking-tight truncate max-w-[170px]">
                {t('tagline')}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Search & Location */}
        <div ref={searchRef} className="flex-1 max-w-md relative">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              id="input-location-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => {
                if (searchResults.length > 0) setShowSearchDropdown(true);
              }}
              placeholder={t('searchPlaceholder')}
              className="w-full bg-slate-800/80 border border-slate-700/80 focus:border-cyan-500/80 text-xs sm:text-sm text-slate-100 placeholder-slate-400 rounded-full pl-9 pr-20 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
            />
            {isSearching && (
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin absolute right-16" />
            )}
            <button
              id="btn-use-gps"
              onClick={useCurrentGPSLocation}
              title={t('currentLocation')}
              className="absolute right-1.5 top-1.5 bottom-1.5 px-2.5 rounded-full bg-slate-700/60 hover:bg-cyan-600/80 text-slate-300 hover:text-white text-[11px] font-medium flex items-center gap-1 transition-colors"
            >
              <Navigation className="w-3 h-3 text-cyan-400" />
              <span className="hidden md:inline">GPS</span>
            </button>
          </div>

          {/* Search Dropdown */}
          {showSearchDropdown && searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1.5 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50 max-h-72 overflow-y-auto">
              <div className="p-1.5">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 py-1">
                  Locations Found ({searchResults.length})
                </div>
                {searchResults.map((item, idx) => (
                  <button
                    key={`${item.latitude}-${item.longitude}-${idx}`}
                    onClick={() => handleSelectLocation(item)}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-200 text-xs flex items-center justify-between group transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                      <div>
                        <span className="font-semibold text-slate-100">{item.name}</span>
                        <span className="text-slate-400 ml-1.5">
                          {item.admin1 ? `${item.admin1}, ` : ''}{item.country}
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {item.latitude.toFixed(2)}°, {item.longitude.toFixed(2)}°
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-3">
          
          {/* Quick Active Location Pill */}
          <div className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-medium text-slate-200 truncate max-w-[110px]">
              {location.name}
            </span>
            <button
              onClick={() => isSaved ? removeSavedLocation(location.name) : saveCurrentLocation()}
              title={isSaved ? 'Remove from saved' : 'Save location'}
              className="text-slate-400 hover:text-cyan-400 ml-0.5"
            >
              {isSaved ? <BookmarkCheck className="w-3.5 h-3.5 text-cyan-400" /> : <Bookmark className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={refreshWeather}
              title="Refresh live meteorological metrics"
              className={`text-slate-400 hover:text-cyan-400 ml-0.5 ${loading ? 'animate-spin text-cyan-400' : ''}`}
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          {/* Unit Toggle (°C / °F) */}
          <div className="flex items-center bg-slate-800 border border-slate-700 rounded-lg p-0.5 text-xs font-semibold">
            <button
              id="btn-unit-celsius"
              onClick={() => setTempUnit('celsius')}
              className={`px-2 py-1 rounded-md transition-colors ${
                tempUnit === 'celsius' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              °C
            </button>
            <button
              id="btn-unit-fahrenheit"
              onClick={() => setTempUnit('fahrenheit')}
              className={`px-2 py-1 rounded-md transition-colors ${
                tempUnit === 'fahrenheit' ? 'bg-cyan-500 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              °F
            </button>
          </div>

          {/* Language Selector Dropdown */}
          <div ref={langRef} className="relative">
            <button
              id="btn-language-selector"
              onClick={() => setShowLangDropdown(!showLangDropdown)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white flex items-center gap-1 text-xs transition-colors"
              title="Change Language"
            >
              <Globe className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline font-medium uppercase">{language}</span>
            </button>

            {showLangDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50">
                <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  Select Language
                </div>
                <div className="max-h-60 overflow-y-auto">
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setShowLangDropdown(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                        language === lang.code ? 'text-cyan-400 font-semibold bg-cyan-950/40' : 'text-slate-300'
                      }`}
                    >
                      <span>{lang.nativeName} ({lang.name})</span>
                      {language === lang.code && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Voice Assistant Button */}
          <button
            id="btn-nav-voice"
            onClick={onOpenVoice}
            className="p-2 rounded-lg bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/40 hover:border-cyan-400 text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-all shadow-sm hover:shadow-cyan-500/20"
            title={t('voiceAssistant')}
          >
            <Mic className="w-4 h-4" />
            <span className="hidden md:inline text-xs font-semibold">Voice AI</span>
          </button>

          {/* Severe Alerts Bell */}
          <button
            id="btn-nav-notifications"
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title={t('alerts')}
          >
            <Bell className="w-4 h-4" />
            {unreadAlertCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[9px] font-bold text-white items-center justify-center">
                  {unreadAlertCount}
                </span>
              </span>
            )}
          </button>

          {/* Profile Menu */}
          <div ref={profileRef} className="relative">
            <button
              id="btn-user-profile"
              onClick={() => setShowProfileDropdown(!showProfileDropdown)}
              className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-800 border border-transparent hover:border-slate-700 transition-colors"
            >
              {user?.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover border border-cyan-500/60"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-cyan-400 font-bold text-xs border border-slate-600">
                  {user?.name ? user.name[0].toUpperCase() : 'U'}
                </div>
              )}
            </button>

            {showProfileDropdown && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50">
                <div className="px-3 py-2 border-b border-slate-800">
                  <div className="text-xs font-semibold text-slate-100 truncate">{user?.name || 'Meteorologist'}</div>
                  <div className="text-[11px] text-slate-400 truncate">{user?.email}</div>
                </div>

                <button
                  onClick={() => {
                    onNavigate('settings');
                    setShowProfileDropdown(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 flex items-center gap-2"
                >
                  <User className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{t('settings')} & {t('profile')}</span>
                </button>

                <button
                  onClick={() => {
                    onNavigate('saved-locations');
                    setShowProfileDropdown(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 flex items-center gap-2"
                >
                  <Bookmark className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{t('savedLocations')}</span>
                </button>

                <div className="border-t border-slate-800 my-1"></div>

                <button
                  id="btn-logout"
                  onClick={() => {
                    logout();
                    setShowProfileDropdown(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-red-400 hover:bg-red-950/30 flex items-center gap-2"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t('logout')}</span>
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
