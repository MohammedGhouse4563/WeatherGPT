import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  MessageSquareCode, 
  CalendarDays, 
  Map, 
  AlertOctagon, 
  TrendingUp, 
  Sprout, 
  ShieldAlert, 
  Scale, 
  Bookmark, 
  Settings,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Route,
  Activity,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { useWeather } from '../context/WeatherContext';
import { useTranslation } from '../utils/i18n';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string, query?: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpen = false,
  onClose = () => {},
}) => {
  const { language, unreadAlertCount } = useWeather();
  const { t } = useTranslation(language);

  // Remember collapsed preference in localStorage
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('weathergpt_sidebar_collapsed') === 'true';
  });

  const toggleCollapse = () => {
    const next = !isCollapsed;
    setIsCollapsed(next);
    localStorage.setItem('weathergpt_sidebar_collapsed', String(next));
  };

  const NAV_ITEMS = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard, badge: null },
    { id: 'chat', label: t('aiChat'), icon: MessageSquareCode, badge: 'AI' },
    { id: 'forecast', label: t('forecast'), icon: CalendarDays, badge: '7-Day' },
    { id: 'map', label: t('weatherMap'), icon: Map, badge: 'Doppler' },
    { id: 'trip', label: 'Trip Route Planner', icon: Route, badge: 'New' },
    { id: 'alerts', label: t('alerts'), icon: AlertOctagon, badge: unreadAlertCount > 0 ? `${unreadAlertCount}` : null, isAlert: unreadAlertCount > 0 },
    { id: 'climate', label: t('climate'), icon: TrendingUp, badge: 'Archive' },
    { id: 'agriculture', label: t('agriculture'), icon: Sprout, badge: null },
    { id: 'disaster', label: t('disasterCenter'), icon: ShieldAlert, badge: null },
    { id: 'compare', label: t('comparison'), icon: Scale, badge: null },
    { id: 'settings', label: t('settings'), icon: Settings, badge: null },
  ];

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Responsive Sidebar */}
      <aside
        className={`fixed lg:sticky top-16 bottom-0 left-0 z-40 bg-slate-900/95 lg:bg-slate-900/80 backdrop-blur-md border-r lg:border border-slate-800 lg:rounded-2xl transition-all duration-200 ease-in-out flex flex-col justify-between overflow-y-auto overflow-x-hidden ${
          isCollapsed ? 'lg:w-16 w-60' : 'w-56 lg:w-56'
        } ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } flex-shrink-0 lg:my-1 lg:max-h-[calc(100vh-5.5rem)]`}
      >
        <div className="p-2 space-y-1">
          
          {/* Header with quick Collapse / Expand Button */}
          <div className="flex items-center justify-between px-2 py-1.5 border-b border-slate-800/80 mb-1">
            {!isCollapsed ? (
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 truncate">
                Navigation Hub
              </span>
            ) : (
              <div className="w-full flex justify-center">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              </div>
            )}

            <button
              onClick={toggleCollapse}
              className="hidden lg:flex p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title={isCollapsed ? 'Expand sidebar' : 'Collapse to compact rail (saves screen space)'}
            >
              {isCollapsed ? <PanelLeftOpen className="w-3.5 h-3.5" /> : <PanelLeftClose className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Nav Items List */}
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => {
                  setActiveTab(item.id);
                  onClose();
                }}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center ${
                  isCollapsed ? 'justify-center px-2' : 'justify-between px-2.5'
                } py-2 rounded-xl text-xs font-medium transition-all group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/10 border border-cyan-500/40 text-cyan-300 font-semibold shadow-sm'
                    : 'text-slate-300 hover:text-slate-100 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon
                    className={`w-4 h-4 flex-shrink-0 transition-colors ${
                      isActive
                        ? 'text-cyan-400'
                        : item.isAlert
                        ? 'text-red-400 animate-pulse'
                        : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  {!isCollapsed && <span className="truncate text-left text-[11px] sm:text-xs">{item.label}</span>}
                </div>

                {!isCollapsed && (
                  <div className="flex items-center gap-1">
                    {item.badge && (
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                          item.isAlert
                            ? 'bg-red-500 text-white'
                            : isActive
                            ? 'bg-cyan-500/30 text-cyan-300 border border-cyan-500/40'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                    {isActive && <ChevronRight className="w-3 h-3 text-cyan-400" />}
                  </div>
                )}

                {/* Floating tooltip on hover when in compact mode */}
                {isCollapsed && (
                  <div className="hidden lg:group-hover:flex absolute left-full ml-2 px-2.5 py-1 bg-slate-900 border border-slate-700 text-slate-100 text-xs rounded-lg shadow-xl whitespace-nowrap z-50 pointer-events-none items-center gap-1.5">
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="text-[9px] px-1 bg-cyan-950 text-cyan-400 rounded">
                        {item.badge}
                      </span>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom AI Pill */}
        <div className="p-2 border-t border-slate-800/80">
          {!isCollapsed ? (
            <div 
              onClick={() => {
                setActiveTab('chat');
                onClose();
              }}
              className="p-2.5 rounded-xl bg-gradient-to-br from-slate-800/90 via-slate-800/60 to-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/40 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-1.5 mb-1">
                <div className="w-5 h-5 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Sparkles className="w-3 h-3" />
                </div>
                <span className="text-[11px] font-semibold text-slate-200 group-hover:text-cyan-300">
                  WeatherGPT AI
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight">
                Live met grounding & reasoning
              </p>
            </div>
          ) : (
            <button
              onClick={() => {
                setActiveTab('chat');
                onClose();
              }}
              className="w-full flex justify-center p-2 rounded-xl bg-cyan-950/50 border border-cyan-500/30 text-cyan-400 hover:scale-105 transition-all"
              title="Open WeatherGPT AI Chat"
            >
              <Sparkles className="w-4 h-4" />
            </button>
          )}
        </div>
      </aside>
    </>
  );
};

