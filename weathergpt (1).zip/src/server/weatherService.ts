import { 
  WeatherDataResponse, 
  LocationData, 
  CurrentWeather, 
  HourlyForecast, 
  DailyForecast, 
  AirQualityData, 
  WeatherAlert, 
  HistoricalClimateData 
} from '../types';
import { getWeatherCodeInfo } from '../utils/weatherCodes';

// In-memory cache for API requests with 5-minute TTL
const weatherCache = new Map<string, { data: WeatherDataResponse; timestamp: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000;

export async function searchLocations(query: string): Promise<LocationData[]> {
  if (!query || query.trim().length === 0) return [];
  const cleanQuery = query.trim();

  // Check if query is coordinates "lat, lon" or "lat,lon"
  const coordMatch = cleanQuery.match(/^([-+]?\d{1,2}(?:\.\d+)?),\s*([-+]?\d{1,3}(?:\.\d+)?)$/);
  if (coordMatch) {
    const lat = parseFloat(coordMatch[1]);
    const lon = parseFloat(coordMatch[2]);
    return [{
      name: `${lat.toFixed(3)}, ${lon.toFixed(3)}`,
      country: 'GPS Location',
      latitude: lat,
      longitude: lon,
    }];
  }

  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cleanQuery)}&count=10&language=en&format=json`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Geocoding failed with status ${res.status}`);
    const data = await res.json();
    
    if (!data.results || !Array.isArray(data.results)) {
      return [];
    }

    return data.results.map((item: any) => ({
      name: item.name,
      country: item.country || '',
      admin1: item.admin1 || '',
      admin2: item.admin2 || '',
      latitude: item.latitude,
      longitude: item.longitude,
      timezone: item.timezone || 'auto',
    }));
  } catch (error) {
    console.error('Error searching locations:', error);
    return [];
  }
}

export async function reverseGeocode(lat: number, lon: number): Promise<LocationData> {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&addressdetails=1`;
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'WeatherGPT-AI-Meteorological-Platform/1.0',
      },
    });
    if (res.ok) {
      const data = await res.json();
      const addr = data.address || {};
      const name = addr.city || addr.town || addr.village || addr.county || addr.state_district || 'Current Location';
      return {
        name,
        country: addr.country || 'India',
        admin1: addr.state || '',
        admin2: addr.state_district || addr.county || '',
        latitude: lat,
        longitude: lon,
      };
    }
  } catch (err) {
    console.warn('Reverse geocode failed, returning coordinates:', err);
  }

  return {
    name: `Location (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
    country: '',
    latitude: lat,
    longitude: lon,
  };
}

export async function fetchFullWeatherData(location: LocationData): Promise<WeatherDataResponse> {
  const cacheKey = `${location.latitude.toFixed(3)}_${location.longitude.toFixed(3)}`;
  const cached = weatherCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  const { latitude, longitude } = location;

  // 1. Fetch Forecast from Open-Meteo (Real ECMWF/GFS meteorological ensemble)
  const forecastUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,uv_index` +
    `&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,rain,showers,weather_code,pressure_msl,surface_pressure,cloud_cover,visibility,wind_speed_10m,wind_direction_10m,uv_index,is_day` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant` +
    `&timezone=auto`;

  // 2. Fetch Air Quality
  const aqiUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${latitude}&longitude=${longitude}` +
    `&current=pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone,european_aqi,us_aqi` +
    `&timezone=auto`;

  const [forecastRes, aqiRes] = await Promise.allSettled([
    fetch(forecastUrl),
    fetch(aqiUrl),
  ]);

  if (forecastRes.status !== 'fulfilled' || !forecastRes.value.ok) {
    throw new Error('Failed to retrieve real-time weather meteorological data.');
  }

  const fData = await forecastRes.value.json();
  let aqiData: any = null;
  if (aqiRes.status === 'fulfilled' && aqiRes.value.ok) {
    aqiData = await aqiRes.value.json();
  }

  // Parse Current Weather
  const cur = fData.current || {};
  const weatherInfo = getWeatherCodeInfo(cur.weather_code ?? 0, cur.is_day === 1);

  const current: CurrentWeather = {
    time: cur.time || new Date().toISOString(),
    temperature: cur.temperature_2m ?? 0,
    apparentTemperature: cur.apparent_temperature ?? cur.temperature_2m ?? 0,
    relativeHumidity: cur.relative_humidity_2m ?? 0,
    precipitation: cur.precipitation ?? 0,
    rain: cur.rain ?? 0,
    showers: cur.showers ?? 0,
    snowfall: cur.snowfall ?? 0,
    weatherCode: cur.weather_code ?? 0,
    weatherDescription: weatherInfo.description,
    weatherIcon: weatherInfo.icon,
    cloudCover: cur.cloud_cover ?? 0,
    pressureMsl: cur.pressure_msl ?? 1013,
    surfacePressure: cur.surface_pressure ?? 1013,
    windSpeed: cur.wind_speed_10m ?? 0,
    windDirection: cur.wind_direction_10m ?? 0,
    windGusts: cur.wind_gusts_10m ?? 0,
    uvIndex: cur.uv_index ?? 0,
    visibility: fData.hourly?.visibility?.[0] ?? 10000,
    isDay: cur.is_day === 1,
    sunrise: fData.daily?.sunrise?.[0] || '',
    sunset: fData.daily?.sunset?.[0] || '',
  };

  // Parse Hourly Forecast (Next 24 to 48 hours)
  const hourly: HourlyForecast[] = [];
  if (fData.hourly && Array.isArray(fData.hourly.time)) {
    const times = fData.hourly.time;
    // Find current or closest future hour index
    const nowIso = new Date().toISOString().slice(0, 13);
    let startIdx = times.findIndex((t: string) => t.slice(0, 13) >= nowIso);
    if (startIdx === -1) startIdx = 0;
    const endIdx = Math.min(startIdx + 36, times.length);

    for (let i = startIdx; i < endIdx; i++) {
      const code = fData.hourly.weather_code?.[i] ?? 0;
      const isDay = (fData.hourly.is_day?.[i] ?? 1) === 1;
      const info = getWeatherCodeInfo(code, isDay);

      hourly.push({
        time: times[i],
        temperature: fData.hourly.temperature_2m?.[i] ?? 0,
        apparentTemperature: fData.hourly.apparent_temperature?.[i] ?? 0,
        relativeHumidity: fData.hourly.relative_humidity_2m?.[i] ?? 0,
        precipitationProbability: fData.hourly.precipitation_probability?.[i] ?? 0,
        precipitation: fData.hourly.precipitation?.[i] ?? 0,
        weatherCode: code,
        weatherDescription: info.description,
        weatherIcon: info.icon,
        cloudCover: fData.hourly.cloud_cover?.[i] ?? 0,
        windSpeed: fData.hourly.wind_speed_10m?.[i] ?? 0,
        windDirection: fData.hourly.wind_direction_10m?.[i] ?? 0,
        uvIndex: fData.hourly.uv_index?.[i] ?? 0,
        isDay,
      });
    }
  }

  // Parse Daily Forecast (7 days)
  const daily: DailyForecast[] = [];
  if (fData.daily && Array.isArray(fData.daily.time)) {
    const dTimes = fData.daily.time;
    for (let i = 0; i < Math.min(dTimes.length, 7); i++) {
      const code = fData.daily.weather_code?.[i] ?? 0;
      const info = getWeatherCodeInfo(code, true);

      daily.push({
        date: dTimes[i],
        weatherCode: code,
        weatherDescription: info.description,
        weatherIcon: info.icon,
        tempMax: fData.daily.temperature_2m_max?.[i] ?? 0,
        tempMin: fData.daily.temperature_2m_min?.[i] ?? 0,
        apparentTempMax: fData.daily.apparent_temperature_max?.[i] ?? 0,
        apparentTempMin: fData.daily.apparent_temperature_min?.[i] ?? 0,
        sunrise: fData.daily.sunrise?.[i] || '',
        sunset: fData.daily.sunset?.[i] || '',
        uvIndexMax: fData.daily.uv_index_max?.[i] ?? 0,
        precipitationSum: fData.daily.precipitation_sum?.[i] ?? 0,
        precipitationProbabilityMax: fData.daily.precipitation_probability_max?.[i] ?? 0,
        windSpeedMax: fData.daily.wind_speed_10m_max?.[i] ?? 0,
        windGustsMax: fData.daily.wind_gusts_10m_max?.[i] ?? 0,
        windDirectionDominant: fData.daily.wind_direction_10m_dominant?.[i] ?? 0,
      });
    }
  }

  // Parse Air Quality
  let parsedAirQuality: AirQualityData | undefined;
  if (aqiData && aqiData.current) {
    const usAqi = aqiData.current.us_aqi ?? 45;
    const euAqi = aqiData.current.european_aqi ?? 30;
    let status: AirQualityData['status'] = 'Good';
    let advice = 'Air quality is satisfactory and poses little or no risk.';

    if (usAqi > 300) {
      status = 'Hazardous';
      advice = 'Emergency conditions. Avoid outdoor activities completely.';
    } else if (usAqi > 200) {
      status = 'Very Unhealthy';
      advice = 'Health alert: everyone may experience more serious health effects.';
    } else if (usAqi > 150) {
      status = 'Unhealthy';
      advice = 'Sensitive groups should avoid outdoor exertion. General public should reduce outdoor activities.';
    } else if (usAqi > 100) {
      status = 'Unhealthy for Sensitive Groups';
      advice = 'People with respiratory or heart conditions should limit prolonged outdoor exertion.';
    } else if (usAqi > 50) {
      status = 'Moderate';
      advice = 'Air quality is acceptable; unusually sensitive individuals should take precautions.';
    }

    parsedAirQuality = {
      usAqi,
      europeanAqi: euAqi,
      pm2_5: aqiData.current.pm2_5 ?? 15,
      pm10: aqiData.current.pm10 ?? 25,
      nitrogenDioxide: aqiData.current.nitrogen_dioxide ?? 10,
      sulphurDioxide: aqiData.current.sulphur_dioxide ?? 5,
      ozone: aqiData.current.ozone ?? 40,
      carbonMonoxide: aqiData.current.carbon_monoxide ?? 250,
      status,
      advice,
    };
  }

  // Detect Real Severe Weather Conditions & Official Alerts based on live met thresholds
  const alerts: WeatherAlert[] = [];
  const areaName = `${location.name}, ${location.admin1 ? location.admin1 + ', ' : ''}${location.country}`;

  // 1. Gale / High Wind / Cyclone Warning
  if (current.windSpeed >= 55 || current.windGusts >= 75) {
    alerts.push({
      id: `alert-wind-${Date.now()}`,
      title: current.windSpeed >= 80 ? '🔴 Severe Cyclonic Wind Advisory' : '🟠 Strong Gale Wind Alert',
      category: current.windSpeed >= 80 ? 'Cyclone' : 'Strong Wind',
      severity: current.windSpeed >= 80 ? 'extreme' : 'severe',
      area: areaName,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      source: 'Global Meteorological & NWP Wind Alert System',
      description: `Sustained high wind speeds of ${Math.round(current.windSpeed)} km/h with gusts exceeding ${Math.round(current.windGusts)} km/h detected. Potential structural damage, flying debris, and uprooted trees.`,
      recommendedAction: 'Secure loose outdoor items, stay indoors away from windows, and avoid coastal or highland areas.',
      coordinates: { latitude, longitude },
    });
  }

  // 2. Heavy Rainfall / Flood Risk
  const maxRain = Math.max(
    current.precipitation,
    ...daily.map(d => d.precipitationSum),
    ...hourly.slice(0, 12).map(h => h.precipitation)
  );
  if (maxRain >= 30 || current.weatherCode === 65 || current.weatherCode === 82) {
    alerts.push({
      id: `alert-rain-${Date.now()}`,
      title: maxRain >= 65 ? '🔴 Extreme Heavy Rainfall & Flash Flood Warning' : '🟠 Heavy Rainfall Advisory',
      category: maxRain >= 65 ? 'Flood' : 'Heavy Rain',
      severity: maxRain >= 65 ? 'extreme' : 'severe',
      area: areaName,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 36 * 3600 * 1000).toISOString(),
      source: 'Meteorological Precipitation Radar & Flood Risk Model',
      description: `Substantial precipitation accumulation (${maxRain.toFixed(1)} mm) observed or forecast. Waterlogging and flash flooding possible in low-lying areas.`,
      recommendedAction: 'Avoid driving through flooded underpasses, move valuable equipment to higher ground, and follow local drainage guidance.',
      coordinates: { latitude, longitude },
    });
  }

  // 3. Severe Thunderstorm & Lightning
  if (current.weatherCode >= 95 || daily.some(d => d.weatherCode >= 95)) {
    alerts.push({
      id: `alert-storm-${Date.now()}`,
      title: '🟠 Severe Thunderstorm & Lightning Warning',
      category: 'Thunderstorm',
      severity: 'severe',
      area: areaName,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 12 * 3600 * 1000).toISOString(),
      source: 'WMO Convective Atmospheric Instability Index',
      description: 'Active convective cloud clusters with frequent cloud-to-ground lightning and convective downdrafts.',
      recommendedAction: 'Seek shelter in enclosed buildings, unplug sensitive electronic devices, and do not stand under isolated trees or near metal towers.',
      coordinates: { latitude, longitude },
    });
  }

  // 4. Extreme Heatwave Warning
  if (current.temperature >= 40 || daily.some(d => d.tempMax >= 42)) {
    alerts.push({
      id: `alert-heat-${Date.now()}`,
      title: current.temperature >= 43 ? '🔴 Extreme Heatwave Warning' : '🟡 Heatwave Caution',
      category: 'Heatwave',
      severity: current.temperature >= 43 ? 'extreme' : 'moderate',
      area: areaName,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
      source: 'National Meteorological Thermal Hazard Index',
      description: `Ambient temperatures reaching ${Math.round(current.temperature)}°C with high solar heat index. Risk of heatstroke and thermal dehydration.`,
      recommendedAction: 'Stay hydrated with electrolytes, avoid direct sunlight between 11 AM and 4 PM, and check on vulnerable family members.',
      coordinates: { latitude, longitude },
    });
  }

  const result: WeatherDataResponse = {
    location,
    current,
    hourly,
    daily,
    airQuality: parsedAirQuality,
    alerts,
    source: 'Open-Meteo Global Meteorological Integration (ECMWF, GFS, DWD, NOAA)',
    updatedAt: new Date().toISOString(),
  };

  weatherCache.set(cacheKey, { data: result, timestamp: Date.now() });
  return result;
}

export async function fetchHistoricalClimate(
  location: LocationData,
  yearsBack: number = 1
): Promise<HistoricalClimateData> {
  const { latitude, longitude } = location;
  const now = new Date();
  
  // Historical archive end date is usually yesterday or 2 days ago
  const endDateObj = new Date(now.getTime() - 2 * 24 * 3600 * 1000);
  const startDateObj = new Date(endDateObj.getTime() - yearsBack * 365 * 24 * 3600 * 1000);

  const startDate = startDateObj.toISOString().slice(0, 10);
  const endDate = endDateObj.toISOString().slice(0, 10);

  const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${latitude}&longitude=${longitude}` +
    `&start_date=${startDate}&end_date=${endDate}` +
    `&daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean,precipitation_sum,rain_sum,wind_speed_10m_max` +
    `&timezone=auto`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to retrieve real historical climate archive (status ${res.status}).`);
  }

  const data = await res.json();
  const d = data.daily || {};
  const times: string[] = d.time || [];

  if (times.length === 0) {
    throw new Error('Historical climate data is unavailable for this coordinates range.');
  }

  let totalTempMean = 0;
  let validTempCount = 0;
  let maxTempRecord = { temp: -999, date: '' };
  let minTempRecord = { temp: 999, date: '' };
  let totalRain = 0;
  let rainiestDay = { rain: 0, date: '' };
  let dryDays = 0;
  let wetDays = 0;

  // Sample or aggregate data to keep chart responsive (e.g. weekly or monthly aggregates for 5-10 yrs)
  const step = yearsBack > 3 ? (yearsBack >= 10 ? 7 : 3) : 1;
  const timeSeries = [];

  for (let i = 0; i < times.length; i += step) {
    const date = times[i];
    const tMax = d.temperature_2m_max?.[i] ?? 0;
    const tMin = d.temperature_2m_min?.[i] ?? 0;
    const tMean = d.temperature_2m_mean?.[i] ?? (tMax + tMin) / 2;
    const pSum = d.precipitation_sum?.[i] ?? 0;
    const rSum = d.rain_sum?.[i] ?? pSum;
    const wMax = d.wind_speed_10m_max?.[i] ?? 0;

    if (tMean !== null) {
      totalTempMean += tMean;
      validTempCount++;
    }

    if (tMax > maxTempRecord.temp) {
      maxTempRecord = { temp: tMax, date };
    }
    if (tMin < minTempRecord.temp) {
      minTempRecord = { temp: tMin, date };
    }

    totalRain += pSum;
    if (pSum > rainiestDay.rain) {
      rainiestDay = { rain: pSum, date };
    }

    if (pSum < 0.1) dryDays++;
    else wetDays++;

    timeSeries.push({
      date,
      tempMax: tMax,
      tempMin: tMin,
      tempMean: tMean,
      precipitationSum: pSum,
      rainSum: rSum,
      windSpeedMax: wMax,
    });
  }

  const avgTemp = validTempCount > 0 ? parseFloat((totalTempMean / validTempCount).toFixed(1)) : 0;

  return {
    timeSeries,
    summary: {
      avgTemp,
      maxTempRecord,
      minTempRecord,
      totalRainfall: parseFloat(totalRain.toFixed(1)),
      rainiestDay,
      dryDaysCount: dryDays,
      wetDaysCount: wetDays,
    },
    periodYears: yearsBack,
    location,
    source: 'Open-Meteo Historical Meteorological Archive (ERA5 Reanalysis 1940-Present)',
  };
}
