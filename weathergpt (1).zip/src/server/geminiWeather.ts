import { GoogleGenAI, Modality } from '@google/genai';
import { 
  LocationData, 
  SupportedLanguage, 
  WeatherDataResponse, 
  AgriAdvisoryRequest, 
  AgriAdvisoryResponse 
} from '../types';
import { fetchFullWeatherData, searchLocations } from './weatherService';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

const LANGUAGE_NAMES: Record<SupportedLanguage, string> = {
  en: 'English',
  ta: 'Tamil (தமிழ்)',
  hi: 'Hindi (हिन्दी)',
  te: 'Telugu (తెలుగు)',
  kn: 'Kannada (ಕನ್ನಡ)',
  ml: 'Malayalam (മലയാളം)',
  bn: 'Bengali (বাংলা)',
  mr: 'Marathi (मराठी)',
};

export async function processWeatherQuery(params: {
  query: string;
  defaultLocation: LocationData;
  language: SupportedLanguage;
  conversationHistory?: Array<{ sender: 'user' | 'assistant'; content: string }>;
}): Promise<{
  response: string;
  groundingData: any;
  resolvedLocation: LocationData;
}> {
  const { query, defaultLocation, language, conversationHistory = [] } = params;
  const ai = getAiClient();

  // Step 1: Query Understanding & Parameter Extraction with Gemini
  let resolvedLocation = defaultLocation;
  let targetLocationName = '';
  let timeRange = 'current/next 24 hours';

  try {
    const extractionPrompt = `You are a meteorological query parser. Given the user query, identify:
1. Target location name (if a city, state, or place is mentioned, e.g. "Chennai", "Coimbatore", "Delhi", "Bengaluru", "Mumbai", "London", "Tokyo", etc.). If no specific location is mentioned, leave it empty.
2. Time horizon (e.g., "today", "tomorrow", "this weekend", "next 7 days", "current").
3. Core intent (e.g., "rain_check", "temperature_check", "travel_safety", "cyclone_warning", "agri_irrigation", "general_forecast", "city_comparison").

User query: "${query}"
Default user location: ${defaultLocation.name}, ${defaultLocation.country}

Return ONLY valid JSON in this exact structure without markdown:
{"locationName": "...", "timeRange": "...", "intent": "..."}`;

    const extractionRes = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: extractionPrompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsedJson = JSON.parse(extractionRes.text || '{}');
    if (parsedJson.locationName && parsedJson.locationName.trim().length > 0) {
      targetLocationName = parsedJson.locationName.trim();
      const searchRes = await searchLocations(targetLocationName);
      if (searchRes && searchRes.length > 0) {
        resolvedLocation = searchRes[0];
      }
    }
    if (parsedJson.timeRange) {
      timeRange = parsedJson.timeRange;
    }
  } catch (err) {
    console.warn('Intent parsing fallback to default location:', err);
  }

  // Step 2: Fetch REAL weather data from Open-Meteo Meteorological Network
  const weatherData: WeatherDataResponse = await fetchFullWeatherData(resolvedLocation);

  // Step 3: Meteorological Reasoning with Grounded Facts
  const targetLanguageName = LANGUAGE_NAMES[language] || 'English';

  const historyContext = conversationHistory
    .slice(-4)
    .map(h => `${h.sender === 'user' ? 'User' : 'WeatherGPT'}: ${h.content}`)
    .join('\n');

  const reasoningSystemPrompt = `You are WeatherGPT, a premier AI Meteorological Intelligence Assistant.
YOUR CORE DIRECTIVE:
1. Ground every weather fact, temperature, rain chance, wind speed, and humidity strictly in the provided verified meteorological dataset below.
2. NEVER invent, hallucinate, or assume temperatures, rain percentages, cyclone alerts, or severe warnings.
3. Structure your response cleanly with clear section headings or bullet points:
   - 🌤️ **Observed / Current Weather**: (Temperature, feels-like, condition, humidity, wind)
   - 📅 **Forecast Breakdown**: (Specific to the requested time horizon: ${timeRange})
   - ⚠️ **Severe Weather Status**: (Active official alerts or state that no official warnings are active)
   - 💡 **AI Meteorological Advisory & Recommendations**: (Practical guidance on clothing, umbrella, travel safety, commute, outdoor plans, or farming based strictly on the facts)
4. Clearly distinguish between verified observed weather, forecast projections, and AI-generated advisory recommendations.
5. YOU MUST ANSWER ENTIRELY IN THE REQUESTED LANGUAGE: ${targetLanguageName} (${language}). Ensure fluent, natural phrasing and proper Unicode typography for Indian languages.
6. Always mention the meteorological data source: "${weatherData.source}" and update timestamp: "${new Date(weatherData.updatedAt).toLocaleTimeString()}".`;

  const meteorologicalContext = JSON.stringify({
    location: {
      name: resolvedLocation.name,
      admin1: resolvedLocation.admin1,
      country: resolvedLocation.country,
      coordinates: `${resolvedLocation.latitude}, ${resolvedLocation.longitude}`,
    },
    current: weatherData.current,
    next12HoursHourly: weatherData.hourly.slice(0, 12),
    sevenDayOutlook: weatherData.daily,
    airQuality: weatherData.airQuality,
    activeAlerts: weatherData.alerts,
    source: weatherData.source,
    updatedAt: weatherData.updatedAt,
  });

  const promptContent = `Conversation context:
${historyContext ? historyContext + '\n' : ''}
User Query: "${query}"

Verified Meteorological Ground Truth Data:
${meteorologicalContext}

Provide a comprehensive, accurate, and helpful WeatherGPT response in ${targetLanguageName}.`;

  const answerRes = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: promptContent,
    config: {
      systemInstruction: reasoningSystemPrompt,
      temperature: 0.3, // Low temperature for high factual precision
    },
  });

  const finalResponse = answerRes.text || 'Unable to generate meteorological response.';

  const groundingData = {
    locationName: `${resolvedLocation.name}, ${resolvedLocation.admin1 ? resolvedLocation.admin1 + ', ' : ''}${resolvedLocation.country}`,
    temperature: weatherData.current.temperature,
    weatherCondition: weatherData.current.weatherDescription,
    precipitationChance: weatherData.daily[0]?.precipitationProbabilityMax ?? 0,
    dataSource: weatherData.source,
    updatedAt: weatherData.updatedAt,
    alertCategory: weatherData.alerts.length > 0 ? weatherData.alerts[0].category : undefined,
    timeRange,
  };

  return {
    response: finalResponse,
    groundingData,
    resolvedLocation,
  };
}

export async function generateAgriAdvisory(req: AgriAdvisoryRequest): Promise<AgriAdvisoryResponse> {
  const { crop, location, growthStage, irrigationMethod, language } = req;
  const weatherData = await fetchFullWeatherData(location);
  const ai = getAiClient();

  const targetLangName = LANGUAGE_NAMES[language] || 'English';

  const systemInstruction = `You are the WeatherGPT Agriculture Intelligence System.
Evaluate the 7-day meteorological forecast against the selected crop, growth stage, and irrigation method.
Generate an actionable agronomic advisory covering:
- Irrigation scheduling (whether to irrigate or avoid due to expected rainfall)
- Heat/cold stress mitigation
- Spraying condition window (pesticide/fertilizer drift risk based on wind and rain)
- Fungal/pest risk under current humidity and temperature
- Harvesting readiness advice

Return the result strictly as a valid JSON object matching the requested schema. The aiAdvisoryText must be written in ${targetLangName}.`;

  const prompt = `Crop: ${crop}
Growth Stage: ${growthStage}
Irrigation Method: ${irrigationMethod}
Location: ${location.name}, ${location.admin1}, ${location.country}
Language: ${targetLangName}

Meteorological 7-Day Forecast & Live Observations:
${JSON.stringify({
  current: weatherData.current,
  daily: weatherData.daily,
  hourly48h: weatherData.hourly.slice(0, 24),
})}

Return ONLY JSON with this structure:
{
  "irrigationRecommendation": {
    "status": "Irrigate Today" | "Delay Irrigation (Rain Expected)" | "Reduced Irrigation" | "Adequate Moisture",
    "reason": "..."
  },
  "heatStressRisk": {
    "level": "Low" | "Moderate" | "High" | "Severe",
    "mitigation": "..."
  },
  "spraySuitability": {
    "suitable": true | false,
    "condition": "...",
    "windNote": "...",
    "rainWindow": "..."
  },
  "diseasePestRisk": {
    "riskLevel": "Low" | "Moderate" | "High",
    "likelyConditions": "...",
    "prevention": "..."
  },
  "harvestSuitability": {
    "suitable": true | false,
    "outlook": "..."
  },
  "aiAdvisoryText": "Full comprehensive agronomic guidance written in ${targetLangName} with clear bullet points"
}`;

  const res = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.3,
    },
  });

  const parsed = JSON.parse(res.text || '{}');

  return {
    crop,
    growthStage,
    irrigationRecommendation: parsed.irrigationRecommendation || {
      status: 'Adequate Moisture',
      reason: 'Soil moisture levels are currently balanced based on recent meteorological humidity.',
    },
    heatStressRisk: parsed.heatStressRisk || {
      level: 'Low',
      mitigation: 'Standard canopy management recommended.',
    },
    spraySuitability: parsed.spraySuitability || {
      suitable: true,
      condition: 'Favorable winds below 15 km/h.',
      windNote: 'Normal drift risk.',
      rainWindow: 'No rain expected in the next 12 hours.',
    },
    diseasePestRisk: parsed.diseasePestRisk || {
      riskLevel: 'Moderate',
      likelyConditions: 'High humidity may encourage fungal sporulation.',
      prevention: 'Maintain proper plant spacing and crop scouting.',
    },
    harvestSuitability: parsed.harvestSuitability || {
      suitable: true,
      outlook: 'Dry spell suitable for harvesting and threshing.',
    },
    aiAdvisoryText: parsed.aiAdvisoryText || 'Standard agricultural advisory generated.',
    weatherSnapshot: {
      tempMax: weatherData.daily[0]?.tempMax ?? weatherData.current.temperature,
      rainChance: weatherData.daily[0]?.precipitationProbabilityMax ?? 0,
      humidity: weatherData.current.relativeHumidity,
      windSpeed: weatherData.current.windSpeed,
    },
    updatedAt: new Date().toISOString(),
  };
}

export async function generateSpeechAudio(text: string): Promise<string | null> {
  try {
    const ai = getAiClient();
    const cleanText = text.replace(/[*#_`]/g, '').slice(0, 400); // Clean markdown and clip for fast TTS response
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-tts-preview',
      contents: [{ parts: [{ text: `Speak in a clear, friendly meteorological broadcast tone: ${cleanText}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch (err) {
    console.warn('Gemini TTS synthesis fallback to browser Web Speech API:', err);
    return null;
  }
}
