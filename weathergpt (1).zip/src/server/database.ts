import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { UserProfile, LocationData, ChatConversation, SupportedLanguage } from '../types';

interface DBUser {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  avatarUrl?: string;
  preferredLanguage: SupportedLanguage;
  defaultLocation: LocationData;
  temperatureUnit: 'celsius' | 'fahrenheit';
  windSpeedUnit: 'kmh' | 'mph' | 'ms';
  notificationPreferences: {
    severeWeather: boolean;
    rainAlerts: boolean;
    heatAlerts: boolean;
    cycloneAlerts: boolean;
    dailyBriefing: boolean;
  };
  savedLocations: LocationData[];
  createdAt: string;
}

interface DBSchema {
  users: DBUser[];
  conversations: Record<string, ChatConversation[]>; // userId -> conversations
  sessions: Record<string, { userId: string; expiresAt: number }>; // token -> session
}

const DB_FILE = path.join(process.cwd(), 'data', 'weathergpt-db.json');

// Ensure data directory exists
function ensureDbDir() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Initial state with a realistic default user if needed, but allows real sign-ups and logins
const DEFAULT_CHENNAI_LOCATION: LocationData = {
  name: 'Chennai',
  country: 'India',
  admin1: 'Tamil Nadu',
  latitude: 13.0827,
  longitude: 80.2707,
  timezone: 'Asia/Kolkata',
  tag: 'Home',
  isDefault: true,
};

function readDB(): DBSchema {
  ensureDbDir();
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading database file, initializing empty store:', err);
  }

  // Initial seed user for demo/immediate login convenience if needed
  const initialUser: DBUser = {
    id: 'user-default-1',
    email: 'anizaid35@gmail.com',
    passwordHash: hashPassword('weather123'),
    name: 'Anis Zaid',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    preferredLanguage: 'en',
    defaultLocation: DEFAULT_CHENNAI_LOCATION,
    temperatureUnit: 'celsius',
    windSpeedUnit: 'kmh',
    notificationPreferences: {
      severeWeather: true,
      rainAlerts: true,
      heatAlerts: true,
      cycloneAlerts: true,
      dailyBriefing: true,
    },
    savedLocations: [
      DEFAULT_CHENNAI_LOCATION,
      {
        name: 'Coimbatore',
        country: 'India',
        admin1: 'Tamil Nadu',
        latitude: 11.0168,
        longitude: 76.9558,
        tag: 'Office',
      },
      {
        name: 'Bengaluru',
        country: 'India',
        admin1: 'Karnataka',
        latitude: 12.9716,
        longitude: 77.5946,
        tag: 'Farm',
      },
      {
        name: 'Mumbai',
        country: 'India',
        admin1: 'Maharashtra',
        latitude: 19.0760,
        longitude: 72.8777,
        tag: 'Custom',
      },
    ],
    createdAt: new Date().toISOString(),
  };

  const initialDB: DBSchema = {
    users: [initialUser],
    conversations: {},
    sessions: {},
  };
  writeDB(initialDB);
  return initialDB;
}

function writeDB(data: DBSchema) {
  ensureDbDir();
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing to DB file:', err);
  }
}

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_weathergpt_salt_2026').digest('hex');
}

export function createSession(userId: string): string {
  const token = 'wgpt_' + crypto.randomBytes(32).toString('hex');
  const db = readDB();
  db.sessions[token] = {
    userId,
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
  };
  writeDB(db);
  return token;
}

export function getUserByToken(token: string): DBUser | null {
  if (!token) return null;
  const db = readDB();
  const session = db.sessions[token];
  if (!session || session.expiresAt < Date.now()) {
    return null;
  }
  const user = db.users.find(u => u.id === session.userId);
  return user || null;
}

export function removeSession(token: string) {
  const db = readDB();
  delete db.sessions[token];
  writeDB(db);
}

export function findUserByEmail(email: string): DBUser | null {
  const db = readDB();
  return db.users.find(u => u.email.toLowerCase() === email.toLowerCase().trim()) || null;
}

export function createUser(params: {
  name: string;
  email: string;
  password?: string;
  preferredLanguage?: SupportedLanguage;
  defaultLocation?: LocationData;
}): { user: DBUser; token: string } {
  const db = readDB();
  const existing = findUserByEmail(params.email);
  if (existing) {
    throw new Error('An account with this email address already exists.');
  }

  const newUser: DBUser = {
    id: 'user_' + crypto.randomBytes(8).toString('hex'),
    email: params.email.toLowerCase().trim(),
    passwordHash: params.password ? hashPassword(params.password) : hashPassword('oauth_google_verified'),
    name: params.name || 'Meteorologist',
    preferredLanguage: params.preferredLanguage || 'en',
    defaultLocation: params.defaultLocation || DEFAULT_CHENNAI_LOCATION,
    temperatureUnit: 'celsius',
    windSpeedUnit: 'kmh',
    notificationPreferences: {
      severeWeather: true,
      rainAlerts: true,
      heatAlerts: true,
      cycloneAlerts: true,
      dailyBriefing: true,
    },
    savedLocations: [params.defaultLocation || DEFAULT_CHENNAI_LOCATION],
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);
  writeDB(db);

  const token = createSession(newUser.id);
  return { user: newUser, token };
}

export function updateUserProfile(userId: string, updates: Partial<DBUser>): DBUser {
  const db = readDB();
  const index = db.users.findIndex(u => u.id === userId);
  if (index === -1) {
    throw new Error('User not found');
  }

  db.users[index] = {
    ...db.users[index],
    ...updates,
  };
  writeDB(db);
  return db.users[index];
}

export function getUserSavedLocations(userId: string): LocationData[] {
  const db = readDB();
  const user = db.users.find(u => u.id === userId);
  return user ? user.savedLocations : [];
}

export function addSavedLocation(userId: string, location: LocationData): LocationData[] {
  const db = readDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) throw new Error('User not found');

  // Check if exists
  const exists = user.savedLocations.some(
    loc => Math.abs(loc.latitude - location.latitude) < 0.05 && Math.abs(loc.longitude - location.longitude) < 0.05
  );

  if (!exists) {
    user.savedLocations.push({
      ...location,
      id: 'loc_' + crypto.randomBytes(6).toString('hex'),
    });
    writeDB(db);
  }
  return user.savedLocations;
}

export function removeSavedLocation(userId: string, locationName: string): LocationData[] {
  const db = readDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) throw new Error('User not found');

  user.savedLocations = user.savedLocations.filter(loc => loc.name.toLowerCase() !== locationName.toLowerCase());
  writeDB(db);
  return user.savedLocations;
}

export function getConversations(userId: string): ChatConversation[] {
  const db = readDB();
  return db.conversations[userId] || [];
}

export function saveConversation(userId: string, conversation: ChatConversation) {
  const db = readDB();
  if (!db.conversations[userId]) {
    db.conversations[userId] = [];
  }
  const existingIdx = db.conversations[userId].findIndex(c => c.id === conversation.id);
  if (existingIdx >= 0) {
    db.conversations[userId][existingIdx] = conversation;
  } else {
    db.conversations[userId].unshift(conversation);
  }
  writeDB(db);
}

export function deleteConversation(userId: string, conversationId: string) {
  const db = readDB();
  if (db.conversations[userId]) {
    db.conversations[userId] = db.conversations[userId].filter(c => c.id !== conversationId);
    writeDB(db);
  }
}
