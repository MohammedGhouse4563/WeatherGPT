// Shared TypeScript types for WeatherGPT

export type SupportedLanguage = 
  | 'en' // English
  | 'ta' // Tamil
  | 'hi' // Hindi
  | 'te' // Telugu
  | 'kn' // Kannada
  | 'ml' // Malayalam
  | 'bn' // Bengali
  | 'mr'; // Marathi

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
}

export type TemperatureUnit = 'celsius' | 'fahrenheit';
export type WindSpeedUnit = 'kmh' | 'mph' | 'ms';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  preferredLanguage: SupportedLanguage;
  defaultLocation: LocationData;
  temperatureUnit: TemperatureUnit;
  windSpeedUnit: WindSpeedUnit;
  notificationPreferences: {
    severeWeather: boolean;
    rainAlerts: boolean;
    heatAlerts: boolean;
    cycloneAlerts: boolean;
    dailyBriefing: boolean;
  };
  createdAt: string;
}

export interface LocationData {
  id?: string;
  name: string;
  country: string;
  admin1?: string; // State / Province
  admin2?: string; // District
  latitude: number;
  longitude: number;
  timezone?: string;
  tag?: 'Home' | 'Office' | 'Farm' | 'College' | 'Custom';
  isDefault?: boolean;
}

export interface CurrentWeather {
  time: string;
  temperature: number;
  apparentTemperature: number;
  relativeHumidity: number;
  precipitation: number;
  rain: number;
  showers: number;
  snowfall: number;
  weatherCode: number;
  weatherDescription: string;
  weatherIcon: string;
  cloudCover: number;
  pressureMsl: number;
  surfacePressure: number;
  windSpeed: number;
  windDirection: number;
  windGusts: number;
  uvIndex: number;
  visibility: number;
  isDay: boolean;
  sunrise?: string;
  sunset?: string;
}

export interface HourlyForecast {
  time: string;
  temperature: number;
  apparentTemperature: number;
  relativeHumidity: number;
  precipitationProbability: number;
  precipitation: number;
  weatherCode: number;
  weatherDescription: string;
  weatherIcon: string;
  cloudCover: number;
  windSpeed: number;
  windDirection: number;
  uvIndex: number;
  isDay: boolean;
}

export interface DailyForecast {
  date: string;
  weatherCode: number;
  weatherDescription: string;
  weatherIcon: string;
  tempMax: number;
  tempMin: number;
  apparentTempMax: number;
  apparentTempMin: number;
  sunrise: string;
  sunset: string;
  uvIndexMax: number;
  precipitationSum: number;
  precipitationProbabilityMax: number;
  windSpeedMax: number;
  windGustsMax: number;
  windDirectionDominant: number;
}

export interface AirQualityData {
  usAqi: number;
  europeanAqi: number;
  pm2_5: number;
  pm10: number;
  nitrogenDioxide: number;
  sulphurDioxide: number;
  ozone: number;
  carbonMonoxide: number;
  status: 'Good' | 'Moderate' | 'Unhealthy for Sensitive Groups' | 'Unhealthy' | 'Very Unhealthy' | 'Hazardous';
  advice: string;
}

export type AlertSeverity = 'extreme' | 'severe' | 'moderate' | 'information';
export type AlertCategory = 
  | 'Cyclone' 
  | 'Heavy Rain' 
  | 'Flood' 
  | 'Thunderstorm' 
  | 'Lightning' 
  | 'Heatwave' 
  | 'Cold wave' 
  | 'Strong Wind' 
  | 'Drought' 
  | 'Marine Warning'
  | 'General Advisory';

export interface WeatherAlert {
  id: string;
  title: string;
  category: AlertCategory;
  severity: AlertSeverity;
  area: string;
  startTime: string;
  endTime: string;
  source: string;
  description: string;
  recommendedAction: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface WeatherDataResponse {
  location: LocationData;
  current: CurrentWeather;
  hourly: HourlyForecast[];
  daily: DailyForecast[];
  airQuality?: AirQualityData;
  alerts: WeatherAlert[];
  source: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  language?: SupportedLanguage;
  groundingData?: {
    locationName?: string;
    temperature?: number;
    weatherCondition?: string;
    precipitationChance?: number;
    dataSource?: string;
    updatedAt?: string;
    alertCategory?: string;
    timeRange?: string;
  };
  audioBase64?: string;
}

export interface ChatConversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
  language?: SupportedLanguage;
}

export interface HistoricalClimateData {
  timeSeries: {
    date: string;
    tempMax: number;
    tempMin: number;
    tempMean: number;
    precipitationSum: number;
    rainSum: number;
    windSpeedMax: number;
  }[];
  summary: {
    avgTemp: number;
    maxTempRecord: { temp: number; date: string };
    minTempRecord: { temp: number; date: string };
    totalRainfall: number;
    rainiestDay: { rain: number; date: string };
    dryDaysCount: number;
    wetDaysCount: number;
  };
  periodYears: number;
  location: LocationData;
  source: string;
}

export interface AgriAdvisoryRequest {
  crop: string;
  location: LocationData;
  growthStage: string;
  irrigationMethod: string;
  language: SupportedLanguage;
}

export interface AgriAdvisoryResponse {
  crop: string;
  growthStage: string;
  irrigationRecommendation: {
    status: 'Irrigate Today' | 'Delay Irrigation (Rain Expected)' | 'Reduced Irrigation' | 'Adequate Moisture';
    reason: string;
  };
  heatStressRisk: {
    level: 'Low' | 'Moderate' | 'High' | 'Severe';
    mitigation: string;
  };
  spraySuitability: {
    suitable: boolean;
    condition: string;
    windNote: string;
    rainWindow: string;
  };
  diseasePestRisk: {
    riskLevel: 'Low' | 'Moderate' | 'High';
    likelyConditions: string;
    prevention: string;
  };
  harvestSuitability: {
    suitable: boolean;
    outlook: string;
  };
  aiAdvisoryText: string;
  weatherSnapshot: {
    tempMax: number;
    rainChance: number;
    humidity: number;
    windSpeed: number;
  };
  updatedAt: string;
}
