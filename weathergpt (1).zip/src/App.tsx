import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { WeatherProvider, useWeather } from './context/WeatherContext';
import { AuthPage } from './pages/AuthPage';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { VoiceModal } from './components/VoiceModal';
import { NotificationModal } from './components/NotificationModal';

import { DashboardPage } from './pages/DashboardPage';
import { AiChatPage } from './pages/AiChatPage';
import { ForecastPage } from './pages/ForecastPage';
import { WeatherMapPage } from './pages/WeatherMapPage';
import { AgriculturePage } from './pages/AgriculturePage';
import { AlertsPage } from './pages/AlertsPage';
import { ClimatePage } from './pages/ClimatePage';
import { ComparisonPage } from './pages/ComparisonPage';
import { SettingsPage } from './pages/SettingsPage';
import { DisasterCenterPage } from './pages/DisasterCenterPage';
import { TripPlannerPage } from './pages/TripPlannerPage';

const MainAppLayout: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);
  const [isNotifOpen, setIsNotifOpen] = useState<boolean>(false);
  const [chatInitialQuery, setChatInitialQuery] = useState<string>('');

  if (!user) {
    return <AuthPage />;
  }

  const handleNavigate = (tab: string, query?: string) => {
    setActiveTab(tab);
    if (query) {
      setChatInitialQuery(query);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Navbar */}
      <Navbar
        onOpenVoice={() => setIsVoiceOpen(true)}
        onOpenNotifications={() => setIsNotifOpen(true)}
        onNavigate={handleNavigate}
      />

      {/* Body: Sleek Desktop Sidebar + Dynamic Page Content with minimized left gap */}
      <div className="flex-1 flex w-full max-w-[1600px] mx-auto px-2.5 sm:px-4 lg:px-5 pt-3.5 pb-20 md:pb-6 gap-3 sm:gap-4">
        
        {/* Desktop Sidebar (Collapsible & Space Optimized) */}
        <Sidebar activeTab={activeTab} setActiveTab={handleNavigate} />

        {/* Dynamic Main Workspace */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <DashboardPage
              onNavigate={handleNavigate}
              onOpenVoice={() => setIsVoiceOpen(true)}
            />
          )}

          {activeTab === 'chat' && (
            <AiChatPage
              initialQuery={chatInitialQuery}
              onOpenVoiceModal={() => setIsVoiceOpen(true)}
            />
          )}

          {activeTab === 'forecast' && <ForecastPage />}

          {activeTab === 'map' && <WeatherMapPage />}

          {activeTab === 'trip' && <TripPlannerPage />}

          {activeTab === 'agriculture' && <AgriculturePage />}

          {activeTab === 'alerts' && (
            <AlertsPage onNavigateToDisaster={() => handleNavigate('disaster')} />
          )}

          {activeTab === 'climate' && <ClimatePage />}

          {activeTab === 'compare' && <ComparisonPage />}

          {activeTab === 'settings' && <SettingsPage />}

          {activeTab === 'disaster' && <DisasterCenterPage />}
        </main>

      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileNav activeTab={activeTab} setActiveTab={handleNavigate} />

      {/* Voice Assistant Modal */}
      <VoiceModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onNavigateToChat={(q) => handleNavigate('chat', q)}
      />

      {/* Severe Alerts & Notification Drawer */}
      <NotificationModal
        isOpen={isNotifOpen}
        onClose={() => setIsNotifOpen(false)}
        onNavigateToAlerts={() => handleNavigate('alerts')}
      />

    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <WeatherProvider>
        <MainAppLayout />
      </WeatherProvider>
    </AuthProvider>
  );
}
