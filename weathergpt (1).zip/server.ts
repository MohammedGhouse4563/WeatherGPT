import express from 'express';
import path from 'path';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import { 
  createUser, 
  findUserByEmail, 
  getUserByToken, 
  hashPassword, 
  createSession, 
  removeSession, 
  updateUserProfile,
  getUserSavedLocations,
  addSavedLocation,
  removeSavedLocation,
  getConversations,
  saveConversation,
  deleteConversation
} from './src/server/database';
import { 
  searchLocations, 
  reverseGeocode, 
  fetchFullWeatherData, 
  fetchHistoricalClimate 
} from './src/server/weatherService';
import { 
  processWeatherQuery, 
  generateAgriAdvisory, 
  generateSpeechAudio 
} from './src/server/geminiWeather';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: '10mb' }));

  // Auth Middleware
  const authMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    const token = authHeader.substring(7);
    const user = getUserByToken(token);
    if (!user) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    (req as any).user = user;
    (req as any).token = token;
    next();
  };

  // Optional Auth Middleware (attaches user if token present)
  const optionalAuthMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const user = getUserByToken(token);
      if (user) {
        (req as any).user = user;
        (req as any).token = token;
      }
    }
    next();
  };

  // --- API Endpoints ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      service: 'WeatherGPT AI Meteorological Intelligence API', 
      timestamp: new Date().toISOString() 
    });
  });

  // Authentication: Register
  app.post('/api/auth/register', (req, res) => {
    try {
      const { name, email, password, preferredLanguage, defaultLocation } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }
      const { user, token } = createUser({
        name: name || email.split('@')[0],
        email,
        password,
        preferredLanguage,
        defaultLocation,
      });

      const { passwordHash, ...safeUser } = user;
      res.json({ user: safeUser, token });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Registration failed' });
    }
  });

  // Authentication: Login
  app.post('/api/auth/login', (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }

      const user = findUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }

      const hashed = hashPassword(password);
      if (user.passwordHash !== hashed) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }

      const token = createSession(user.id);
      const { passwordHash, ...safeUser } = user;
      res.json({ user: safeUser, token });
    } catch (err: any) {
      res.status(500).json({ error: 'Login failed: ' + err.message });
    }
  });

  // Authentication: Google OAuth Sign-In simulation / real Google Token verification
  app.post('/api/auth/google', (req, res) => {
    try {
      const { email, name, avatarUrl, preferredLanguage } = req.body;
      if (!email) {
        return res.status(400).json({ error: 'Google email is required' });
      }

      let user = findUserByEmail(email);
      let token = '';

      if (!user) {
        const created = createUser({
          name: name || 'Google User',
          email,
          preferredLanguage: preferredLanguage || 'en',
        });
        user = created.user;
        token = created.token;
      } else {
        token = createSession(user.id);
      }

      if (avatarUrl && (!user.avatarUrl || user.avatarUrl !== avatarUrl)) {
        user = updateUserProfile(user.id, { avatarUrl });
      }

      const { passwordHash, ...safeUser } = user;
      res.json({ user: safeUser, token });
    } catch (err: any) {
      res.status(500).json({ error: 'Google Authentication failed: ' + err.message });
    }
  });

  // Authentication: Logout
  app.post('/api/auth/logout', authMiddleware, (req, res) => {
    try {
      const token = (req as any).token;
      removeSession(token);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: 'Logout failed' });
    }
  });

  // Authentication: Get Current User Profile
  app.get('/api/auth/me', authMiddleware, (req, res) => {
    const user = (req as any).user;
    const { passwordHash, ...safeUser } = user;
    res.json({ user: safeUser });
  });

  // Profile update
  app.put('/api/profile', authMiddleware, (req, res) => {
    try {
      const user = (req as any).user;
      const updates = req.body;
      const updatedUser = updateUserProfile(user.id, updates);
      const { passwordHash, ...safeUser } = updatedUser;
      res.json({ user: safeUser });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update profile' });
    }
  });

  // Location search autocomplete
  app.get('/api/locations/search', async (req, res) => {
    try {
      const q = req.query.q as string;
      const results = await searchLocations(q);
      res.json({ results });
    } catch (err: any) {
      res.status(500).json({ error: 'Location search failed' });
    }
  });

  // Reverse geocoding for GPS coordinate lookups
  app.get('/api/locations/reverse', async (req, res) => {
    try {
      const lat = parseFloat(req.query.lat as string);
      const lon = parseFloat(req.query.lon as string);
      if (isNaN(lat) || isNaN(lon)) {
        return res.status(400).json({ error: 'Valid latitude and longitude required' });
      }
      const location = await reverseGeocode(lat, lon);
      res.json({ location });
    } catch (err: any) {
      res.status(500).json({ error: 'Reverse geocode failed' });
    }
  });

  // User Saved Locations
  app.get('/api/locations/saved', authMiddleware, (req, res) => {
    const user = (req as any).user;
    const locations = getUserSavedLocations(user.id);
    res.json({ locations });
  });

  app.post('/api/locations/saved', authMiddleware, (req, res) => {
    try {
      const user = (req as any).user;
      const location = req.body.location;
      if (!location || location.latitude === undefined || location.longitude === undefined) {
        return res.status(400).json({ error: 'Valid location object required' });
      }
      const locations = addSavedLocation(user.id, location);
      res.json({ locations });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.delete('/api/locations/saved', authMiddleware, (req, res) => {
    try {
      const user = (req as any).user;
      const locationName = req.query.name as string;
      if (!locationName) {
        return res.status(400).json({ error: 'Location name required' });
      }
      const locations = removeSavedLocation(user.id, locationName);
      res.json({ locations });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Full Meteorological Weather Data (Current, Hourly, Daily, Air Quality, Severe Alerts)
  app.get('/api/weather/full', async (req, res) => {
    try {
      let lat = parseFloat(req.query.lat as string);
      let lon = parseFloat(req.query.lon as string);
      let name = (req.query.name as string) || 'Selected Location';
      let admin1 = (req.query.admin1 as string) || '';
      let country = (req.query.country as string) || 'India';

      if (isNaN(lat) || isNaN(lon)) {
        // Fallback to Chennai default if coordinates missing
        lat = 13.0827;
        lon = 80.2707;
        name = 'Chennai';
        admin1 = 'Tamil Nadu';
        country = 'India';
      }

      const weatherData = await fetchFullWeatherData({
        name,
        admin1,
        country,
        latitude: lat,
        longitude: lon,
      });

      res.json(weatherData);
    } catch (err: any) {
      console.error('Weather retrieval error:', err);
      res.status(500).json({ error: 'Failed to retrieve real meteorological data: ' + err.message });
    }
  });

  // Historical Climate Data (1, 5, 10 years archive)
  app.get('/api/weather/historical', async (req, res) => {
    try {
      const lat = parseFloat(req.query.lat as string);
      const lon = parseFloat(req.query.lon as string);
      const years = parseInt((req.query.years as string) || '1', 10);
      const name = (req.query.name as string) || 'Selected Location';
      const country = (req.query.country as string) || '';

      if (isNaN(lat) || isNaN(lon)) {
        return res.status(400).json({ error: 'Latitude and longitude are required' });
      }

      const data = await fetchHistoricalClimate(
        {
          name,
          country,
          latitude: lat,
          longitude: lon,
        },
        Math.min(Math.max(years, 1), 10)
      );

      res.json(data);
    } catch (err: any) {
      console.error('Historical climate retrieval error:', err);
      res.status(500).json({ error: 'Failed to retrieve historical climate data: ' + err.message });
    }
  });

  // WeatherGPT AI Conversational Chat
  app.post('/api/chat', optionalAuthMiddleware, async (req, res) => {
    try {
      const { query, defaultLocation, language, conversationHistory } = req.body;
      if (!query || query.trim().length === 0) {
        return res.status(400).json({ error: 'Query is required' });
      }

      const user = (req as any).user;
      const userLoc = defaultLocation || user?.defaultLocation || {
        name: 'Chennai',
        country: 'India',
        admin1: 'Tamil Nadu',
        latitude: 13.0827,
        longitude: 80.2707,
      };

      const lang = language || user?.preferredLanguage || 'en';

      const result = await processWeatherQuery({
        query,
        defaultLocation: userLoc,
        language: lang,
        conversationHistory: conversationHistory || [],
      });

      res.json(result);
    } catch (err: any) {
      console.error('Chat error:', err);
      res.status(500).json({ 
        error: 'Meteorological AI processing failed. Please try again.',
        details: err.message 
      });
    }
  });

  // Chat Conversations Persistence
  app.get('/api/chat/conversations', authMiddleware, (req, res) => {
    const user = (req as any).user;
    const conversations = getConversations(user.id);
    res.json({ conversations });
  });

  app.post('/api/chat/conversations', authMiddleware, (req, res) => {
    try {
      const user = (req as any).user;
      const conversation = req.body.conversation;
      if (!conversation || !conversation.id) {
        return res.status(400).json({ error: 'Valid conversation object required' });
      }
      saveConversation(user.id, conversation);
      res.json({ success: true });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.delete('/api/chat/conversations/:id', authMiddleware, (req, res) => {
    try {
      const user = (req as any).user;
      deleteConversation(user.id, req.params.id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Agricultural Weather Advisory
  app.post('/api/agriculture/advisory', async (req, res) => {
    try {
      const { crop, location, growthStage, irrigationMethod, language } = req.body;
      if (!crop || !location) {
        return res.status(400).json({ error: 'Crop and location are required' });
      }

      const advisory = await generateAgriAdvisory({
        crop,
        location,
        growthStage: growthStage || 'Vegetative',
        irrigationMethod: irrigationMethod || 'Drip',
        language: language || 'en',
      });

      res.json(advisory);
    } catch (err: any) {
      console.error('Agriculture advisory error:', err);
      res.status(500).json({ error: 'Failed to generate agricultural advisory: ' + err.message });
    }
  });

  // Text-To-Speech Synthesis
  app.post('/api/voice/speak', async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }
      const audioBase64 = await generateSpeechAudio(text);
      res.json({ audioBase64 });
    } catch (err: any) {
      res.status(500).json({ error: 'TTS failed: ' + err.message });
    }
  });

  // Vite Middleware for dev / Static files for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WeatherGPT server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
